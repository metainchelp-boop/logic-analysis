"""계층별 성과·설정을 읽기 예산 안에서 재개 수집한다. 광고 변경은 하지 않는다.

현재 위임과 계정의 캠페인/그룹 설정을 다시 대조한 관측만 완료로 저장한다.
성과 응답 누락과 명시적 0은 별개이며, 수집 완료는 세팅 적정성 판정이 아니다.
"""
from collections import Counter
from copy import deepcopy
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta
import hashlib
import json
import math
import re
from itertools import islice
from time import monotonic

from . import handles as H, naver_read as N, store as S
from . import inspection_fields as F


MAX_ENTITIES, MAX_TASKS, MAX_BYTES = 10000, 50000, 8 * 1024 * 1024
IDS = {"campaign": "nccCampaignId", "adgroup": "nccAdgroupId", "ad": "nccAdId", "keyword": "nccKeywordId"}
PARENTS = {"adgroup": "nccCampaignId", "ad": "nccAdgroupId", "keyword": "nccAdgroupId"}
FIELDS = ("impCnt", "clkCnt", "salesAmt", "ccnt", "convAmt")
TARGETS = ("SD", "RL", "AG", "negative_keywords")
_ID = re.compile(r"[A-Za-z0-9_-]{1,100}\Z")
_SOURCE_KEYS = {"version", "customer_id", "cycle_day", "campaign_fingerprint", "campaigns", "queue",
                "next_index", "entities", "targets", "performance", "confirmed"}
_TASK_KEYS = {"kind", "parent_id", "cursor", "criterion_type", "entity_ids"}


class CheckpointInvalid(ValueError):
    pass


class InspectionChanged(ValueError):
    pass


@dataclass(frozen=True)
class InspectionOutcome:
    code: str
    counts: dict = field(default_factory=dict)


def _invalid():
    raise CheckpointInvalid("설정 관측의 범위·관계·재개 근거가 다릅니다")


def _id(value):
    return isinstance(value, str) and _ID.fullmatch(value) is not None


def _at(value, day):
    try:
        at = datetime.fromisoformat(value)
        if at.utcoffset() is None or at.astimezone(S.KST).date() < day:
            _invalid()
        return at
    except (TypeError, ValueError):
        _invalid()


def _fingerprint(rows):
    return hashlib.sha256(json.dumps(rows, sort_keys=True, separators=(",", ":"),
                                     ensure_ascii=False, allow_nan=False).encode()).hexdigest()


def _key(entity, identifier):
    return entity + ":" + identifier


def _task(kind, parent_id=None, cursor=None, criterion_type=None, entity_ids=()):
    return dict(kind=kind, parent_id=parent_id, cursor=cursor, criterion_type=criterion_type,
                entity_ids=list(entity_ids))


def validate_progress(source, job):
    """닫힌 체크포인트 계약. 임의 원문/다른 계정/관계/미래 수치는 보존하지 않는다."""
    try:
        day = date.fromisoformat(job["cycle_day"])
        if (not isinstance(source, dict) or set(source) != _SOURCE_KEYS or type(source["version"]) is not int
                or source["version"] != 1 or type(source["customer_id"]) is not int
                or source["customer_id"] != job["customer_id"] or source["cycle_day"] != job["cycle_day"]
                or type(source["confirmed"]) is not bool):
            _invalid()
        entities, campaigns, queue = source["entities"], source["campaigns"], source["queue"]
        if (not isinstance(entities, dict) or len(entities) > MAX_ENTITIES or not isinstance(campaigns, list)
                or not isinstance(queue, list) or len(queue) > MAX_TASKS or type(source["next_index"]) is not int
                or not 0 <= source["next_index"] <= len(queue)):
            _invalid()
        cid = job["customer_id"]
        for key, row in entities.items():
            if (not isinstance(row, dict) or set(row) != {"entity", "id", "parent_id", "campaign_id", "checked_at", "settings"}
                    or row["entity"] not in IDS or not _id(row["id"]) or key != _key(row["entity"], row["id"])):
                _invalid()
            _at(row["checked_at"], day)
            clean = F.sanitize_record(row["entity"], row["settings"], cid, row["parent_id"])
            if clean != row["settings"] or clean[IDS[row["entity"]]] != row["id"]:
                _invalid()
            if row["entity"] == "campaign":
                if row["parent_id"] is not None or row["campaign_id"] != row["id"]:
                    _invalid()
            else:
                parent_kind = "campaign" if row["entity"] == "adgroup" else "adgroup"
                parent = entities.get(_key(parent_kind, row["parent_id"]))
                if parent is None or row["campaign_id"] != parent["campaign_id"]:
                    _invalid()
        canonical = sorted((row["settings"] for row in entities.values() if row["entity"] == "campaign"),
                           key=lambda row: row[IDS["campaign"]])
        if canonical != campaigns or _fingerprint(campaigns) != source["campaign_fingerprint"]:
            _invalid()
        seen, processed, stats_processed = set(), set(), set()
        for index, task in enumerate(queue):
            if not isinstance(task, dict) or set(task) != _TASK_KEYS:
                _invalid()
            kind, parent, cursor = task["kind"], task["parent_id"], task["cursor"]
            if kind not in {"adgroup", "ad", "keyword", "criterion", "negative", "stats", "verify_adgroup"}:
                _invalid()
            if kind == "stats":
                if parent is not None or cursor is not None or task["criterion_type"] is not None:
                    _invalid()
                if (not isinstance(task["entity_ids"], list) or not 1 <= len(task["entity_ids"]) <= 100
                        or any(not _id(i) for i in task["entity_ids"])
                        or len(set(task["entity_ids"])) != len(task["entity_ids"])
                        or any(not any(_key(e, i) in entities for e in IDS) for i in task["entity_ids"])):
                    _invalid()
            else:
                expected = "campaign" if kind in {"adgroup", "verify_adgroup"} else "adgroup"
                if _key(expected, parent) not in entities:
                    _invalid()
                if cursor is not None and (kind not in {"adgroup", "keyword", "verify_adgroup"} or not _id(cursor)):
                    _invalid()
                if kind == "verify_adgroup":
                    if (not isinstance(task["entity_ids"], list) or len(task["entity_ids"]) > MAX_ENTITIES
                            or len(set(task["entity_ids"])) != len(task["entity_ids"])
                            or any(_key("adgroup", i) not in entities or
                                entities[_key("adgroup", i)]["parent_id"] != parent for i in task["entity_ids"])):
                        _invalid()
                elif task["entity_ids"] != []:
                    _invalid()
                if ((kind == "criterion" and task["criterion_type"] not in TARGETS[:3])
                        or (kind != "criterion" and task["criterion_type"] is not None)):
                    _invalid()
            task_key = (kind, parent, cursor, task["criterion_type"], tuple(task["entity_ids"]) if kind == "stats" else ())
            if task_key in seen:
                _invalid()
            seen.add(task_key)
            if index < source["next_index"]:
                processed.add((kind, parent, task["criterion_type"]))
                if kind == "stats":
                    if stats_processed.intersection(task["entity_ids"]):
                        _invalid()
                    stats_processed.update(task["entity_ids"])
        for row in entities.values():
            if row["entity"] != "campaign" and (row["entity"], row["parent_id"], None) not in processed:
                _invalid()
            required = ([_task("adgroup", row["id"])] if row["entity"] == "campaign" else
                        [_task(kind, row["id"]) for kind in ("ad", "keyword")] if row["entity"] == "adgroup" else [])
            if any((task["kind"], task["parent_id"], None, None, ()) not in seen for task in required):
                _invalid()
        targets = source["targets"]
        if not isinstance(targets, dict) or len(targets) > MAX_ENTITIES:
            _invalid()
        for group, observations in targets.items():
            record = entities.get(_key("adgroup", group))
            if record is None or not isinstance(observations, dict) or set(observations)-set(TARGETS):
                _invalid()
            capabilities = F.capabilities(record["settings"].get("adgroupType"))
            for kind, observation in observations.items():
                if (not isinstance(observation, dict) or set(observation) != {"state", "checked_at", "records"}
                        or observation["state"] not in {"observed", "unsupported"}):
                    _invalid()
                _at(observation["checked_at"], day)
                if observation["state"] == "unsupported":
                    if observation["records"] != [] or capabilities.get(kind) != "unsupported":
                        _invalid()
                else:
                    expected_task = ("negative", group, None) if kind == "negative_keywords" else ("criterion", group, kind)
                    if capabilities.get(kind) != "supported" or expected_task not in processed:
                        _invalid()
                    clean = (F.sanitize_negative(observation["records"], cid, group) if kind == "negative_keywords" else
                             F.sanitize_criteria(observation["records"], cid, group, kind))
                    if clean != observation["records"] or not F.valid_target_constraints(
                            clean, record["settings"].get("adgroupType"), kind):
                        _invalid()
        performance = source["performance"]
        if not isinstance(performance, dict) or set(performance)-set(entities):
            _invalid()
        for key, row in performance.items():
            if (not isinstance(row, dict) or set(row) != {"period_start", "period_end", "checked_at", "source_at", "fields", "complete", "missing"}
                    or row["period_start"] != job["period_start"] or row["period_end"] != job["period_end"]
                    or type(row["complete"]) is not bool or type(row["missing"]) is not bool
                    or not isinstance(row["fields"], dict) or set(row["fields"]) != set(FIELDS)):
                _invalid()
            checked = _at(row["checked_at"], day)
            source_at = None if row["source_at"] is None else datetime.fromisoformat(row["source_at"])
            if source_at is not None and (source_at.utcoffset() is None or source_at > checked):
                _invalid()
            for value in row["fields"].values():
                if value is not None and (type(value) not in (int, float) or not math.isfinite(value) or not 0 <= value <= 10**15):
                    _invalid()
            if row["missing"] and (row["complete"] or any(value is not None for value in row["fields"].values())):
                _invalid()
            complete = (not row["missing"] and source_at is not None and
                source_at >= datetime.combine(date.fromisoformat(job["period_end"])+timedelta(days=1), datetime.min.time(), S.KST) and
                all(value is not None for value in row["fields"].values()))
            if row["complete"] != complete:
                _invalid()
            if entities[key]["id"] not in stats_processed:
                _invalid()
        if source["confirmed"] and (source["next_index"] != len(queue) or set(performance) != set(entities)
                or any(("verify_adgroup", row["id"], None) not in processed for row in entities.values() if row["entity"] == "campaign")):
            _invalid()
        if source["confirmed"]:
            for row in entities.values():
                if row["entity"] != "adgroup":
                    continue
                capabilities = F.capabilities(row["settings"].get("adgroupType"))
                observed = targets.get(row["id"], {})
                for kind, support in capabilities.items():
                    if kind in TARGETS and support in {"supported", "unsupported"} and (
                            kind not in observed or observed[kind]["state"] != (
                                "observed" if support == "supported" else "unsupported")):
                        _invalid()
        if len(json.dumps(source, ensure_ascii=False, allow_nan=False).encode()) > MAX_BYTES:
            _invalid()
        return source
    except (KeyError, TypeError, ValueError, OverflowError, N.NaverApiError):
        _invalid()


def _entity(entity, settings, parent_id, campaign_id, now):
    identifier = settings[IDS[entity]]
    return _key(entity, identifier), dict(entity=entity, id=identifier, parent_id=parent_id,
        campaign_id=identifier if entity == "campaign" else campaign_id,
        checked_at=now.astimezone(S.KST).isoformat(), settings=settings)


def _roots(reader, handle):
    rows, cursor = reader.get_setup_page(handle, "campaign")
    if cursor is not None or len(rows) > MAX_ENTITIES:
        raise CheckpointInvalid("캠페인 목록 한도 또는 모양을 확인하지 못했습니다")
    return sorted(rows, key=lambda row: row[IDS["campaign"]])


def _initial(campaigns, job, now):
    entities = dict(_entity("campaign", row, None, None, now) for row in campaigns)
    return dict(version=1, customer_id=job["customer_id"], cycle_day=job["cycle_day"],
        campaign_fingerprint=_fingerprint(campaigns), campaigns=campaigns,
        queue=[_task("adgroup", row[IDS["campaign"]]) for row in campaigns], next_index=0,
        entities=entities, targets={}, performance={}, confirmed=False)


def _append_final(progress):
    kinds = {task["kind"] for task in progress["queue"]}
    if "stats" not in kinds and progress["entities"]:
        for kind in IDS:
            identifiers = [row["id"] for _, row in sorted(progress["entities"].items()) if row["entity"] == kind]
            progress["queue"].extend(_task("stats", entity_ids=identifiers[i:i+100]) for i in range(0, len(identifiers), 100))
        return True
    if "verify_adgroup" not in kinds and progress["campaigns"]:
        for campaign in progress["campaigns"]:
            cid = campaign[IDS["campaign"]]
            expected = sorted(row["id"] for row in progress["entities"].values()
                              if row["entity"] == "adgroup" and row["parent_id"] == cid)
            progress["queue"].append(_task("verify_adgroup", cid, entity_ids=expected))
        return True
    return False


def _read_task(reader, handle, job, task, progress, clock):
    kind, parent = task["kind"], task["parent_id"]
    if kind in {"adgroup", "ad", "keyword", "verify_adgroup"}:
        entity = "adgroup" if kind == "verify_adgroup" else kind
        rows, cursor = reader.get_setup_page(handle, entity, parent, page_token=task["cursor"])
        now = clock()
        if kind == "verify_adgroup":
            remaining = set(task["entity_ids"])
            for row in rows:
                rid = row[IDS[entity]]
                prior = progress["entities"].get(_key(entity, rid))
                if rid not in remaining or prior is None or prior["settings"] != row:
                    raise InspectionChanged()
                remaining.remove(rid)
            if cursor is None and remaining:
                raise InspectionChanged()
            if cursor is not None:
                progress["queue"].append(_task(kind, parent, cursor, entity_ids=sorted(remaining)))
            return
        parent_kind = "campaign" if entity == "adgroup" else "adgroup"
        campaign_id = progress["entities"][_key(parent_kind, parent)]["campaign_id"]
        for row in rows:
            key, observed = _entity(entity, row, parent, campaign_id, now)
            if key in progress["entities"]:
                raise InspectionChanged()
            progress["entities"][key] = observed
            if entity == "adgroup":
                progress["queue"].extend(_task(child, observed["id"]) for child in ("ad", "keyword"))
                capabilities = F.capabilities(row.get("adgroupType"))
                for target in TARGETS:
                    support = capabilities.get(target)
                    if support == "supported":
                        progress["queue"].append(_task("negative" if target == "negative_keywords" else "criterion",
                            observed["id"], criterion_type=None if target == "negative_keywords" else target))
                    elif support == "unsupported":
                        progress["targets"].setdefault(observed["id"], {})[target] = {
                            "state": "unsupported", "checked_at": now.isoformat(), "records": []}
        if cursor is not None:
            progress["queue"].append(_task(kind, parent, cursor))
    elif kind in {"criterion", "negative"}:
        target = "negative_keywords" if kind == "negative" else task["criterion_type"]
        rows = (reader.get_setup_negative_keywords(handle, parent) if kind == "negative" else
                reader.get_setup_criteria(handle, parent, target))
        group_type = progress["entities"]["adgroup:"+parent]["settings"].get("adgroupType")
        if not F.valid_target_constraints(rows, group_type, target):
            raise N.NaverApiError(N.KIND_BAD_RESPONSE, "/ncc/targets", 200,
                customer=job["customer_id"], detail="광고 유형의 타겟 제약과 응답이 다름")
        now = clock()
        progress["targets"].setdefault(parent, {})[target] = {"state": "observed", "checked_at": now.isoformat(), "records": rows}
    elif kind == "stats":
        result = reader.get_entity_stats_summary(handle, task["entity_ids"], date.fromisoformat(job["period_start"]),
            date.fromisoformat(job["period_end"]), FIELDS)
        now = clock()
        for key, entity in progress["entities"].items():
            if entity["id"] not in task["entity_ids"]:
                continue
            missing = entity["id"] in result.missing_ids
            fields = {name: None if missing else result.rows[entity["id"]].get(name) for name in FIELDS}
            progress["performance"][key] = {"period_start": job["period_start"], "period_end": job["period_end"],
                "checked_at": now.isoformat(), "source_at": result.cycle_base_tm.isoformat() if result.cycle_base_tm else None,
                "fields": fields, "complete": not missing and result.data_fresh and all(v is not None for v in fields.values()),
                "missing": missing}


def _read(reader, handle, job, store, clock, values):
    progress = store.inspection_progress(job)
    if progress is not None:
        validate_progress(progress, job)
        if any(datetime.fromisoformat(row["checked_at"]) > clock() for row in progress["entities"].values()):
            _invalid()
    campaigns = _roots(reader, handle)
    reader.check_budget()
    if progress is None or progress["campaign_fingerprint"] != _fingerprint(campaigns):
        progress = _initial(campaigns, job, clock())
        store.record_inspection_progress(job, clock(), progress)
    while True:
        if progress["next_index"] == len(progress["queue"]):
            update = deepcopy(progress)
            if not _append_final(update):
                break
            store.record_inspection_progress(job, clock(), update)
            progress = update
        task = progress["queue"][progress["next_index"]]
        update = deepcopy(progress)
        try:
            _read_task(reader, handle, job, task, update, clock)
        except InspectionChanged:
            store.record_inspection_progress(job, clock(), _initial(campaigns, job, clock()))
            raise
        reader.check_budget()
        update["next_index"] += 1
        validate_progress(update, job)
        store.record_inspection_progress(job, clock(), update)
        progress = update
        values["progressed"] = True
    after = _roots(reader, handle)
    if _fingerprint(after) != progress["campaign_fingerprint"]:
        store.record_inspection_progress(job, clock(), _initial(after, job, clock()))
        raise InspectionChanged()
    reader.check_budget()
    update = deepcopy(progress)
    update["confirmed"] = True
    validate_progress(update, job)
    store.record_inspection_progress(job, clock(), update)
    values.update(status="ok")


def run_inspection(reader, store, clock, *, limit=24, max_calls=6, max_seconds=10, per_account_calls=8,
                   exclude_customers=()):
    if (type(limit) is not int or not 1 <= limit <= 24 or type(max_calls) is not int or not 1 <= max_calls <= 24
            or type(max_seconds) not in (int, float) or not 0 < max_seconds <= 30
            or type(per_account_calls) is not int or not 2 <= per_account_calls <= 8):
        raise ValueError("세부 점검 수집 예산이 올바르지 않습니다")
    excluded = tuple(islice(exclude_customers, MAX_ENTITIES+1))
    if len(excluded) > MAX_ENTITIES or any(type(cid) is not int or cid <= 0 for cid in excluded):
        raise ValueError("세부 점검 제외 계정이 올바르지 않습니다")
    if reader.rate_limited:
        return InspectionOutcome("BUDGET")
    now, initial, started, counts = clock(), reader.calls, monotonic(), Counter()
    with reader.bounded_requests(max_calls=max_calls, max_seconds=max_seconds):
        for job in store.inspection_work(now, limit):
            if job["customer_id"] in excluded:
                continue
            elapsed = max((clock()-now).total_seconds(), monotonic()-started)
            if elapsed >= max_seconds or max_calls-(reader.calls-initial) < 2:
                return InspectionOutcome("BUDGET", dict(counts))
            if clock() < now or clock().astimezone(S.KST).date() != now.astimezone(S.KST).date():
                return InspectionOutcome("SOURCE_CHANGED", dict(counts))
            values = {}
            try:
                store.begin_inspection_check(job, clock())
                handle = H.issue_inventory_handle(customer_id=job["customer_id"], snapshot_at=job["snapshot_at"], now=clock(),
                    validate=lambda cid, snapshot, at: store.inspection_account_valid(job, at))
                with reader.bounded_requests(max_calls=per_account_calls, max_seconds=min(20, max_seconds-elapsed)):
                    _read(reader, handle, job, store, clock, values)
                    reader.check_budget()
            except N.NaverApiError as exc:
                values.update(status="reauth_required" if exc.kind == N.KIND_KEY_REJECTED else "retry", error_code=exc.kind)
            except N.StatsShapeUnknown:
                values.update(status="retry", error_code="STATS_SHAPE_UNKNOWN")
            except InspectionChanged:
                values.update(status="retry", error_code="SETTINGS_CHANGED")
            except CheckpointInvalid:
                values.update(status="limited", error_code="CHECKPOINT_INVALID")
            except N.RunAbort as exc:
                values.update(status="partial" if values.get("progressed") else "retry",
                    error_code=N.KIND_RATE if reader.rate_limited else exc.cause_code or exc.code)
            except (H.NotEligible, H.HandleInvalid, S.StoreRefused):
                return InspectionOutcome("SOURCE_CHANGED", dict(counts))
            except S.StoreError:
                raise
            except Exception:
                values.update(status="retry", error_code="UNEXPECTED")
            try:
                status = store.record_inspection_check(job, clock(), values)
            except S.StoreRefused:
                return InspectionOutcome("SOURCE_CHANGED", dict(counts))
            counts[status] += 1
            if reader.rate_limited:
                return InspectionOutcome("BUDGET", dict(counts))
    return InspectionOutcome("DONE", dict(counts))
