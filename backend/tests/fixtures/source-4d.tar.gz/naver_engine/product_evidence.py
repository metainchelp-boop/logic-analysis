"""Closed saved-product observations. Pure validation/selection; no file, DB or network I/O."""
from copy import deepcopy
from datetime import datetime, timedelta, timezone
import hashlib
import json
import math
import re
from urllib.parse import urlparse

KST = timezone(timedelta(hours=9))
MAX_EXPORT_AGE = timedelta(hours=30)
MAX_RECORD_AGE = timedelta(days=14)
MAX_FUTURE = timedelta(minutes=5)
MAX_BUNDLE_BYTES = 5 * 1024 * 1024
METRICS = frozenset({"price", "review_count", "rating"})
FEATURES = frozenset({"delivery_info", "return_info", "gift_info", "certification", "review_section", "spec_table"})
DISPLAY_FIELDS = ("name", "category", "price", "review_count", "rating", "delivery_info", "return_info",
                  "gift_info", "certification", "review_section", "spec_table", "source_status")
REASONS = frozenset({"ok", "not_linked", "not_found", "ambiguous", "no_products", "stale", "invalid", "unavailable"})
_HOSTS = frozenset({"smartstore.naver.com", "brand.naver.com"})
_SOURCES = frozenset({"html_meta", "html_json_ld", "html_next_data", "review_sample", "stored_product_info"})
_PRODUCT_FIELDS = frozenset({"product_key", "recorded_at", "observed_at", "name", "category", "metrics", "features"})
_MODEL_FIELDS = frozenset({"index", "name", "category", "metrics", "features"})
_PATH = re.compile(r"/([A-Za-z0-9_-]{1,100})(?:/products/([1-9][0-9]{0,23}))?/?")


class EvidenceInvalid(ValueError):
    pass


def _bad():
    raise EvidenceInvalid("PRODUCT_EVIDENCE_INVALID")


def _identity(value):
    if (not isinstance(value, str) or not 1 <= len(value) <= 2048 or value != value.strip()
            or any(ord(c) < 32 or ord(c) == 127 for c in value)):
        return None
    try:
        parsed = urlparse(value if "://" in value else "https://" + value)
        host = (parsed.hostname or "").lower()
        if parsed.scheme not in {"http", "https"} or parsed.netloc.lower() != host or parsed.params:
            return None
        host = host.removeprefix("m.")
        match = _PATH.fullmatch(parsed.path)
        if host not in _HOSTS or match is None:
            return None
        return host, match[1], match[2]
    except (ValueError, TypeError):
        return None


def canonical_store(value):
    identity = _identity(value)
    return "/".join(identity[:2]) if identity else None


def canonical_product(value):
    identity = _identity(value)
    return "/".join(identity[:2]) + "/products/" + identity[2] if identity and identity[2] else None


def _moment(value):
    try:
        at = datetime.fromisoformat(value) if isinstance(value, str) else value
        return at.astimezone(KST) if isinstance(at, datetime) and at.utcoffset() is not None else None
    except (ValueError, TypeError, OverflowError):
        return None


def _text(value):
    if value is None:
        return None
    if (not isinstance(value, str) or not 1 <= len(value) <= 100 or value != value.strip()
            or any(ord(c) < 32 or 0x7f <= ord(c) <= 0x9f or 0xd800 <= ord(c) <= 0xdfff
                   or c in "<>{}" or 0x202a <= ord(c) <= 0x202e or 0x2066 <= ord(c) <= 0x2069 for c in value)
            or re.search(r"https?://|www\.|[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}|(?<!\d)\+?\d(?:[ .()-]?\d){8,14}(?!\d)|\b[A-Za-z0-9-]+\.(?:com|net|org|co\.kr|kr|io)\b", value, re.I)):
        _bad()
    return value


def _number(value, high, *, integer=False):
    # Bound before isfinite so a malicious arbitrary-precision integer cannot raise OverflowError.
    return type(value) in ((int,) if integer else (int, float)) and 0 <= value <= high and math.isfinite(value)


def _facts(value):
    """Validate shared model/source fields without interpreting narrative or inferred benefits."""
    name, category = _text(value["name"]), _text(value["category"])
    metrics, features = value["metrics"], value["features"]
    if not isinstance(metrics, dict) or set(metrics) != METRICS or not isinstance(features, dict) or set(features) != FEATURES:
        _bad()
    for key, item in metrics.items():
        if not isinstance(item, dict) or set(item) != {"value", "status", "sources"}:
            _bad()
        status, sources = item["status"], item["sources"]
        if (not isinstance(status, str) or status not in {"measured", "cross_verified", "unavailable"} or not isinstance(sources, list)
                or len(sources) > len(_SOURCES) or any(not isinstance(s, str) or s not in _SOURCES for s in sources)
                or len(set(sources)) != len(sources)):
            _bad()
        if status == "unavailable":
            if item["value"] is not None or sources:
                _bad()
        elif (not sources or not _number(item["value"], {"price": 10**12, "review_count": 10**9, "rating": 5}[key], integer=key == "review_count")
              or status == "cross_verified" and len(sources) < 2
              or "review_sample" in sources and key != "rating"):
            _bad()
    if any(v is not None and type(v) is not bool for v in features.values()):
        _bad()
    return {"name": name, "category": category, "metrics": deepcopy(metrics), "features": deepcopy(features)}


def _has_facts(product):
    return (product["name"] is not None or product["category"] is not None
            or any(item["value"] is not None for item in product["metrics"].values())
            or any(value is not None for value in product["features"].values()))


def validate_bundle(bundle, now):
    """All-or-none shape validation. Old but valid sources are selected as stale, not repaired."""
    now = _moment(now)
    if now is None or not isinstance(bundle, dict) or set(bundle) != {"schema_version", "exported_at", "complete", "stores"}:
        _bad()
    at = _moment(bundle["exported_at"])
    stores = bundle["stores"]
    if (type(bundle["schema_version"]) is not int or bundle["schema_version"] != 1 or bundle["complete"] is not True
            or at is None or at > now + MAX_FUTURE or not isinstance(stores, list) or len(stores) > 10000):
        _bad()
    clean, seen = [], set()
    for store in stores:
        if not isinstance(store, dict) or set(store) != {"store_key", "status", "products"}:
            _bad()
        key, status, products = store["store_key"], store["status"], store["products"]
        if (not isinstance(key, str) or canonical_store(key) != key or key in seen
                or not isinstance(status, str) or status not in {"ok", "ambiguous", "no_products"} or not isinstance(products, list)
                or len(products) > 3 or status != "ok" and products or status == "ok" and not products):
            _bad()
        seen.add(key)
        current, identifiers = [], set()
        for product in products:
            if not isinstance(product, dict) or set(product) != _PRODUCT_FIELDS:
                _bad()
            identifier, recorded = product["product_key"], _moment(product["recorded_at"])
            if (not isinstance(identifier, str) or canonical_product(identifier) != identifier
                    or canonical_store(identifier) != key or identifier in identifiers
                    or recorded is None or recorded > at + MAX_FUTURE or recorded > now + MAX_FUTURE
                    or product["observed_at"] is not None):
                _bad()
            identifiers.add(identifier)
            current.append({"product_key": identifier, "recorded_at": recorded.isoformat(), "observed_at": None, **_facts(product)})
        clean.append({"store_key": key, "status": status, "products": current})
    result = {"schema_version": 1, "exported_at": at.isoformat(), "complete": True, "stores": clean}
    if len(json.dumps(result, ensure_ascii=False, allow_nan=False, separators=(",", ":")).encode()) > MAX_BUNDLE_BYTES:
        _bad()
    return result


def select(bundle, store_key, now):
    """Current link selects only its store. An export refresh alone does not change fact provenance."""
    now = _moment(now)
    if now is None:
        _bad()
    key = canonical_store(store_key)
    status, at, products = "not_linked", None, []
    if key is not None:
        if bundle is None:
            status = "unavailable"
        else:
            try:
                source = validate_bundle(bundle, now)
                at = source["exported_at"]
                if now - _moment(at) > MAX_EXPORT_AGE:
                    status = "stale"
                else:
                    store = next((row for row in source["stores"] if row["store_key"] == key), None)
                    if store is None:
                        status = "not_found"
                    elif store["status"] != "ok":
                        status = store["status"]
                    else:
                        products = [p for p in store["products"] if now - _moment(p["recorded_at"]) <= MAX_RECORD_AGE and _has_facts(p)]
                        status = "ready" if products else "stale" if any(_has_facts(p) for p in store["products"]) else "no_products"
            except EvidenceInvalid:
                status, at, products = "invalid", None, []
    fingerprint = hashlib.sha256(json.dumps([status, key, products], ensure_ascii=False, allow_nan=False,
                                            sort_keys=True, separators=(",", ":")).encode()).hexdigest()
    return {"schema_version": 1, "status": status, "store_key": key, "exported_at": at,
            "source_fingerprint": fingerprint, "products": deepcopy(products)}


def normalize_context(value):
    keys = {"version", "state", "reason", "source_time_confirmed", "products"}
    if (not isinstance(value, dict) or set(value) != keys or type(value["version"]) is not int or value["version"] != 1
            or not isinstance(value["state"], str) or value["state"] not in {"stored_observations", "unavailable"}
            or not isinstance(value["reason"], str) or value["reason"] not in REASONS
            or value["source_time_confirmed"] is not False or not isinstance(value["products"], list) or len(value["products"]) > 3):
        _bad()
    ready = value["state"] == "stored_observations"
    if ready != (value["reason"] == "ok") or ready != bool(value["products"]):
        _bad()
    products = []
    for index, product in enumerate(value["products"], 1):
        if not isinstance(product, dict) or set(product) != _MODEL_FIELDS or type(product["index"]) is not int or product["index"] != index:
            _bad()
        clean = {"index": index, **_facts(product)}
        if not _has_facts(clean):
            _bad()
        products.append(clean)
    return {"version": 1, "state": value["state"], "reason": value["reason"], "source_time_confirmed": False, "products": products}


def model_context(selection):
    if (not isinstance(selection, dict) or not isinstance(selection.get("status"), str)
            or selection["status"] not in REASONS | {"ready"} or not isinstance(selection.get("products"), list)):
        _bad()
    ready = selection["status"] == "ready"
    if ready and (not selection["products"] or len(selection["products"]) > 3
                  or any(not isinstance(product, dict) or not _PRODUCT_FIELDS <= set(product)
                         for product in selection["products"])):
        _bad()
    if not ready and selection["products"]:
        _bad()
    return normalize_context({"version": 1, "state": "stored_observations" if ready else "unavailable",
        "reason": "ok" if ready else selection["status"], "source_time_confirmed": False,
        "products": [{"index": i, **{key: deepcopy(p[key]) for key in ("name", "category", "metrics", "features")}}
                     for i, p in enumerate(selection.get("products", []) if ready else [], 1)]})


def display(context, index, field):
    value = normalize_context(context)
    if type(index) is not int or not 1 <= index <= len(value["products"]) or field not in DISPLAY_FIELDS:
        _bad()
    product, prefix = value["products"][index - 1], f"저장 관측 상품 {index}의 "
    if field == "source_status":
        return prefix + "분석 저장분 기준 · 실제 수집 시각과 현재 조건은 미확인"
    if field in {"name", "category"}:
        if product[field] is None:
            _bad()
        return prefix + ("상품명 " if field == "name" else "분류 ") + product[field]
    if field in METRICS:
        metric = product["metrics"][field]
        if metric["value"] is None:
            _bad()
        number = format(metric["value"], ",.2f").rstrip("0").rstrip(".") if type(metric["value"]) is float else format(metric["value"], ",")
        label, unit = {"price": ("가격", "원"), "review_count": ("리뷰 수", "건"), "rating": ("평점", "점")}[field]
        if field == "rating" and metric["sources"] == ["review_sample"]:
            label = "저장 리뷰 표본 평균"
        return prefix + label + " " + number + unit + (" · 교차확인된 저장값" if metric["status"] == "cross_verified" else " · 실측으로 기록된 저장값")
    feature = product["features"][field]
    if feature is None:
        _bad()
    label = {"delivery_info": "배송 안내", "return_info": "반품 안내", "gift_info": "증정 안내",
             "certification": "인증 관련 안내", "review_section": "리뷰 영역", "spec_table": "규격표"}[field]
    return prefix + label + ("가 저장 페이지에서 탐지됨" if feature else "가 저장 페이지에서 탐지되지 않음")
