"""Validate the registered non-personal process counter callback, without I/O."""
from datetime import datetime

_FIELDS={'version','available','scope','durable','account_scoped','started_at','blocked_before_attempt','items'}
_COUNTERS={'attempts','http_responses','http_successes','http_failures','transport_failures','elapsed_ms','latency_samples'}

def project(getter):
    unavailable={'version':1,'available':False}
    try:
        value=getter()
        if type(value) is not dict or set(value)!=_FIELDS or type(value['version']) is not int or value['version']!=1 or value['available'] is not True or value['scope']!='process_since_start' or value['durable'] is not False or value['account_scoped'] is not False:return unavailable
        stamp=value['started_at']
        if type(stamp) is not str or not 20<=len(stamp)<=40 or datetime.fromisoformat(stamp).utcoffset() is None:return unavailable
        if type(value['blocked_before_attempt']) is not int or not 0<=value['blocked_before_attempt']<2**53:return unavailable
        rows=value['items']
        if type(rows) is not list or len(rows)>128:return unavailable
        seen=set();items=[]
        for row in rows:
            if type(row) is not dict or set(row)!=_COUNTERS|{'service','phase','method'} or row['service'] not in {'naver','erp'} or row['phase'] not in {'collection','execution','sync','profile'} or row['method'] not in {'GET','POST','PUT','OTHER'}:return unavailable
            key=(row['service'],row['phase'],row['method'])
            if key in seen or any(type(row[k]) is not int or not 0<=row[k]<2**53 for k in _COUNTERS):return unavailable
            if row['http_responses']!=row['http_successes']+row['http_failures'] or row['http_responses']+row['transport_failures']>row['attempts'] or row['latency_samples']>row['attempts']:return unavailable
            seen.add(key);items.append(dict(row))
        return {**value,'items':items}
    except Exception:return unavailable
