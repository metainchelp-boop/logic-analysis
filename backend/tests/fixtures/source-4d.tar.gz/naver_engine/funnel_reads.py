"""Optional daily-only platform purchase reads inside the shared GET budget.

The existing batched general performance reader is intentionally unchanged.
Purchase fields and their basic denominators always come from the same call.
"""
from collections import Counter
from copy import deepcopy
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta
from decimal import Decimal
from itertools import islice
import hashlib
import json
import math
from time import monotonic

from . import fields as F, handles as H, naver_read as N, store as S

FIELDS = ("impCnt", "clkCnt", "salesAmt", "purchaseCcnt", "purchaseConvAmt")
OUTPUTS = ("imp", "clk", "spend", "purchase_count", "purchase_value")
MAX_NUMBER = 9007199254740991
MAX_CAMPAIGNS = 10000
_SOURCE = frozenset({"version", "customer_id", "period_start", "period_end", "generation", "campaigns",
                     "campaign_fingerprint", "next_index", "cycles", "day_totals"})


class CheckpointInvalid(ValueError):
    pass


class FunnelIncomplete(ValueError):
    CODES = frozenset({"STATS_INCOMPLETE", "STATS_PERIOD_OPEN", "STATS_METRIC_MISSING", "STATS_METRIC_INVALID",
                       "STATS_DATE_INCOMPLETE", "STATS_CYCLE_INVALID", "STATS_CYCLE_FUTURE", "STATS_CAMPAIGNS_INVALID"})

    def __init__(self, *, code="STATS_INCOMPLETE"):
        self.code = code if code in self.CODES else "STATS_INCOMPLETE"
        super().__init__("구매전환 원천의 날짜·응답을 확인하지 못했습니다")


class SourceAggregating(FunnelIncomplete):
    pass


@dataclass(frozen=True)
class FunnelOutcome:
    code: str
    counts: dict = field(default_factory=dict)


def _invalid():
    raise CheckpointInvalid("구매전환 재개 원천의 범위·숫자·세대가 다릅니다")


def _at(value):
    try:
        at = datetime.fromisoformat(value) if isinstance(value, str) else value
        if not isinstance(at, datetime) or at.utcoffset() is None:
            _invalid()
        return at.astimezone(S.KST)
    except (TypeError, ValueError, OverflowError):
        _invalid()


def _period(job):
    try:
        start, end = date.fromisoformat(job["period_start"]), date.fromisoformat(job["period_end"])
        if (start.isoformat() != job["period_start"] or end.isoformat() != job["period_end"]
                or not 0 <= (end-start).days < 31 or type(job["customer_id"]) is not int or job["customer_id"] <= 0):
            _invalid()
        _at(job["generation"])
        return start, end
    except (TypeError, ValueError, KeyError, OverflowError):
        _invalid()


def _days(start, end):
    return tuple(str(start+timedelta(days=index)) for index in range((end-start).days+1))


def _number(value, key):
    if value is None and key in FIELDS[3:]:
        return None
    if (type(value) not in (int, float) or not 0 <= value <= MAX_NUMBER or not math.isfinite(value)
            or key in ("impCnt", "clkCnt", "purchaseCcnt") and int(value) != value):
        _invalid()
    return int(value) if int(value) == value else value


def _add(left, right, key):
    if left is None or right is None:
        return None
    total = Decimal(str(left))+Decimal(str(right))
    if total > MAX_NUMBER:
        _invalid()
    return _number(int(total) if total == int(total) else float(total), key)


def _campaigns(rows, cid):
    if not isinstance(rows, list) or len(rows) > MAX_CAMPAIGNS:
        _invalid()
    clean, seen = [], set()
    for row in rows:
        if not isinstance(row, dict): _invalid()
        item = F.keep(row, F.CAMPAIGN)
        identifier = item.get("nccCampaignId")
        if (not isinstance(identifier, str) or not N._CAMPAIGN_ID.fullmatch(identifier) or identifier in seen
                or type(item.get("customerId")) is not int or item["customerId"] != cid):
            _invalid()
        seen.add(identifier); clean.append(item)
    return sorted(clean, key=lambda row: row["nccCampaignId"])


def fingerprint(campaigns):
    try:
        return hashlib.sha256(json.dumps(campaigns, sort_keys=True, ensure_ascii=False, separators=(",", ":"), allow_nan=False).encode()).hexdigest()
    except (TypeError, ValueError, OverflowError):
        _invalid()


def _cycle(value, end, generation, now=None):
    at = _at(value)
    if at.date() <= end or at.date() < _at(generation).date() or now is not None and at > now:
        _invalid()
    return at


def validate_progress(source, job, now=None):
    """Closed checkpoint contract, shared with storage; optional now rejects future cycles."""
    start, end = _period(job)
    if (not isinstance(source, dict) or set(source) != _SOURCE or type(source["version"]) is not int or source["version"] != 1
            or type(source["customer_id"]) is not int or source["customer_id"] != job["customer_id"]
            or source["period_start"] != job["period_start"] or source["period_end"] != job["period_end"]
            or source["generation"] != job["generation"]):
        _invalid()
    campaigns = _campaigns(source["campaigns"], job["customer_id"])
    if campaigns != source["campaigns"] or source["campaign_fingerprint"] != fingerprint(campaigns):
        _invalid()
    index, cycles, totals = source["next_index"], source["cycles"], source["day_totals"]
    if (type(index) is not int or not 0 <= index <= len(campaigns) or not isinstance(cycles, list) or len(cycles) != index
            or not isinstance(totals, dict) or set(totals) != set(_days(start, end))):
        _invalid()
    if now is not None:
        now = _at(now)
        if _at(job["generation"]) > now:
            _invalid()
    for value in cycles:
        _cycle(value, end, job["generation"], now)
    result = {}
    for day, row in totals.items():
        if not isinstance(row, dict) or set(row) != set(FIELDS):
            _invalid()
        clean = {key: _number(row[key], key) for key in FIELDS}
        if index == 0 and any(clean[key] != (None if not campaigns and key in FIELDS[3:] else 0) for key in FIELDS):
            _invalid()
        complete = index == len(campaigns)
        result[day] = {**clean, "basic_complete": complete,
                       "count_complete": complete and clean["purchaseCcnt"] is not None,
                       "value_complete": complete and clean["purchaseConvAmt"] is not None}
    return result


def _normalized(daily):
    result = {}
    for day, row in daily.days.items():
        if not isinstance(row, dict) or set(row) != set(FIELDS) or any(row[key] is None for key in FIELDS[:3]):
            raise FunnelIncomplete(code="STATS_METRIC_MISSING")
        try:
            result[day] = {key: _number(row[key], key) for key in FIELDS}
        except CheckpointInvalid:
            raise FunnelIncomplete(code="STATS_METRIC_INVALID") from None
    return result


def _read(reader, handle, job, values, store, clock):
    start, end = _period(job)
    if end >= _at(clock()).date():
        raise FunnelIncomplete(code="STATS_PERIOD_OPEN")
    if _at(job["generation"]) > _at(clock()):
        _invalid()
    progress = store.funnel_progress(job)
    if progress is not None:
        validate_progress(progress, job, clock())
    before = _campaigns(reader.get_campaigns(handle), job["customer_id"])
    reader.check_budget()
    if progress is None or progress["campaigns"] != before:
        totals = {day: dict.fromkeys(FIELDS, 0) for day in _days(start, end)}
        if not before:
            for row in totals.values(): row.update(purchaseCcnt=None, purchaseConvAmt=None)
        progress = {"version": 1, "customer_id": job["customer_id"], "period_start": job["period_start"],
                    "period_end": job["period_end"], "generation": job["generation"], "campaigns": before,
                    "campaign_fingerprint": fingerprint(before), "next_index": 0, "cycles": [], "day_totals": totals}
        store.record_funnel_progress(job, clock(), progress)
    for campaign in before[progress["next_index"]:]:
        daily = reader.get_stats_daily(handle, campaign["nccCampaignId"], start, end, fields=FIELDS)
        reader.check_budget()
        if daily.entity_id != campaign["nccCampaignId"]:
            raise FunnelIncomplete(code="STATS_CAMPAIGNS_INVALID")
        normalized = _normalized(daily)
        try:
            cycle = _at(daily.cycle_base_tm)
        except CheckpointInvalid:
            raise FunnelIncomplete(code="STATS_CYCLE_INVALID") from None
        if cycle > _at(clock()):
            raise FunnelIncomplete(code="STATS_CYCLE_FUTURE")
        if (not daily.data_fresh or daily.missing_days or cycle.date() < _at(job["generation"]).date()):
            raise SourceAggregating()
        if set(daily.days) != set(_days(start, end)):
            raise FunnelIncomplete(code="STATS_DATE_INCOMPLETE")
        _cycle(cycle, end, job["generation"], clock())
        update = deepcopy(progress)
        try:
            for day, row in normalized.items():
                for key in FIELDS: update["day_totals"][day][key] = _add(update["day_totals"][day][key], row[key], key)
        except CheckpointInvalid:
            raise FunnelIncomplete(code="STATS_METRIC_INVALID") from None
        update["cycles"].append(cycle.isoformat()); update["next_index"] += 1
        store.record_funnel_progress(job, clock(), update)
        progress = update; values["progressed"] = True
    after = _campaigns(reader.get_campaigns(handle), job["customer_id"])
    reader.check_budget()
    if before != after:
        values.update(status="retry", error_code="CAMPAIGNS_CHANGED")
        return
    rows = validate_progress(progress, job, clock())
    at = _at(clock()).isoformat()
    source_at = min(progress["cycles"]) if progress["cycles"] else at
    values.update(status="ok", error_code=None, campaign_fingerprint=progress["campaign_fingerprint"], campaigns=after,
                  daily_rows=[{"customer_id": job["customer_id"], "day": day,
                      **{key: row[key] for key in ("basic_complete", "count_complete", "value_complete")},
                      **dict(zip(OUTPUTS, (row[key] for key in FIELDS))), "checked_at": at, "source_at": source_at}
                      for day, row in sorted(rows.items())])


def run_funnel(reader, store, clock, *, limit=24, max_calls=6, max_seconds=20, per_account_calls=6,
               exclude_customers=()):
    if (type(limit) is not int or not 1 <= limit <= 24 or type(max_calls) is not int or not 1 <= max_calls <= 6
            or type(max_seconds) not in (int, float) or not 0 < max_seconds <= 20
            or type(per_account_calls) is not int or not 1 <= per_account_calls <= 6):
        raise ValueError("구매전환 읽기 예산이 올바르지 않습니다")
    try:
        excluded = tuple(islice(exclude_customers, MAX_CAMPAIGNS+1))
    except TypeError:
        raise ValueError("구매전환 제외 계정이 올바르지 않습니다") from None
    if len(excluded) > MAX_CAMPAIGNS or any(type(cid) is not int or cid <= 0 for cid in excluded):
        raise ValueError("구매전환 제외 계정이 올바르지 않습니다")
    excluded = set(excluded) | set(reader.called_customers)
    if reader.rate_limited: return FunnelOutcome("BUDGET")
    now, initial, started = _at(clock()), reader.calls, monotonic()
    if store.inventory_snapshot(now) is None: return FunnelOutcome("NOT_READY")
    counts, seen = Counter(), set()
    with reader.bounded_requests(max_calls=max_calls, max_seconds=max_seconds):
        for job in store.funnel_work(now, limit):
            if job["customer_id"] in seen or job["customer_id"] in excluded: continue
            elapsed = max((_at(clock())-now).total_seconds(), monotonic()-started)
            if elapsed >= max_seconds or max_calls-(reader.calls-initial) < 2: return FunnelOutcome("BUDGET", dict(counts))
            if clock() < now or _at(clock()).date() != now.date(): return FunnelOutcome("SOURCE_CHANGED", dict(counts))
            values = {}
            try:
                seen.add(job["customer_id"])
                store.begin_funnel_check(job, clock())
                handle = H.issue_inventory_handle(customer_id=job["customer_id"], snapshot_at=job["snapshot_at"], now=clock(),
                    validate=lambda cid, snapshot, at: store.funnel_account_valid(job, at))
                with reader.bounded_requests(max_calls=min(per_account_calls, max_calls-(reader.calls-initial)),
                        max_seconds=min(20, max_seconds-elapsed)):
                    _read(reader, handle, job, values, store, clock)
                    reader.check_budget()
            except N.NaverApiError as exc:
                values.update(status="reauth_required" if exc.kind == N.KIND_KEY_REJECTED else "retry", error_code=exc.kind)
            except SourceAggregating:
                values.update(status="source_wait", error_code="SOURCE_AGGREGATING")
            except (N.StatsShapeUnknown, FunnelIncomplete) as exc:
                values.update(status="retry", error_code=exc.code)
            except CheckpointInvalid:
                values.update(status="limited", error_code="CHECKPOINT_INVALID")
            except N.RunAbort as exc:
                values.update(status="partial" if values.get("progressed") else "retry",
                              error_code=N.KIND_RATE if reader.rate_limited else exc.cause_code or exc.code)
            except (H.NotEligible, H.HandleInvalid, S.StoreRefused):
                return FunnelOutcome("SOURCE_CHANGED", dict(counts))
            except S.StoreError:
                raise
            except Exception:
                values.update(status="retry", error_code="UNEXPECTED")
            try:
                status = store.record_funnel_check(job, clock(), values)
            except S.StoreRefused:
                return FunnelOutcome("SOURCE_CHANGED", dict(counts))
            counts[status] += 1
            if reader.rate_limited: return FunnelOutcome("BUDGET", dict(counts))
    return FunnelOutcome("DONE", dict(counts))
