"""저장판 수치와 분리한 조회 전용 갱신 상태. 수집/생성/저장은 하지 않는다."""
from datetime import datetime, timedelta

from . import reporting as R


def _time(raw):
    try:
        at = datetime.fromisoformat(raw or "")
        return at.astimezone(R.KST) if at.tzinfo is not None and at.utcoffset() is not None else None
    except (TypeError, ValueError):
        return None


def latest_job(jobs):
    """종료 시각이 같으면 최신 세대, 같은 세대의 충돌은 미완결을 우선한다."""
    unknown = datetime.max.replace(tzinfo=R.KST)
    return max(jobs, key=lambda job: (_time(job.get("checked_at")) or unknown,
        _time(job.get("generation")) or unknown, job.get("status") != "ok",
        job.get("status") in ("retry", "limited", "reauth_required")), default=None)


def source_collected_at(rows, now):
    times = []
    for row in rows:
        checked, source, generation = (_time(row.get(key)) for key in ("checked_at", "source_at", "source_generation"))
        if (checked and source and generation and source <= checked <= now and generation <= checked
                and source.date() >= generation.date() and R._collected(row, row.get("day"), now)):
            times.append(checked)
    return max(times).isoformat() if times else None


def scope_state(period, expected, rows, jobs, queued, prior, required_after, dirty, now):
    """이미 저장된 원천·작업 증거만 사용한다. 전환 미확인을 0/성공으로 바꾸지 않는다."""
    by_day = {(row["customer_id"], row["day"]): row for row in rows}
    pending, failed, attempts, proven, basis_unconfirmed = 0, False, [], [], 0
    response = {key+"_account_days": 0 for key in ("expected", "received", "zero", "positive",
        "missing_or_null", "source_unverified", "basic_incomplete")}
    for cid in expected:
        for offset in range((period.end-period.start).days+1):
            day = str(period.start+timedelta(days=offset))
            row = by_day.get((cid, day))
            base = _time((required_after or {}).get(str(cid))) or period.due_at.replace(hour=0, minute=1)
            checked, source, generation = (_time((row or {}).get(key))
                for key in ("checked_at", "source_at", "source_generation"))
            # 완결 표시만으로는 누락·잘못된 지표의 대조 성공을 입증할 수 없다.
            proof = bool(row and row["basic_complete"] and row["conversion_complete"]
                and all(R._number(row.get(key)) for key in (*R.BASIC_FIELDS, *R.CONVERSION_FIELDS))
                and checked and source and generation and base <= generation <= checked <= now
                and source <= checked and source.date() >= generation.date() and R._collected(row, day, now))
            response_fresh = bool(row and checked and source and generation and base <= generation <= checked <= now
                and source <= checked and source.date() >= generation.date() and R._collected(row, day, now))
            if proof:
                proven.append(checked)
            relevant = [job for job in jobs if job["customer_id"] == cid and job["period_start"] <= day <= job["period_end"]]
            newest = latest_job(relevant)
            good = proof
            if newest:
                attempted = _time(newest.get("checked_at"))
                if attempted is None or attempted > now:
                    good = False
                    response_fresh = False
                else:
                    attempts.append(attempted)
                required = _time(newest.get("generation"))
                if required is None:
                    response_fresh = False
                if required and (generation is None or generation < required):
                    good = False
                    response_fresh = False
                if newest["status"] != "ok" and attempted is not None and attempted <= now and (checked is None or attempted >= checked):
                    good = False
                    response_fresh = False
                    failed = failed or newest["status"] in ("retry", "limited", "reauth_required")
            if any(request["customer_id"] == cid and request["period_start"] <= day <= request["period_end"] for request in queued):
                good = False
                response_fresh = False
            if not good:
                pending += 1
            response["expected_account_days"] += 1
            if not row or row.get("basic_complete") != 1 or not all(R._number(row.get(key)) for key in R.BASIC_FIELDS):
                response["basic_incomplete_account_days"] += 1
            elif not response_fresh:
                response["source_unverified_account_days"] += 1
            elif not all(R._number(row.get(key)) for key in R.CONVERSION_FIELDS):
                response["missing_or_null_account_days"] += 1
            else:
                response["received_account_days"] += 1
                response["zero_account_days" if all(row[key] == 0 for key in R.CONVERSION_FIELDS)
                         else "positive_account_days"] += 1
                if not row["conversion_complete"]:
                    basis_unconfirmed += 1
    status = "complete" if expected and not pending else "failed" if failed else "pending"
    if dirty and status == "complete":
        status = "updating"
    successes = [_time(prior.get("last_checked_at"))]
    if expected and len(proven) == len(expected)*((period.end-period.start).days+1):
        successes.append(min(proven))
    successful = [at for at in successes if at is not None and at <= now]
    source_attempts = [_time(row.get("checked_at")) for row in rows]
    source_attempts = [at for at in source_attempts if at is not None and at <= now]
    attempted = max(attempts) if len(attempts) > 0 else max(source_attempts, default=None)
    validation = {"status": status, "pending_account_days": pending,
        "last_checked_at": max(successful).isoformat() if successful else None,
        "last_attempt_at": attempted.isoformat() if attempted is not None else None}
    # 현재 원천의 숫자 응답 여부이며 측정 설정·산정 근거 또는 저장판 수치의 완결 판정이 아니다.
    response["status"] = ("complete" if response["expected_account_days"] > 0
        and response["received_account_days"] == response["expected_account_days"]
        else "partial" if response["received_account_days"] > 0 else "unavailable")
    issues = [{"code": code, "account_days": count} for code, count in (
        ("basic_incomplete", response["basic_incomplete_account_days"]),
        ("source_unverified", response["source_unverified_account_days"]),
        ("conversion_not_provided", response["missing_or_null_account_days"]),
        ("conversion_basis_unconfirmed", basis_unconfirmed)) if count > 0]
    return {"validation": validation, "source_collected_at": source_collected_at(rows, now),
        "conversion_response": response, "conversion_diagnosis": {"issues": issues}}
