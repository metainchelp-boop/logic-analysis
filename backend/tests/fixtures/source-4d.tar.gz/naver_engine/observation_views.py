"""Closed, private-ID-free operation projections; no provider calls or file access."""
import json
from naver_runtime import provider_observability as P

SAFE_INTEGER=2**53-1
def public_number(value):return value if type(value)is int and 0<=value<=SAFE_INTEGER else None

def public_estimate(value):
    return {key:(public_number(number) if key.endswith('_microusd') else number)
        for key,number in value.items() if key!='price_config_fingerprint'}


def provider_projection(reservations,rows,*,legacy=False):
    from .observation_store import WINDOW,PUBLIC_LIMIT
    selected=list(reservations[:WINDOW]);ids={row[0] for row in selected}
    traces={row[0]:row for row in rows if row[0] in ids}
    items=[];missing=0;incomplete=0;estimates=[];http=0;logical=0
    for job_id,reserved,at in selected:
        row=traces.get(job_id)
        trace=None
        try:trace=P.normalize_snapshot(json.loads(row[4])) if row and row[4] else None
        except Exception:pass
        trace_incomplete=False
        if trace is None:missing+=1
        else:
            phases=[event['phase'] for event in trace['events']]
            logical+=phases.count('logical_invoke');http+=phases.count('transport_attempt')
            trace_incomplete=trace['telemetry_incomplete'] or any(event['diagnostic']=='observer-failed' for event in trace['events'])
            incomplete+=int(trace_incomplete)
            estimates.append(trace['estimate'])
        item={'origin':row[1] if row else 'unobserved','period_key':row[5] if row else None,'reserved_at':at,'reserved_microusd':reserved,
            'telemetry_status':'missing' if trace is None else 'incomplete' if trace_incomplete else 'recorded',
            'events':trace['events'] if trace else [],'usage':trace['usage'] if trace else None,'estimate':public_estimate(trace['estimate']) if trace else None}
        # Sidecars are optional. Old traces and invalid/corrupt sidecars remain unknown.
        try:
            from . import strategy_validation as V
            from .observation_store import VALIDATION_LIMIT
            raw=row[6] if row and len(row)>6 else None
            if (trace is not None and isinstance(raw,str) and len(raw.encode('utf8'))<=VALIDATION_LIMIT
                    and not any(event['phase'] in {'document_validated','draft_saved'} for event in trace['events'])):
                summary=V.normalize(json.loads(raw))
                if any(event['phase']=='failure' and event['diagnostic']==P.diagnostic(V.ERROR_CODES[summary['rule']]) for event in trace['events']):
                    item['validation_summary']=summary
        except Exception:pass
        items.append(item)
    # Cost-field interpretation is supplied by the closed provider contract, never inferred from reservations.
    reserved=public_number(sum(row[1] for row in selected))
    known=[estimate['total_microusd'] for estimate in estimates if estimate['status']=='configured_estimate']
    subtotal=public_number(sum(known)) if known else None
    complete=bool(selected) and len(known)==len(selected) and not(missing or incomplete) and subtotal is not None
    overflow=reserved is None or bool(known) and subtotal is None or any(number is not None and public_number(number) is None for estimate in estimates for key,number in estimate.items() if key.endswith('_microusd'))
    return {'window_limit':WINDOW,'item_limit':PUBLIC_LIMIT,'window_calls':len(selected),
        'logical_calls':logical if not(missing or incomplete) else None,'known_logical_calls':logical,
        'http_attempts':http if not(missing or incomplete) else None,'known_http_attempts':http,
        'reserved_microusd':reserved,'estimated_microusd':subtotal if complete else None,
        'known_estimated_subtotal_microusd':subtotal,'estimate_complete':complete,'public_number_incomplete':bool(overflow),
        'telemetry_missing':missing,'telemetry_incomplete':incomplete,'invoice_verified':False,
        'coverage':{'scope':'current_actor_account','window_truncated':len(reservations)>WINDOW,
            'legacy_scope_unknown':legacy,'complete':not(missing or incomplete or legacy or len(reservations)>WINDOW or overflow)},
        'items':items[:PUBLIC_LIMIT]}
