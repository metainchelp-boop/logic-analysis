"""자동화 계획의 현재 담당·계정 범위. 조회는 수집·AI·광고 변경을 시작하지 않는다."""
import re
from app.naver_auto import matching as M, org_snapshot as O, scope as SC
from . import approval_documents as D, handles as H, inventory as I, report_views as RV, setup_checks as SETUP
from . import operating_criteria as CRITERIA


def ownership(ctx, company):
    pid = company["possibility_id"]
    return SC.ownership_for_client(ctx.org, pid, pid, SC.MATCH_PID)


def context(ctx, store, scope, selection="all"):
    catalog, state = I.catalog_status(store, ctx.now)
    if state != "accepted" or not O.allows_raising(ctx.freshness) or store.inventory_snapshot(ctx.now) is None:
        raise RV.SourceUnavailable()
    known = {r["possibility_id"]: r for r in catalog["items"] if r["stage_known"] and not r["stage_hidden"]}
    owns = {pid: ownership(ctx, row) for pid, row in known.items()}
    visible = SC.clients_in(ctx.org, scope, owns, selection)
    companies = {pid: row for pid, row in known.items() if pid in visible}
    try:
        matched, _ = I._matching(ctx, catalog, auto_evidence=I.automatic_evidence(store))
    except M.BadInput:
        raise RV.SourceUnavailable() from None
    pairs = {p.customer_id: p.possibility_id for p in matched.pairs}
    return companies, pairs


def resolve(ctx, store, scope, pid, key, selection="all"):
    companies, pairs = context(ctx, store, scope, selection)
    cids = [cid for cid, company in pairs.items() if company == pid and RV.account_key(cid) == key and cid in ctx.accounts]
    if pid not in companies or len(cids) != 1:
        raise SC.ClientNotVisible()
    return companies[pid], cids[0]


def view(ctx, store, scope, query, *, operator_enabled=False):
    if set(query) - {"selection", "q", "page", "possibility_id", "account_key"}:
        raise RV.QueryInvalid()
    page, search, selection = query.get("page", "0"), query.get("q", ""), query.get("selection", "all")
    if (not isinstance(page, str) or not re.fullmatch(r"0|[1-9][0-9]{0,5}", page)
            or not isinstance(search, str) or len(search) > 200 or any(ord(c) < 32 for c in search)):
        raise RV.QueryInvalid()
    if ("possibility_id" in query) != ("account_key" in query):
        raise RV.QueryInvalid()
    companies, pairs = context(ctx, store, scope, selection)
    rows = []
    for cid, pid in pairs.items():
        if pid not in companies or cid not in ctx.accounts:
            continue
        company, account = companies[pid], ctx.accounts[cid]
        row = {"possibility_id": pid, "account_key": RV.account_key(cid), "company_name": company["company_name"],
               "account_name": account["account_name"], "ad_account_no": str(account["ad_account_no"]) if account["ad_account_no"] is not None else None,
               "workflow": H.stage_key(company["stage"])}
        if search.casefold() in " ".join(str(row[k] or "") for k in ("company_name", "account_name", "ad_account_no")).casefold():
            rows.append(row)
    rows.sort(key=lambda r: (r["company_name"] or "", r["account_name"] or "", r["account_key"]))
    page = int(page)
    if page and page * 100 >= len(rows):
        raise RV.QueryInvalid()
    out = {"accounts": rows[page*100:(page+1)*100], "total": len(rows), "page": page, "page_size": 100,
           "next_page": page+1 if (page+1)*100 < len(rows) else None, "selection": None, "plan": None,
           "can_edit": False, "can_approve": False, "execution_enabled": False, "policy": dict(D.POLICY),
           "provider_status": dict(D.PROVIDER_STATUS)}
    if "possibility_id" not in query:
        return out
    pid = RV._number(query, "possibility_id")
    key = query["account_key"]
    if not isinstance(key, str) or not re.fullmatch(r"[0-9a-f]{64}", key):
        raise RV.QueryInvalid()
    cids = [cid for cid, company in pairs.items() if company == pid and RV.account_key(cid) == key and cid in ctx.accounts]
    if pid not in companies or len(cids) != 1:
        raise SC.ClientNotVisible()
    company, cid = companies[pid], cids[0]
    stage = H.stage_key(company["stage"])
    can_write = SC.ACT_APPROVE in SC.allowed_actions(ctx.org, scope, ownership(ctx, company))
    plan = store.automation_plan(pid, key)
    can_approve = can_write and stage in D.AUTO_STAGES
    if plan["approval_requires_lead"]:
        can_approve = can_approve and SC.can_approve(ctx.org, ownership(ctx, company), SC.LEVEL_LEAD,
            plan["author"]["actor"], scope.viewer_idx)
    projected = {"goal": plan["plan"]["goal"], "budget_plan": {"daily_budget": plan["plan"]["daily_spend_cap"]}}
    observation = store.setup_observation(cid, ctx.now)
    criteria = CRITERIA.assess(plan, ctx.now, CRITERIA.performance_from_observation(observation))
    if stage not in D.AUTO_STAGES:
        criteria["state"] = "hold"
        criteria["reasons"].append({"code": "CONTRACT_STAGE", "message": "현재 계약 단계에서는 자동 운영 판단을 보류합니다."})
        criteria["metric"].update(value=None, status="hold")
    out.update(selection={"possibility_id": pid, "account_key": key, "workflow": stage}, plan=plan,
               can_edit=can_write and stage in D.EDIT_STAGES, can_approve=can_approve,
               operating_criteria=criteria,
                existing_budget=SETUP.project_existing_budget(now=ctx.now, observation=observation),
               learning_assets=store.learning_assets(pid,key,now=ctx.now,allowed_pairs=[(p,RV.account_key(c)) for c,p in pairs.items() if p in companies and c in ctx.accounts and H.stage_key(companies[p]["stage"]) in D.EDIT_STAGES],can_edit=can_write and stage in D.EDIT_STAGES),
               setup_checks=SETUP.project_setup(now=ctx.now, structure=store.structure_checks([cid], ctx.now).get(cid),
                   plan=projected, observation=observation))
    from . import experiments as X
    catalog=X.candidate_catalog(observation,possibility_id=pid,customer_id=cid,account_key=key)
    out['execution']=store.execution_projection(pid,key,cid,ctx.now,plan,catalog,can_edit=can_write and stage in D.AUTO_STAGES,can_approve=can_approve,can_stop=SC.ACT_STOP in SC.allowed_actions(ctx.org,scope,ownership(ctx,company)),operator_enabled=operator_enabled)
    out['execution']['recovery_receipt']=None
    out['randomized_experiments']=store.randomized_projection(pid,key,scope.viewer_idx,ctx.now)
    out['randomized_experiments']['operator_enabled']=operator_enabled is True
    return out


def experiments_view(ctx,store,scope,query):
    """Selected-account saved state; no collection, file reads or writes."""
    from . import experiments as X
    if set(query)-{"possibility_id","account_key","experiment_id","request_id"} or not {"possibility_id","account_key"}<=set(query):
        raise RV.QueryInvalid()
    pid=RV._number(query,"possibility_id");key=query["account_key"];eid=query.get("experiment_id");request_id=query.get("request_id")
    if request_id is not None and (not isinstance(request_id,str) or not re.fullmatch(r"[0-9a-f]{32}",request_id)):
        raise RV.QueryInvalid()
    if not isinstance(key,str) or not re.fullmatch(r"[0-9a-f]{64}",key) or eid is not None and (not isinstance(eid,str) or not re.fullmatch(r"[0-9a-f]{32}",eid)):
        raise RV.QueryInvalid()
    company,cid=resolve(ctx,store,scope,pid,key)
    receipt=store.experiment_recovery_receipt(pid,key,scope.viewer_idx,request_id) if request_id is not None else None
    if receipt is not None:
        if eid is not None and eid!=receipt["experiment_id"]:raise RV.QueryInvalid()
        eid=receipt["experiment_id"]
    stage=H.stage_key(company["stage"]);own=ownership(ctx,company)
    can_edit=SC.ACT_APPROVE in SC.allowed_actions(ctx.org,scope,own) and stage in D.AUTO_STAGES
    plan=store.automation_plan(pid,key);observation=store.setup_observation(cid,ctx.now)
    catalog=X.candidate_catalog(observation,possibility_id=pid,customer_id=cid,account_key=key)
    can_approve=can_edit
    if plan["approval_requires_lead"]:
        can_approve=can_approve and SC.can_approve(ctx.org,own,SC.LEVEL_LEAD,plan["author"]["actor"],scope.viewer_idx)
    out=store.experiments_projection(pid,key,cid,ctx.now,plan,catalog,experiment_id=eid,can_edit=can_edit,can_approve=can_approve)
    out["source"].update(checked_at=(observation or {}).get("checked_at"),generation=(observation or {}).get("generation"))
    out["recovery_receipt"]=receipt
    return out


def randomized_experiments_view(ctx,store,scope,query,*,operator_enabled=False):
    """Saved randomized plans and proofs. Viewing never schedules or sends an ad change."""
    if set(query)-{'possibility_id','account_key','experiment_id','request_id'} or not {'possibility_id','account_key'}<=set(query):raise RV.QueryInvalid()
    pid=RV._number(query,'possibility_id');key=query['account_key'];eid=query.get('experiment_id');request_id=query.get('request_id')
    if (not isinstance(key,str) or not re.fullmatch(r'[0-9a-f]{64}',key)
            or eid is not None and (not isinstance(eid,str) or not re.fullmatch(r'[0-9a-f]{32}',eid))
            or request_id is not None and (not isinstance(request_id,str) or not re.fullmatch(r'[0-9a-f]{32}',request_id))):raise RV.QueryInvalid()
    resolve(ctx,store,scope,pid,key)
    out=store.randomized_projection(pid,key,scope.viewer_idx,ctx.now,experiment_id=eid,request_id=request_id)
    out['operator_enabled']=operator_enabled is True
    return out


def execution_view(ctx,store,scope,query,*,operator_enabled=False):
    """Small selected advertiser projection. Never performs HTTP or writes on GET."""
    from . import experiments as X
    if set(query)-{'possibility_id','account_key','resource_id','request_id'} or not {'possibility_id','account_key'}<=set(query):raise RV.QueryInvalid()
    pid=RV._number(query,'possibility_id');key=query['account_key'];rid=query.get('resource_id');request_id=query.get('request_id')
    if not isinstance(key,str) or not re.fullmatch(r'[0-9a-f]{64}',key) or any(x is not None and (not isinstance(x,str) or not re.fullmatch(r'[0-9a-f]{32}',x)) for x in (rid,request_id)):raise RV.QueryInvalid()
    company,cid=resolve(ctx,store,scope,pid,key);own=ownership(ctx,company)
    receipt=store.execution_recovery_receipt(pid,key,scope.viewer_idx,request_id) if request_id else None
    if receipt:
        if rid is not None and rid!=receipt['resource_id']:raise RV.QueryInvalid()
        rid=receipt['resource_id']
    actions=SC.allowed_actions(ctx.org,scope,own);stage=H.stage_key(company['stage'])
    can_edit=SC.ACT_APPROVE in actions and stage in D.AUTO_STAGES
    plan=store.automation_plan(pid,key);obs=store.setup_observation(cid,ctx.now)
    catalog=X.candidate_catalog(obs,possibility_id=pid,customer_id=cid,account_key=key)
    can_approve=can_edit
    if plan['approval_requires_lead']:can_approve=can_approve and SC.can_approve(ctx.org,own,SC.LEVEL_LEAD,plan['author']['actor'],scope.viewer_idx)
    out=store.execution_projection(pid,key,cid,ctx.now,plan,catalog,resource_id=rid,can_edit=can_edit,can_approve=can_approve,can_stop=SC.ACT_STOP in actions,operator_enabled=operator_enabled)
    out['recovery_receipt']=receipt;out['source'].update(checked_at=(obs or {}).get('checked_at'),generation=(obs or {}).get('generation'))
    return out


def learning_source_view(ctx,store,scope,query):
    """One actor-authorized immutable source and its separate annotation; GET never writes."""
    required={'possibility_id','account_key','asset_id'}
    if set(query)-required-{'request_id'} or not required<=set(query):raise RV.QueryInvalid()
    pid=RV._number(query,'possibility_id');key=query['account_key'];asset=query['asset_id'];token=query.get('request_id')
    if not isinstance(key,str) or not re.fullmatch(r'[0-9a-f]{64}',key) or not isinstance(asset,str) or not re.fullmatch(r'auto-(?:exp|exec)-[0-9a-f]{32}',asset) or token is not None and (not isinstance(token,str) or not re.fullmatch(r'[0-9a-f]{32}',token)):raise RV.QueryInvalid()
    companies,pairs=context(ctx,store,scope)
    cids=[cid for cid,p in pairs.items() if p==pid and RV.account_key(cid)==key and cid in ctx.accounts]
    if pid not in companies or len(cids)!=1:raise SC.ClientNotVisible()
    can_edit=SC.ACT_APPROVE in SC.allowed_actions(ctx.org,scope,ownership(ctx,companies[pid])) and H.stage_key(companies[pid]['stage']) in D.EDIT_STAGES
    allowed=[(p,RV.account_key(cid)) for cid,p in pairs.items() if p in companies and cid in ctx.accounts and H.stage_key(companies[p]['stage']) in D.EDIT_STAGES]
    item=store.learning_source_projection(pid,key,asset,ctx.now,allowed,can_edit=can_edit)
    receipt=store.learning_source_receipt(pid,key,asset,scope.viewer_idx,token) if token is not None else None
    return {'selection':{'possibility_id':pid,'account_key':key},'item':item,'recovery_receipt':receipt}
