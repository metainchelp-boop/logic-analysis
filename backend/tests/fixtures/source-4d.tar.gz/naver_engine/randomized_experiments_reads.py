"""Bounded GET-only hourly observations. No assignment, mutation, or zero filling."""
from collections import Counter
from copy import deepcopy
from dataclasses import dataclass,field
from datetime import timedelta
from time import monotonic
from . import randomized_experiments as R, handles as H, naver_read as N, inspection_fields as IF
from .randomized_experiments_store import JOB_FIELDS

SOURCE_FIELDS=JOB_FIELDS|{'started_at','index','rows','before','after','expected'}
TTL=timedelta(minutes=20)
class CheckpointInvalid(ValueError):pass
class ConfigurationChanged(ValueError):pass
@dataclass(frozen=True)
class Outcome:
    code:str
    counts:dict=field(default_factory=dict)

def _invalid():raise CheckpointInvalid('시간 통계의 범위·재개 원천이 다릅니다')

def validate_progress(source,job,now=None):
    from . import experiments as E
    try:
        if not isinstance(job,dict) or set(job)!=JOB_FIELDS or type(job['version'])is not int or job['version']!=1 or job['kind'] not in ('probe','observation'):_invalid()
        if not isinstance(source,dict) or set(source)!=SOURCE_FIELDS or any(type(source[k])is not type(job[k]) or source[k]!=job[k] for k in JOB_FIELDS):_invalid()
        if type(source['index'])is not int or not 0<=source['index']<=10:_invalid()
        started=R.moment(source['started_at'])
        if started<R.moment(job['requested_at']) or now is not None and started>R.moment(now):_invalid()
        for name in ('control','treatment'):E.normalize_arm(job['arms'][name],job['customer_id'])
        expected=source['expected']
        if not isinstance(expected,list) or not 4<=len(expected)<=54 or len({(a['kind'],a['id']) for a in expected})!=len(expected):_invalid()
        for arm in expected:E.normalize_arm(arm,job['customer_id'])
        for key in ('before','after'):
            parts=source[key]
            if not isinstance(parts,dict) or set(parts)-{'campaign','adgroup','ad','keyword'}:_invalid()
            for kind,rows in parts.items():
                if not isinstance(rows,list):_invalid()
                if rows!=[a['settings'] for a in expected if a['kind']==kind]:_invalid()
        for key in ('rows',):
            if not isinstance(source[key],dict) or set(source[key])-{'control','treatment'}:_invalid()
            for name,value in source[key].items():
                clean=R.normalize_hourly(value,now=now)
                if clean['customer_id']!=job['customer_id'] or clean['entity_id']!=job['arms'][name]['id'] or clean['day']!=job['day']:_invalid()
        index=source['index'];kinds=('campaign','adgroup','ad','keyword')
        if set(source['before'])!=set(kinds[:min(index,4)]) or set(source['after'])!=set(kinds[:max(0,index-6)]):_invalid()
        if set(source['rows'])!=set(('control','treatment')[:max(0,min(index-4,2))]):_invalid()
        if index==10:
            R.validate_probe(source['rows']['control'],source['rows']['treatment'],now or started)
            return deepcopy(source['rows'])
        return None
    except (KeyError,ValueError,TypeError,OverflowError):_invalid()

def _initial(job,expected,now):
    return dict(deepcopy(job),started_at=R.moment(now).isoformat(),index=0,rows={},before={},after={},expected=deepcopy(expected))

def _scope(reader,handle,source,kind):
    expected=[a for a in source['expected'] if a['kind']==kind]
    if kind=='campaign':parent=None
    elif kind=='adgroup':parent=next(a['id'] for a in source['expected'] if a['kind']=='campaign')
    else:parent=next(a['id'] for a in source['expected'] if a['kind']=='adgroup')
    rows,cursor=reader.get_setup_page(handle,kind,parent)
    reader.check_budget()
    if cursor is not None:raise ConfigurationChanged('범위 전수 응답이 미완결입니다')
    wanted={a['id'] for a in expected};actual=[];seen=set()
    if not isinstance(rows,list) or len(rows)>IF.MAX_ROWS:raise ConfigurationChanged()
    for raw in rows:
        row=IF.sanitize_record(kind,raw,source['customer_id'],parent);identifier=row[IF.IDS[kind]]
        if identifier in seen:raise ConfigurationChanged()
        seen.add(identifier)
        if kind in ('ad','keyword') and identifier not in wanted:raise ConfigurationChanged()
        if identifier in wanted:actual.append(row)
    byid={row[IF.IDS[kind]]:row for row in actual}
    ordered=[byid.get(a['id']) for a in expected]
    if ordered!=[a['settings'] for a in expected]:raise ConfigurationChanged()
    return ordered

def _read(reader,handle,store,job,clock,values):
    expected=store.randomized_expected_settings(job,clock());source=store.randomized_progress(job)
    if source is None:source=_initial(job,expected,clock())
    else:
        validate_progress(source,job,clock())
        if R.moment(clock())-R.moment(source['started_at'])>TTL or source['expected']!=expected:
            source=_initial(job,expected,clock())
    # A terminal successful source is only selected again by an explicit fresh request.
    if source['index']==10:source=_initial(job,expected,clock())
    store.record_randomized_progress(job,clock(),source)
    while source['index']<10:
        if not store.randomized_account_valid(job,clock()):raise H.NotEligible()
        if R.moment(clock())-R.moment(source['started_at'])>TTL:
            values.update(status='partial',error_code='REQUEST_DEADLINE');return
        index=source['index'];update=deepcopy(source)
        if index in (4,5):
            name=('control','treatment')[index-4]
            update['rows'][name]=R.normalize_hourly(reader.get_entity_stats_hourly(handle,job['arms'][name]['id'],R.day(job['day'])),now=clock())
            reader.check_budget()
        else:
            kind=('campaign','adgroup','ad','keyword')[index if index<4 else index-6]
            update['before' if index<4 else 'after'][kind]=_scope(reader,handle,source,kind)
        update['index']+=1;validate_progress(update,job,clock())
        store.record_randomized_progress(job,clock(),update);source=update;values['progressed']=True
    values.update(status='ok',error_code=None)

def run_randomized(reader,store,clock,*,limit=24,max_calls=6,max_seconds=20,per_account_calls=6,exclude_customers=()):
    from . import store as S
    if type(limit)is not int or not 1<=limit<=24 or type(max_calls)is not int or not 1<=max_calls<=6 or type(max_seconds)not in (int,float) or not 0<max_seconds<=20 or type(per_account_calls)is not int or not 1<=per_account_calls<=6:raise ValueError('읽기 예산이 다릅니다')
    excluded=set(exclude_customers)|set(reader.called_customers)
    if any(type(x)is not int or x<=0 for x in excluded):raise ValueError('제외 계정이 다릅니다')
    if reader.rate_limited:return Outcome('BUDGET')
    now=R.moment(clock());snapshot=store.inventory_snapshot(now)
    if snapshot is None:return Outcome('NOT_READY')
    initial=reader.calls;started=monotonic();counts=Counter();seen=set()
    with reader.bounded_requests(max_calls=max_calls,max_seconds=max_seconds):
        for job in store.randomized_work(now,limit):
            if job['customer_id'] in seen|excluded:continue
            if reader.calls-initial>=max_calls or monotonic()-started>=max_seconds:return Outcome('BUDGET',dict(counts))
            values={};seen.add(job['customer_id'])
            try:
                store.begin_randomized_check(job,clock())
                handle=H.issue_inventory_handle(customer_id=job['customer_id'],snapshot_at=snapshot,now=clock(),validate=lambda cid,snap,at:store.randomized_account_valid(job,at))
                with reader.bounded_requests(max_calls=min(per_account_calls,max_calls-(reader.calls-initial)),max_seconds=min(20,max_seconds-(monotonic()-started))):
                    _read(reader,handle,store,job,clock,values)
            except N.NaverApiError as exc:values.update(status='reauth_required' if exc.kind==N.KIND_KEY_REJECTED else 'retry',error_code=exc.kind)
            except ConfigurationChanged:values.update(status='limited',error_code='SETTINGS_CHANGED')
            except (CheckpointInvalid,R.RandomizedInvalid,N.StatsShapeUnknown):values.update(status='limited',error_code='CHECKPOINT_INVALID')
            except N.RunAbort as exc:values.update(status='partial' if values.get('progressed') else 'retry',error_code=exc.cause_code or exc.code)
            except (H.NotEligible,H.HandleInvalid,S.StoreRefused):return Outcome('SOURCE_CHANGED',dict(counts))
            except S.StoreError:raise
            except Exception:values.update(status='retry',error_code='UNEXPECTED')
            if not store.randomized_account_valid(job,clock()):return Outcome('SOURCE_CHANGED',dict(counts))
            try:status=store.record_randomized_check(job,clock(),values)
            except S.StoreRefused:return Outcome('SOURCE_CHANGED',dict(counts))
            counts[status]+=1
            if reader.rate_limited:return Outcome('BUDGET',dict(counts))
    return Outcome('DONE',dict(counts))
