"""Closed saved search samples: pure validation, selection and descriptive statistics.

No source I/O. The original paired observation/hash verification is the exporter's
responsibility. A complete collector sample is never the whole market.
"""
from copy import deepcopy
from datetime import datetime, timedelta
import hashlib
import json
import math
import re
import statistics
from uuid import UUID

from .product_evidence import KST, canonical_product, canonical_store

MAX_EXPORT_AGE = timedelta(hours=30)
MAX_OBSERVATION_AGE = timedelta(hours=72)
MAX_FUTURE = timedelta(minutes=5)
MAX_BUNDLE_BYTES = 5 * 1024 * 1024
DISPLAY_FIELDS = ("keyword", "source_status", "observed_at", "recorded_at", "sample_count",
                  "price_count", "price_min", "price_median", "price_max")
REASONS = frozenset({"ok", "not_linked", "not_found", "ambiguous", "no_observations", "stale", "invalid", "unavailable"})
_COHORT = frozenset({"product_key", "keyword", "recorded_at", "started_at", "observed_at",
                     "observation_id", "payload_hash", "surface", "sort", "device", "region", "filters", "samples"})
_MODEL = frozenset({"index", "keyword", "observed_at", "recorded_at", "sample_count", "price_count",
                    "price_min", "price_median", "price_max"})
_HEX = re.compile(r"[0-9a-f]{64}")


class EvidenceInvalid(ValueError):
    pass


def _bad():
    raise EvidenceInvalid("MARKET_EVIDENCE_INVALID")


def _moment(value):
    try:
        if isinstance(value, str):
            if len(value) > 50 or re.fullmatch(r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,6})?(?:Z|[+-]\d{2}:\d{2})", value) is None:
                return None
            value = datetime.fromisoformat(value)
        return value.astimezone(KST) if isinstance(value, datetime) and value.utcoffset() is not None else None
    except (ValueError, TypeError, OverflowError):
        return None


def _keyword(value):
    from .product_evidence import _text, EvidenceInvalid as ProductInvalid
    try:
        cleaned = _text(value)
    except ProductInvalid:
        _bad()
    if cleaned is None:
        _bad()
    return cleaned


def _number(value, *, integer=False):
    return type(value) in ((int,) if integer else (int, float)) and 1 <= value <= 10**12 and math.isfinite(value)


def _json(value):
    return json.dumps(value, ensure_ascii=False, allow_nan=False, sort_keys=True, separators=(",", ":"))


def _dates(cohort):
    start, observed, recorded = (_moment(cohort[key]) for key in ("started_at", "observed_at", "recorded_at"))
    if (start is None or observed is None or recorded is None or not timedelta(0) <= observed - start <= timedelta(hours=24)
            or not -MAX_FUTURE <= recorded - observed <= timedelta(hours=24)):
        _bad()
    return start, observed, recorded


def _cohort(value, store_key):
    if not isinstance(value, dict) or set(value) != _COHORT:
        _bad()
    product = value["product_key"]
    if (not isinstance(product, str) or canonical_product(product) != product or canonical_store(product) != store_key
            or value["surface"] != "naver_shopping_search" or value["sort"] not in (None, "rel")
            or any(value[key] is not None for key in ("device", "region", "filters"))
            or not isinstance(value["payload_hash"], str) or _HEX.fullmatch(value["payload_hash"]) is None):
        _bad()
    identifier = value["observation_id"]
    try:
        if not isinstance(identifier, str) or str(UUID(identifier)) != identifier:
            _bad()
    except (ValueError, TypeError, AttributeError):
        _bad()
    keyword = _keyword(value["keyword"])
    start, observed, recorded = _dates(value)
    samples = value["samples"]
    if not isinstance(samples, list) or not 1 <= len(samples) <= 1000:
        _bad()
    seen, clean = set(), []
    for row in samples:
        if (not isinstance(row, dict) or set(row) != {"key", "price"} or not isinstance(row["key"], str)
                or _HEX.fullmatch(row["key"]) is None or row["key"] in seen
                or row["price"] is not None and not _number(row["price"], integer=True)):
            _bad()
        seen.add(row["key"])
        clean.append(dict(row))
    return {**value, "keyword": keyword, "started_at": start.isoformat(), "observed_at": observed.isoformat(),
            "recorded_at": recorded.isoformat(), "samples": clean}


def validate_bundle(bundle, now):
    now = _moment(now)
    if now is None or not isinstance(bundle, dict) or set(bundle) != {"schema_version", "exported_at", "complete", "stores"}:
        _bad()
    exported = _moment(bundle["exported_at"])
    stores = bundle["stores"]
    if (type(bundle["schema_version"]) is not int or bundle["schema_version"] != 1 or bundle["complete"] is not True
            or exported is None or exported - now > MAX_FUTURE or not isinstance(stores, list) or len(stores) > 10000):
        _bad()
    seen, clean = set(), []
    for row in stores:
        if not isinstance(row, dict) or set(row) != {"store_key", "status", "cohorts"}:
            _bad()
        key, status, cohorts = row["store_key"], row["status"], row["cohorts"]
        if (not isinstance(key, str) or canonical_store(key) != key or key in seen
                or not isinstance(status, str) or status not in {"ok", "ambiguous", "no_observations"}
                or not isinstance(cohorts, list) or len(cohorts) > 1 or (status == "ok") != bool(cohorts)):
            _bad()
        seen.add(key)
        validated = [_cohort(value, key) for value in cohorts]
        for value in validated:
            observed, recorded = _moment(value["observed_at"]), _moment(value["recorded_at"])
            if any(at - bound > MAX_FUTURE for at in (observed, recorded) for bound in (exported, now)):
                _bad()
        clean.append({"store_key": key, "status": status, "cohorts": validated})
    result = {"schema_version": 1, "exported_at": exported.isoformat(), "complete": True, "stores": clean}
    if len(_json(result).encode()) > MAX_BUNDLE_BYTES:
        _bad()
    return result


def select(bundle, store_key, now):
    now = _moment(now)
    if now is None:
        _bad()
    key = canonical_store(store_key)
    status, at, cohorts = "not_linked", None, []
    if key is not None:
        if bundle is None:
            status = "unavailable"
        else:
            try:
                source = validate_bundle(bundle, now)
                at = source["exported_at"]
                if now - _moment(at) > MAX_EXPORT_AGE:
                    status = "stale"
                else:
                    row = next((row for row in source["stores"] if row["store_key"] == key), None)
                    if row is None:
                        status = "not_found"
                    elif row["status"] != "ok":
                        status = row["status"]
                    elif any(now - _moment(value[field]) > MAX_OBSERVATION_AGE
                             for value in row["cohorts"] for field in ("observed_at", "recorded_at")):
                        status = "stale"
                    else:
                        status, cohorts = "ready", row["cohorts"]
            except EvidenceInvalid:
                status, at, cohorts = "invalid", None, []
    fingerprint = hashlib.sha256(_json([status, key, cohorts]).encode()).hexdigest()
    return {"schema_version": 1, "status": status, "store_key": key, "exported_at": at,
            "source_fingerprint": fingerprint, "cohorts": deepcopy(cohorts)}


def normalize_context(value):
    if (not isinstance(value, dict) or set(value) != {"version", "state", "reason", "source_time_confirmed", "search_conditions_confirmed", "next_plan_only", "cohorts"}
            or type(value["version"]) is not int or value["version"] != 1
            or not isinstance(value["state"], str) or value["state"] not in {"stored_search_sample", "unavailable"}
            or not isinstance(value["reason"], str) or value["reason"] not in REASONS
            or value["source_time_confirmed"] is not False or value["search_conditions_confirmed"] is not False
            or value["next_plan_only"] is not True or not isinstance(value["cohorts"], list) or len(value["cohorts"]) > 1):
        _bad()
    ready = value["state"] == "stored_search_sample"
    if ready != (value["reason"] == "ok") or ready != bool(value["cohorts"]):
        _bad()
    clean = []
    for row in value["cohorts"]:
        if (not isinstance(row, dict) or set(row) != _MODEL or type(row["index"]) is not int or row["index"] != 1
                or type(row["sample_count"]) is not int or not 1 <= row["sample_count"] <= 1000
                or type(row["price_count"]) is not int or not 0 <= row["price_count"] <= row["sample_count"]):
            _bad()
        keyword, observed, recorded = _keyword(row["keyword"]), _moment(row["observed_at"]), _moment(row["recorded_at"])
        if (observed is None or recorded is None or not -MAX_FUTURE <= recorded - observed <= timedelta(hours=24)):
            _bad()
        minimum, median, maximum = (row[key] for key in ("price_min", "price_median", "price_max"))
        if not row["price_count"]:
            if any(v is not None for v in (minimum, median, maximum)):
                _bad()
        elif (not _number(minimum, integer=True) or not _number(maximum, integer=True) or not _number(median)
                or not minimum <= median <= maximum or median * 2 != int(median * 2)
                or row["price_count"] == 1 and not minimum == median == maximum
                or row["price_count"] == 2 and median != (minimum + maximum) / 2):
            _bad()
        clean.append({**row, "keyword": keyword, "observed_at": observed.isoformat(), "recorded_at": recorded.isoformat()})
    return {**value, "cohorts": clean}


def model_context(selection):
    if (not isinstance(selection, dict) or not isinstance(selection.get("status"), str)
            or selection["status"] not in REASONS | {"ready"} or not isinstance(selection.get("cohorts"), list)):
        _bad()
    ready = selection["status"] == "ready"
    if ready != bool(selection["cohorts"]) or len(selection["cohorts"]) > 1:
        _bad()
    result = []
    for raw in selection["cohorts"]:
        if not isinstance(raw, dict) or not isinstance(raw.get("product_key"), str):
            _bad()
        row = _cohort(raw, canonical_store(raw["product_key"]))
        prices = sorted(sample["price"] for sample in row["samples"] if sample["price"] is not None)
        result.append({"index": 1, "keyword": row["keyword"], "observed_at": row["observed_at"], "recorded_at": row["recorded_at"],
            "sample_count": len(row["samples"]), "price_count": len(prices), "price_min": min(prices) if prices else None,
            "price_median": statistics.median(prices) if prices else None, "price_max": max(prices) if prices else None})
    return normalize_context({"version": 1, "state": "stored_search_sample" if ready else "unavailable",
        "reason": "ok" if ready else selection["status"], "source_time_confirmed": False,
        "search_conditions_confirmed": False, "next_plan_only": True, "cohorts": result})


def display(context, index, field):
    value = normalize_context(context)
    if type(index) is not int or index != 1 or not value["cohorts"] or field not in DISPLAY_FIELDS:
        _bad()
    row = value["cohorts"][0]
    prefix = "저장 검색 표본의 "
    if field == "source_status":
        return ("저장된 네이버 쇼핑 검색 표본 · 다음 운영계획용 · 수집 종료 시각은 클라이언트 기록 기준 · "
                "기기·지역·필터 및 규격·옵션·배송비·쿠폰 비교 조건 미확인 · 전체 시장·광고경쟁·성과 변화의 원인으로 해석하지 않음")
    if field == "keyword":
        return prefix + "검색어 ‘" + row[field] + "’"
    if field in {"observed_at", "recorded_at"}:
        return prefix + ("수집 종료 기록 " if field == "observed_at" else "서버 저장 시각 ") + _moment(row[field]).strftime("%Y-%m-%d %H:%M KST")
    if field in {"sample_count", "price_count"}:
        return prefix + ("검색 결과 항목 " if field == "sample_count" else "양수 표시가격 확인 항목 ") + f"{row[field]:,}개"
    if row[field] is None:
        _bad()
    labels = {"price_min": "최소 표시가격 ", "price_median": "표시가격 중앙값 ", "price_max": "최대 표시가격 "}
    return prefix + labels[field] + f"{row[field]:,}원"
