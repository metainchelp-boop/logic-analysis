"""Sealed, default-off advertising writes. No mutation retry, redirect or proxy.

HTTP acceptance is not confirmation. A separate exact-ID GET is mandatory.
Source read handles cannot authorize a write and no arbitrary path/body is accepted.
"""
from copy import deepcopy
from datetime import timedelta
import base64
import hashlib
import hmac
import json
import math
import re
import secrets
import threading
import urllib.parse
import urllib.request

from . import execution_commands as E, inspection_fields as IF
from .credentials import ManagerCredentials
from .naver_read import UrllibTransport, SystemClock, RequestPacer, parse_stats

HOST = 'https://api.searchad.naver.com'
MAX_BODY = 2*1024*1024
_SEAL = secrets.token_bytes(32)
_TOKEN = object()
_USED = {}
_MUTATIONS = {}
_LOCK = threading.Lock()
_PACER = RequestPacer()
_PATHS = {'campaign':'/ncc/campaigns', 'adgroup':'/ncc/adgroups', 'keyword':'/ncc/keywords', 'ad':'/ncc/ads'}


def _mutation(c):
    action,p=c['action'],deepcopy(c['payload'])
    if action.startswith('create_'):
        kind={'create_campaign':'campaign','create_adgroup':'adgroup','create_keyword':'keyword','create_text_ad':'ad'}[action]
        query={'nccAdgroupId':c['parent']['id']} if kind=='keyword' else None
        return kind,'POST',_PATHS[kind],query,[p] if kind=='keyword' else p
    kind=c['target']['kind']
    body={IF.IDS[kind]:c['target']['id'],'customerId':c['scope']['customer_id'],**p}
    if kind!='campaign':body[IF.PARENTS[kind]]=c['target']['parent_id']
    return kind,'PUT',_PATHS[kind]+'/'+c['target']['id'],{'fields':{'update_bid':'bidAmt','update_daily_budget':'budget','set_user_lock':'userLock'}[action]},body


class WriteBlocked(ValueError):
    pass


class _Handle:
    __slots__ = ('_payload','_expires','_validate','_phase','_nonce','_mac')
    def __init__(self, token, payload, expires, validate, phase):
        if token is not _TOKEN: raise WriteBlocked('서버 실행 승인 핸들이 필요합니다')
        object.__setattr__(self,'_payload',deepcopy(payload))
        object.__setattr__(self,'_expires',expires)
        object.__setattr__(self,'_validate',validate)
        object.__setattr__(self,'_phase',phase)
        object.__setattr__(self,'_nonce',secrets.token_hex(16))
        object.__setattr__(self,'_mac',self._signature())
    def _signature(self):
        raw = E.fingerprint([self._payload,self._expires.isoformat(),self._phase,self._nonce]).encode()
        return hmac.new(_SEAL,raw,hashlib.sha256).digest()
    def __setattr__(self,name,value): raise AttributeError('실행 핸들은 변경할 수 없습니다')
    def __repr__(self): return self.__class__.__name__+'(sealed)'
    def __reduce__(self): raise TypeError('실행 핸들은 직렬화할 수 없습니다')


class CommandHandle(_Handle): pass
class ChannelsHandle(_Handle): pass
class SpendHandle(_Handle): pass
class EvidenceHandle(_Handle): pass


def _issue(cls,payload,now,expires_at,validate,phase):
    now, end = E.parse_moment(now),E.parse_moment(expires_at)
    if not callable(validate) or not timedelta(0) < end-now <= timedelta(seconds=60): raise WriteBlocked('짧은 실행 승인과 현재 권한 확인이 필요합니다')
    return cls(_TOKEN,payload,end,validate,phase)


def issue_command_handle(command, *, now, expires_at, validate, phase='dispatch'):
    if phase not in ('preflight','dispatch','reconcile'): raise WriteBlocked('실행 단계가 올바르지 않습니다')
    return _issue(CommandHandle,E.validate_command(command),now,expires_at,validate,phase)


def issue_channels_handle(scope, *, now, expires_at, validate):
    return _issue(ChannelsHandle,E._scope(scope),now,expires_at,validate,'channels')


def issue_spend_handle(scope, period_start, *, now, expires_at, validate):
    start, now = E._day(period_start),E.parse_moment(now)
    if start > now.date() or (now.date()-start).days > 366: raise WriteBlocked('위험 지출 조회 기간을 확인해 주세요')
    return _issue(SpendHandle,dict(scope=E._scope(scope),period_start=period_start),now,expires_at,validate,'spend')


def issue_evidence_handle(binding,target_key,period_start,period_end,*,now,expires_at,validate,epochs=None):
    b=E.validate_binding(binding); now=E.parse_moment(now); start,end=E._day(period_start),E._day(period_end)
    if (end>=now.date() or (end-start).days+1!=b['document']['evaluation_window_days']
            or start<E._day(b['document']['operation_start']) or end>E._day(b['document']['operation_end'])): raise WriteBlocked('완결 평가 기간을 확인해 주세요')
    ep=E._epoch(b,target_key,epochs)
    return _issue(EvidenceHandle,dict(binding=b,target_key=target_key,epoch=ep,period_start=period_start,period_end=period_end),now,expires_at,validate,'evidence')


def _json(raw):
    if not isinstance(raw,bytes) or len(raw)>MAX_BODY: raise WriteBlocked('응답 크기를 확인하지 못했습니다')
    def pairs(rows):
        out={}
        for k,v in rows:
            if k in out: raise ValueError()
            out[k]=v
        return out
    def constant(_): raise ValueError()
    try: return json.loads(raw.decode('utf-8'),object_pairs_hook=pairs,parse_constant=constant)
    except (ValueError,UnicodeError,RecursionError): raise WriteBlocked('응답 형식을 확인하지 못했습니다') from None


class NaverWrite:
    def __init__(self,credentials,*,enabled=False,transport=None,clock=None,pacer=None,max_calls=6,max_seconds=20):
        if not isinstance(credentials,ManagerCredentials) or type(enabled) is not bool or type(max_calls) is not int or not 1<=max_calls<=6 or type(max_seconds) not in (int,float) or not 0<max_seconds<=20: raise WriteBlocked('실행 설정이 올바르지 않습니다')
        self._credentials,self._enabled=credentials,enabled
        self._transport,self._clock=transport,clock or SystemClock()
        self._pacer=pacer if pacer is not None else _PACER
        self._max_calls,self._max_seconds=max_calls,max_seconds
        self.calls=0; self._start=None
        self._preflight_cache={}
    def __repr__(self): return 'NaverWrite(enabled='+str(self._enabled)+', calls='+str(self.calls)+')'
    def share_pacing(self,pacer):
        if not isinstance(pacer,RequestPacer) or self.calls and self._pacer is not pacer:raise WriteBlocked('호출 후 공유 간격을 바꿀 수 없습니다')
        self._pacer=pacer
        return self
    def _gate(self,handle,cls,phase,*,consume=False):
        try:sealed=type(handle) is cls and handle._phase==phase and hmac.compare_digest(handle._mac,handle._signature())
        except Exception:sealed=False
        if not sealed:raise WriteBlocked('서버 실행 승인 핸들이 필요합니다')
        now=E.parse_moment(self._clock.now())
        try:valid=now<handle._expires and handle._validate() is True
        except Exception:valid=False
        if not valid: raise WriteBlocked('실행 승인·현재 권한이 만료되었습니다')
        if phase=='dispatch' and not self._enabled: raise WriteBlocked('광고 실행 기능이 꺼져 있습니다')
        with _LOCK:
            for key,expiry in tuple(_USED.items()):
                if expiry<=now: _USED.pop(key,None)
            if handle._nonce in _USED: raise WriteBlocked('이미 사용한 핸들은 다시 실행할 수 없습니다')
            if consume: _USED[handle._nonce]=handle._expires
        return deepcopy(handle._payload)
    def _request(self,handle,cls,phase,cid,path,query=None,method='GET',body=None):
        self._gate(handle,cls,phase)
        if self._start is None: self._start=self._clock.monotonic()
        if self.calls>=self._max_calls or self._clock.monotonic()-self._start>=self._max_seconds: raise WriteBlocked('실행 조회 예산을 넘었습니다')
        if method not in ('GET','POST','PUT') or re.fullmatch(r'/(?:stats|ncc/(?:campaigns|adgroups|keywords|ads)(?:/[A-Za-z0-9_-]{1,100})?|ncc/channels)',path) is None: raise WriteBlocked('허용하지 않은 실행 경로입니다')
        if method!='GET':
            if cls is not CommandHandle or phase!='dispatch':raise WriteBlocked('읽기 핸들로 광고를 변경할 수 없습니다')
            _,expected_method,expected_path,expected_query,expected_body=_mutation(handle._payload)
            if (method,path,query,body)!=(expected_method,expected_path,expected_query,expected_body):raise WriteBlocked('승인한 정확 명령만 송신할 수 있습니다')
        self._pacer.pace(self._clock,self._clock.sleep)
        self._gate(handle,cls,phase)
        remaining=self._max_seconds-(self._clock.monotonic()-self._start)
        if remaining<=0: raise WriteBlocked('실행 조회 시간이 지났습니다')
        if method!='GET':
            command=handle._payload
            identity=(command['scope']['customer_id'],command['command_id'])
            # Defense in depth within this process. The durable Store dispatched state
            # is authoritative across process restarts; never auto-issue another POST.
            with _LOCK:
                if identity in _MUTATIONS: raise WriteBlocked('이미 송신한 명령은 재송신하지 않습니다')
                _MUTATIONS[identity]=True
        stamp=str(self._clock.epoch_ms())
        signature=base64.b64encode(self._credentials.secret_key.mac((stamp+'.'+method+'.'+path).encode())).decode('ascii')
        url=HOST+path+('?' + urllib.parse.urlencode(query,doseq=True) if query else '')
        data=None if body is None else json.dumps(body,ensure_ascii=False,separators=(',',':'),allow_nan=False).encode('utf-8')
        req=urllib.request.Request(url,data=data,method=method,headers={'X-Timestamp':stamp,'X-API-KEY':self._credentials.api_key.reveal(),
            'X-Customer':str(cid),'X-Signature':signature,'Content-Type':'application/json; charset=UTF-8'})
        self.calls+=1
        transport=self._transport
        if transport is None: transport=self._transport=UrllibTransport()
        try:
            status,raw=transport.send(req,timeout=min(remaining,10))
            if type(status) is not int or not 100<=status<=599: return 0,None
            if not 200<=status<300: return status,None
            return status,_json(raw)
        except Exception:
            # Never leak raw server error text or credential-bearing request objects.
            return 0,None
    def _row(self,handle,phase,arm):
        if arm is None: return None
        status,row=self._request(handle,CommandHandle,phase,handle._payload['scope']['customer_id'],_PATHS[arm['kind']]+'/'+arm['id'])
        if status!=200 or not isinstance(row,dict): raise WriteBlocked('현재 설정을 조회하지 못했습니다')
        return row
    def _preflight(self,handle,phase):
        c=self._gate(handle,CommandHandle,phase)
        if c['approval_ref']['kind'] == 'randomized_experiment':
            group=c['parent'];campaign=next(a for a in c['activation_snapshot'] if a['kind']=='campaign')
            proof=dict(adgroup=self._row(handle,phase,group),campaign=self._row(handle,phase,campaign))
            for key,path in (('ads','/ncc/ads'),('keywords','/ncc/keywords')):
                status,rows=self._request(handle,CommandHandle,phase,c['scope']['customer_id'],path,{'nccAdgroupId':group['id']})
                if status!=200 or not isinstance(rows,list) or len(rows)>50:raise WriteBlocked('실험 대상 전수 원천이 필요합니다')
                proof[key]=rows
            targets=[r for r in proof['ads'] if isinstance(r,dict) and r.get('nccAdId')==c['target']['id']]
            if len(targets)!=1:raise WriteBlocked('정확한 실험 소재를 확인하지 못했습니다')
            out=dict(target=targets[0],parent=proof['adgroup'],channels=[],randomized_scope=proof)
            E.verify_preflight(c,out)
            return out
        out=dict(target=self._row(handle,phase,c['target']),parent=self._row(handle,phase,c['parent']),channels=[])
        if c['action']=='create_adgroup':
            status,rows=self._request(handle,CommandHandle,phase,c['scope']['customer_id'],'/ncc/channels')
            if status!=200 or not isinstance(rows,list) or len(rows)>100: raise WriteBlocked('SITE 채널을 확인하지 못했습니다')
            out['channels']=rows
        if c['action']=='set_user_lock' and c['payload']['userLock'] is False and c['target']['kind'] in ('campaign','adgroup'):
            proof=dict(adgroups=[],keywords=[],ads=[])
            if c['target']['kind']=='campaign':
                status,groups=self._request(handle,CommandHandle,phase,c['scope']['customer_id'],'/ncc/adgroups',{'nccCampaignId':c['target']['id']})
                if status!=200 or not isinstance(groups,list) or len(groups)!=1:raise WriteBlocked('그룹 1개 전수 확인 범위를 벗어났습니다')
                proof['adgroups']=groups;group=groups[0].get('nccAdgroupId')
            else:group=c['target']['id']
            if not IF.valid_id(group,'adgroup'):raise WriteBlocked()
            for key,path in (('keywords','/ncc/keywords'),('ads','/ncc/ads')):
                status,rows=self._request(handle,CommandHandle,phase,c['scope']['customer_id'],path,{'nccAdgroupId':group})
                if status!=200 or not isinstance(rows,list) or len(rows)>50:raise WriteBlocked()
                proof[key]=rows
            out['activation']=proof
        E.verify_preflight(c,out)
        return out
    def preflight(self,handle):
        try:
            result=self._preflight(handle,'preflight')
            self._preflight_cache[handle._payload['command_id']]=(E.fingerprint(handle._payload),self._clock.monotonic(),deepcopy(result))
            self._gate(handle,CommandHandle,'preflight',consume=True)
            return dict(state='ready',preflight=result,reason_codes=[])
        except (WriteBlocked,E.ExecutionInvalid,ValueError,TypeError,KeyError):
            return dict(state='hold',preflight=None,reason_codes=['PREFLIGHT_UNAVAILABLE_OR_CHANGED'])
    def execute(self,handle):
        attempted=False
        try:
            c=self._gate(handle,CommandHandle,'dispatch')
            cache=self._preflight_cache.get(c['command_id'])
            activation=(c['action']=='set_user_lock' and c['payload']['userLock'] is False and c['target']['kind'] in ('campaign','adgroup')) or c['approval_ref']['kind']=='randomized_experiment'
            if activation and cache and cache[0]==E.fingerprint(c) and 0<=self._clock.monotonic()-cache[1]<=5:
                proof=deepcopy(cache[2]);proof['target']=self._row(handle,'dispatch',c['target']);E.verify_preflight(c,proof)
            else:self._preflight(handle,'dispatch')
            action=c['action']
            kind,method,path,query,body=_mutation(c)
            attempted=True
            status,result=self._request(handle,CommandHandle,'dispatch',c['scope']['customer_id'],path,query,method,body)
            self._gate(handle,CommandHandle,'dispatch',consume=True)
            if status in (400,401,403,404,422): return dict(state='rejected',result_id=None,error_code='PLATFORM_REJECTED')
            if not 200<=status<300 or result is None: return dict(state='unknown',result_id=None,error_code='OUTCOME_UNKNOWN')
            if kind=='keyword' and action.startswith('create_'):
                if not isinstance(result,list) or len(result)!=1: return dict(state='unknown',result_id=None,error_code='RESULT_ID_UNKNOWN')
                result=result[0]
            identifier=result.get(IF.IDS[kind]) if isinstance(result,dict) else None
            if not IF.valid_id(identifier,kind) or c['target'] is not None and identifier!=c['target']['id']: return dict(state='unknown',result_id=None,error_code='RESULT_ID_UNKNOWN')
            return dict(state='accepted',result_id=identifier,error_code=None)
        except (WriteBlocked,E.ExecutionInvalid,ValueError,TypeError,KeyError):
            return dict(state='unknown' if attempted else 'rejected',result_id=None,error_code='OUTCOME_UNKNOWN' if attempted else 'PREFLIGHT_OR_APPROVAL_BLOCKED')
    def reconcile(self,handle,created_id=None):
        try:
            c=self._gate(handle,CommandHandle,'reconcile')
            kind={'create_campaign':'campaign','create_adgroup':'adgroup','create_keyword':'keyword','create_text_ad':'ad'}.get(c['action'],c['target']['kind'] if c['target'] else None)
            identifier=c['target']['id'] if c['target'] else created_id
            if not IF.valid_id(identifier,kind): raise WriteBlocked('생성 ID가 확인되지 않아 재조회만 보류합니다')
            status,row=self._request(handle,CommandHandle,'reconcile',c['scope']['customer_id'],_PATHS[kind]+'/'+identifier)
            self._gate(handle,CommandHandle,'reconcile',consume=True)
            if status!=200 or not isinstance(row,dict): raise WriteBlocked()
            # Do not persist the private row; Store runs the pure closed readback validator.
            return dict(state='ready',readback=row,error_code=None)
        except (WriteBlocked,E.ExecutionInvalid,ValueError,TypeError,KeyError):
            return dict(state='unknown',readback=None,error_code='READBACK_UNAVAILABLE')
    def get_channels(self,handle):
        try:
            scope=self._gate(handle,ChannelsHandle,'channels')
            status,rows=self._request(handle,ChannelsHandle,'channels',scope['customer_id'],'/ncc/channels')
            if status!=200 or not isinstance(rows,list) or len(rows)>100: raise WriteBlocked()
            out,seen=[],set()
            for row in rows:
                if not isinstance(row,dict) or row.get('customerId')!=scope['customer_id'] or not IF.valid_id(row.get('nccBusinessChannelId')) or row['nccBusinessChannelId'] in seen: raise WriteBlocked()
                seen.add(row['nccBusinessChannelId'])
                if row.get('channelTp')!='SITE': continue
                name=E._text(row.get('name'),100)
                key=E._url(row.get('channelKey'))
                if row.get('status') not in ('ELIGIBLE','LIMITED_ELIGIBLE','DELETED','PAUSED'): raise WriteBlocked()
                out.append(dict(id=row['nccBusinessChannelId'],customer_id=scope['customer_id'],type='SITE',name=name,status=row['status'],channel_key=key,source_at=E.parse_moment(self._clock.now()).isoformat()))
            self._gate(handle,ChannelsHandle,'channels',consume=True)
            return dict(state='ready',channels=out,reason_codes=[])
        except (WriteBlocked,E.ExecutionInvalid,ValueError,TypeError,KeyError): return dict(state='unknown',channels=[],reason_codes=['CHANNELS_UNAVAILABLE'])
    def get_spend(self,handle):
        try:
            payload=self._gate(handle,SpendHandle,'spend'); scope=payload['scope']; now=E.parse_moment(self._clock.now())
            def campaigns():
                status,rows=self._request(handle,SpendHandle,'spend',scope['customer_id'],'/ncc/campaigns')
                if status!=200 or not isinstance(rows,list) or len(rows)>100: raise WriteBlocked()
                arms=[]; seen=set()
                for row in rows:
                    a=E._row_arm(row,'campaign',scope['customer_id'])
                    if a['id'] in seen: raise WriteBlocked()
                    seen.add(a['id']); arms.append(a)
                return sorted(arms,key=lambda a:a['id'])
            before=campaigns()
            if not before: raise WriteBlocked('전체 광고비의 빈 응답은 0으로 확정하지 않습니다')
            ids=[a['id'] for a in before]; ranges={}; cycles=[]
            for label,start in (('daily_spend',now.date().isoformat()),('monthly_spend',now.date().replace(day=1).isoformat()),('risk_spend',payload['period_start'])):
                if start not in ranges:
                    status,result=self._request(handle,SpendHandle,'spend',scope['customer_id'],'/stats',{'ids':ids,'fields':json.dumps(['salesAmt']),
                        'timeRange':json.dumps({'since':start,'until':now.date().isoformat()})})
                    if status!=200: raise WriteBlocked()
                    parsed=parse_stats(result,ids,('salesAmt',),now.date())
                    if parsed.missing_ids or parsed.cycle_base_tm is None or any(not E._number(r['salesAmt'],0,9e15) for r in parsed.rows.values()): raise WriteBlocked()
                    cycle=E.parse_moment(parsed.cycle_base_tm)
                    if not timedelta(0)<=now-cycle<=timedelta(minutes=30): raise WriteBlocked()
                    cycles.append(cycle); ranges[start]=sum(r['salesAmt'] for r in parsed.rows.values())
            if campaigns()!=before: raise WriteBlocked('조회 중 캠페인 설정이 바뀌었습니다')
            result=dict(status='ok',customer_id=scope['customer_id'],source_at=min(cycles).isoformat(),day=now.date().isoformat(),month=now.strftime('%Y-%m'),
                daily_spend=ranges[now.date().isoformat()],monthly_spend=ranges[now.date().replace(day=1).isoformat()],risk_spend=ranges[payload['period_start']],risk_period_start=payload['period_start'],budget_unit='unknown',bid_cap_unit='unknown',
                campaigns=[dict(id=a['id'],daily_budget=a['settings'].get('dailyBudget'),use_daily_budget=a['settings'].get('useDailyBudget'),
                    shared_budget=False if a['settings'].get('sharedBudgetId') is None and 'sharedBudgetId' in a['settings'] else None) for a in before])
            if any(not math.isfinite(result[k]) or result[k]>9e15 for k in ('daily_spend','monthly_spend','risk_spend')): raise WriteBlocked()
            self._gate(handle,SpendHandle,'spend',consume=True)
            return dict(state='ready',spend=result,error_code=None)
        except Exception:
            return dict(state='unknown',spend=None,error_code='SPEND_UNAVAILABLE')
    def get_evidence(self,handle):
        try:
            payload=self._gate(handle,EvidenceHandle,'evidence'); b=payload['binding']; cid=b['scope']['customer_id']; ep=payload['epoch']
            parent=b['parents'].get(payload['target_key']); target=ep['target']; now=E.parse_moment(self._clock.now())
            def settings(arm):
                if arm is None:return None
                status,row=self._request(handle,EvidenceHandle,'evidence',cid,_PATHS[arm['kind']]+'/'+arm['id'])
                if status!=200:raise WriteBlocked()
                actual=E._row_arm(row,arm['kind'],cid,arm['parent_id'],arm['campaign_id'])
                if actual!=arm:raise WriteBlocked()
                return actual
            before=(settings(target),settings(parent))
            status,result=self._request(handle,EvidenceHandle,'evidence',cid,'/stats',{'ids':[target['id']],'fields':json.dumps(list(E.X.FIELDS)),
                'timeRange':json.dumps({'since':payload['period_start'],'until':payload['period_end']})})
            if status!=200:raise WriteBlocked()
            parsed=parse_stats(result,[target['id']],E.X.FIELDS,E._day(payload['period_end']))
            if parsed.missing_ids or parsed.cycle_base_tm is None:raise WriteBlocked()
            source=E.parse_moment(parsed.cycle_base_tm)
            if not E.timedelta(0)<=now-source<=E.timedelta(minutes=b['document']['stop']['source_max_age_minutes']):raise WriteBlocked()
            if before!=(settings(target),settings(parent)):raise WriteBlocked()
            fields=parsed.rows[target['id']]
            for name in ('impCnt','clkCnt'):
                if fields[name] is not None and (type(fields[name]) not in (int,float) or not float(fields[name]).is_integer()):raise WriteBlocked()
                if fields[name] is not None:fields[name]=int(fields[name])
            boundary=E.datetime.combine(E._day(payload['period_end'])+E.timedelta(days=1),E.time(),E.OC.KST)
            lag=max(-1,(source-boundary).days)
            if lag<b['plan']['measurement_lag_days']:raise WriteBlocked()
            evidence=dict(status='ok',customer_id=cid,target_key=payload['target_key'],config_epoch=ep['epoch'],
                period_start=payload['period_start'],period_end=payload['period_end'],source_at=source.isoformat(),configuration_verified=True,
                fields=fields,conversion_definition='platform_all_conversions',value_basis='platform_conversion_value',minimum_source_lag_days=lag)
            self._gate(handle,EvidenceHandle,'evidence',consume=True)
            return dict(state='ready',evidence=evidence,error_code=None)
        except Exception:return dict(state='unknown',evidence=None,error_code='ENTITY_EVIDENCE_UNAVAILABLE')
