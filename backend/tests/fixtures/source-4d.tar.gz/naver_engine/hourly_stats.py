"""Exact single-date hourly CTR source. Missing buckets never become zeros."""
from datetime import date, datetime, timedelta, timezone
from decimal import Decimal
import math
import re

FIELDS = ('impCnt', 'clkCnt', 'salesAmt')
KST = timezone(timedelta(hours=9))

class HourlyInvalid(ValueError):
    pass


def parse_hourly(body, *, customer_id, entity_id, day, now):
    if type(day) is not date or not isinstance(now, datetime) or now.utcoffset() is None:
        raise HourlyInvalid('scope')
    if not isinstance(body, dict): raise HourlyInvalid('shape')
    wrappers = [key for key in ('summaryStatResponse', 'dailyStatResponse') if key in body]
    if wrappers:
        if wrappers != ['summaryStatResponse'] or not isinstance(body['summaryStatResponse'], dict): raise HourlyInvalid('shape')
        body = body['summaryStatResponse']
    rows = body.get('data')
    if not isinstance(rows, list) or len(rows) != 1 or not isinstance(rows[0], dict): raise HourlyInvalid('rows')
    row = rows[0]
    if row.get('id') != entity_id or 'customerId' in row and row['customerId'] != customer_id: raise HourlyInvalid('identity')
    def metrics(value):
        out = {}
        for key in FIELDS:
            number = value.get(key)
            if type(number) not in (int, float) or not math.isfinite(number) or not 0 <= number <= 10**15:
                raise HourlyInvalid('metrics')
            if key != 'salesAmt' and (type(number) is not int): raise HourlyInvalid('counts')
            out[key] = number
        if out['clkCnt'] > out['impCnt']: raise HourlyInvalid('counts')
        return out
    summary = metrics(row)
    buckets = row.get('breakdowns')
    if not isinstance(buckets, list) or len(buckets) != 24: raise HourlyInvalid('coverage')
    labels = [b.get('name') if isinstance(b, dict) else None for b in buckets]
    plain = {str(n) for n in range(24)}
    padded = {str(n).zfill(2) for n in range(24)}
    if any(type(label) is not str for label in labels) or len(set(labels)) != 24 or set(labels) not in (plain, padded): raise HourlyInvalid('labels')
    hours = []
    for bucket in sorted(buckets, key=lambda b: int(b['name'])):
        if 'id' in bucket and bucket['id'] != entity_id or 'customerId' in bucket and bucket['customerId'] != customer_id: raise HourlyInvalid('identity')
        hours.append({'hour': int(bucket['name']), **metrics(bucket)})
    for key in FIELDS:
        if sum(Decimal(str(h[key])) for h in hours) != Decimal(str(summary[key])): raise HourlyInvalid('totals')
    raw = body.get('cycleBaseTm')
    if not isinstance(raw, str) or not re.fullmatch(r'[0-9]{12}', raw): raise HourlyInvalid('cycle')
    try: source = datetime.strptime(raw, '%Y%m%d%H%M').replace(tzinfo=KST)
    except ValueError: raise HourlyInvalid('cycle') from None
    # The adapter supplies a KST clock. A fresh completed date is required for the probe and observations.
    if source > now.astimezone(KST) + timedelta(minutes=10) or source.date() <= day: raise HourlyInvalid('cycle')
    return {'customer_id': customer_id, 'entity_id': entity_id, 'day': day.isoformat(),
            'source_at': source.isoformat(), 'hours': hours, 'summary': summary}
