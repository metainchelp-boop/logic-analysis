"""Saved platform purchase events, never merchant orders or a user journey.

Pure aggregation only. Each purchase ratio uses basic metrics read in the same
purchase call and the same qualified account-days. Private provenance is never
included in the compact model context.
"""
from collections.abc import Mapping
from copy import deepcopy
from datetime import date, datetime, timedelta
from decimal import Decimal
import hashlib
import json
import math
import re

from . import reporting as R

MAX_NUMBER = R.MAX_NUMBER
KST = R.KST
METRICS = ("purchase_count", "purchase_value", "purchase_cvr", "purchase_cpa", "purchase_roas")
COVERAGE = ("expected_account_days", "basic_account_days", "count_account_days", "value_account_days",
            "count_paired_account_days", "value_paired_account_days")
DISPLAY_FIELDS = ("source_status", "coverage", "count_coverage", "value_coverage") + METRICS
UNAVAILABLE_STAGES = ("cart", "orders", "refunds", "repeat_purchase", "gross_profit", "unique_customers", "landing_attribution")
_CONTEXT = frozenset({"version", "source_status", "coverage", "metrics", "metric_status", "measurement_confirmed",
                      "attribution_final", "commerce_connected", "unavailable_stages"})
_HEX = re.compile(r"[0-9a-f]{64}\Z")


class EvidenceInvalid(ValueError):
    pass


def _bad():
    raise EvidenceInvalid("FUNNEL_EVIDENCE_INVALID")


def _number(value, *, integer=False):
    return type(value) in ((int,) if integer else (int, float)) and 0 <= value <= MAX_NUMBER and math.isfinite(value)


def _moment(value):
    try:
        value = datetime.fromisoformat(value) if isinstance(value, str) else value
        return value.astimezone(KST) if isinstance(value, datetime) and value.utcoffset() is not None else None
    except (TypeError, ValueError, OverflowError):
        return None


def _sum(rows, key):
    if not rows:
        return None
    total = sum((Decimal(str(row[key])) for row in rows), Decimal(0))
    if total > MAX_NUMBER:
        _bad()
    return int(total) if total == int(total) else float(total)


def _ratio(numerator, denominator, multiplier=1):
    if numerator is None or denominator is None or denominator == 0:
        return None
    value = numerator / denominator * multiplier
    if not _number(value):
        _bad()
    return value


def _source_status(coverage):
    expected = coverage["expected_account_days"]
    if expected and all(coverage[key] == expected for key in COVERAGE[1:]):
        return "complete"
    return "partial" if coverage["count_account_days"] or coverage["value_account_days"] else "unavailable"


def _period(value, now):
    try:
        if not isinstance(value, R.ReportPeriod) or type(value.start) is not date or type(value.end) is not date:
            _bad()
        canonical = R.period(value.kind, value.start)
        if canonical != value or value.end >= now.date():
            _bad()
        return (value.end-value.start).days+1
    except (TypeError, ValueError, OverflowError):
        _bad()


def _qualified(row, day, now):
    if row.get("status") != "ok":
        return False
    checked, source, generation = (_moment(row.get(key)) for key in ("checked_at", "source_at", "source_generation"))
    return bool(checked is not None and source is not None and generation is not None
                and checked.date() > day and source.date() > day and source <= checked <= now
                and generation <= checked and source.date() >= generation.date()
                and type(row.get("source_revision")) is int and row["source_revision"] >= 1
                and isinstance(row.get("campaign_fingerprint"), str) and _HEX.fullmatch(row["campaign_fingerprint"]))


def snapshot(report_period, expected_customer_ids, daily_rows, now):
    """Save facts plus private provenance; foreign rows cannot affect either."""
    now = _moment(now)
    if now is None or not isinstance(expected_customer_ids, (list, tuple, set, frozenset)):
        _bad()
    expected = list(expected_customer_ids)
    if (len(expected) > 10000 or any(type(cid) is not int or cid <= 0 for cid in expected)
            or len(set(expected)) != len(expected) or not isinstance(daily_rows, (list, tuple)) or len(daily_rows) > 310000):
        _bad()
    days = _period(report_period, now)
    expected = sorted(expected)
    scope, seen, manifest, basic, counts, values, count_pair, value_pair = set(expected), set(), [], [], [], [], [], []
    for row in daily_rows:
        if not isinstance(row, Mapping):
            _bad()
        # Scope is checked before foreign numeric/provenance fields are inspected.
        if type(row.get("customer_id")) is not int or row["customer_id"] not in scope:
            continue
        raw_day = row.get("day")
        try:
            day = date.fromisoformat(raw_day) if isinstance(raw_day, str) else None
        except ValueError:
            _bad()
        if day is None or day.isoformat() != raw_day:
            _bad()
        if not report_period.start <= day <= report_period.end:
            continue
        key = (row["customer_id"], raw_day)
        if key in seen:
            _bad()
        seen.add(key)
        clean = {name: row.get(name) for name in ("customer_id", "day", "status", "basic_complete", "count_complete",
                 "value_complete", "imp", "clk", "spend", "purchase_count", "purchase_value", "checked_at", "source_at",
                 "source_generation", "source_revision", "campaign_fingerprint")}
        for name in ("basic_complete", "count_complete", "value_complete"):
            if type(clean[name]) is not bool:
                _bad()
        if clean["status"] not in ("ok", "pending", "partial", "failed", "unavailable", None):
            _bad()
        for name in ("imp", "clk", "spend", "purchase_count", "purchase_value"):
            if clean[name] is not None and not _number(clean[name], integer=name in ("imp", "clk", "purchase_count")):
                _bad()
        manifest.append(clean)
        if not _qualified(clean, day, now):
            continue
        basic_ok = clean["basic_complete"] and all(clean[name] is not None for name in ("imp", "clk", "spend"))
        count_ok, value_ok = clean["count_complete"] and clean["purchase_count"] is not None, clean["value_complete"] and clean["purchase_value"] is not None
        if basic_ok: basic.append(clean)
        if count_ok: counts.append(clean)
        if value_ok: values.append(clean)
        if basic_ok and count_ok: count_pair.append(clean)
        if basic_ok and value_ok: value_pair.append(clean)
    coverage = dict(zip(COVERAGE, (len(expected)*days, len(basic), len(counts), len(values), len(count_pair), len(value_pair))))
    paired = {"count": {key: _sum(count_pair, key) for key in ("clk", "spend", "purchase_count")},
              "value": {key: _sum(value_pair, key) for key in ("spend", "purchase_value")}}
    metrics = {"purchase_count": _sum(counts, "purchase_count"), "purchase_value": _sum(values, "purchase_value"),
               "purchase_cvr": _ratio(paired["count"]["purchase_count"], paired["count"]["clk"], 100),
               "purchase_cpa": _ratio(paired["count"]["spend"], paired["count"]["purchase_count"]),
               "purchase_roas": _ratio(paired["value"]["purchase_value"], paired["value"]["spend"], 100)}
    families = ("count_account_days", "value_account_days", "count_paired_account_days", "count_paired_account_days", "value_paired_account_days")
    denominators = (None, None, paired["count"]["clk"], paired["count"]["purchase_count"], paired["value"]["spend"])
    statuses = {key: ("ready" if coverage[family] == coverage["expected_account_days"] else "partial") if metrics[key] is not None
                else "zero_denominator" if denominator == 0 else "unavailable"
                for key, family, denominator in zip(METRICS, families, denominators)}
    result = {"version": 1, "source_status": _source_status(coverage), "coverage": coverage, "metrics": metrics,
              "metric_status": statuses, "measurement_confirmed": False, "attribution_final": False,
              "commerce_connected": False, "unavailable_stages": list(UNAVAILABLE_STAGES)}
    manifest.sort(key=lambda row: (row["customer_id"], row["day"]))
    material = [{**{key: value for key, value in row.items() if key not in ("checked_at", "source_at")},
                 "qualified": _qualified(row, date.fromisoformat(row["day"]), now)} for row in manifest]
    try:
        fingerprint = hashlib.sha256(json.dumps([report_period.key, expected, material, result], sort_keys=True,
                                    separators=(",", ":"), ensure_ascii=False, allow_nan=False).encode()).hexdigest()
    except (TypeError, ValueError, OverflowError):
        _bad()
    return {**normalize_context(result), "period": report_period.as_dict(), "paired_bases": paired,
            "_source_manifest": manifest, "_fingerprint": fingerprint}


def normalize_context(value):
    if not isinstance(value, dict) or set(value) != _CONTEXT or type(value["version"]) is not int or value["version"] != 1:
        _bad()
    coverage, metrics, statuses = value["coverage"], value["metrics"], value["metric_status"]
    if (not isinstance(coverage, dict) or set(coverage) != set(COVERAGE)
            or any(type(number) is not int or not 0 <= number <= 310000 for number in coverage.values())
            or any(coverage[key] > coverage["expected_account_days"] for key in COVERAGE[1:])
            or coverage["count_paired_account_days"] > min(coverage["basic_account_days"], coverage["count_account_days"])
            or coverage["value_paired_account_days"] > min(coverage["basic_account_days"], coverage["value_account_days"])
            or value["source_status"] != _source_status(coverage)
            or not isinstance(metrics, dict) or set(metrics) != set(METRICS)
            or not isinstance(statuses, dict) or set(statuses) != set(METRICS)
            or any(value[name] is not False for name in ("measurement_confirmed", "attribution_final", "commerce_connected"))
            or value["unavailable_stages"] != list(UNAVAILABLE_STAGES)):
        _bad()
    for key, family in zip(METRICS, ("count_account_days", "value_account_days", "count_paired_account_days", "count_paired_account_days", "value_paired_account_days")):
        metric, status = metrics[key], statuses[key]
        if metric is not None:
            if (not _number(metric, integer=key == "purchase_count") or not coverage[family]
                    or status != ("ready" if coverage[family] == coverage["expected_account_days"] else "partial")):
                _bad()
        else:
            if (status not in ("unavailable", "zero_denominator") or key in METRICS[:2] and coverage[family]
                    or status == "zero_denominator" and (key in METRICS[:2] or not coverage[family])
                    or key in METRICS[2:] and coverage[family] and status != "zero_denominator"):
                _bad()
    return deepcopy(value)


def model_context(saved_funnel):
    if not isinstance(saved_funnel, dict):
        _bad()
    return normalize_context({key: saved_funnel[key] for key in _CONTEXT if key in saved_funnel})


def _formatted(value):
    text = format(Decimal(str(value)), ",f")
    return text.rstrip("0").rstrip(".") if "." in text else text


def display(context, field):
    context = normalize_context(context)
    if field not in DISPLAY_FIELDS:
        _bad()
    coverage = context["coverage"]
    expected = coverage["expected_account_days"]
    if field == "source_status":
        label = {"complete": "숫자 응답 완결", "partial": "부분 집계", "unavailable": "구매수·가치 미확인"}[context["source_status"]]
        return ("별도 플랫폼 구매전환 원천 " + label + "; 통계 광고비는 VAT 포함, 구매 전환금액의 VAT 조건 미확인; "
                "태그 건전성·최종 귀속·실제 주문/결제/환불/순매출/이익은 미확인")
    if field == "coverage":
        return (f"별도 구매전환 원천 예상 {expected:,}계정×일 중 구매수 {coverage['count_account_days']:,}, "
                f"구매가치 {coverage['value_account_days']:,}; 기본과 공동 표본은 각각 "
                f"{coverage['count_paired_account_days']:,}/{coverage['value_paired_account_days']:,}계정×일")
    if field in ("count_coverage", "value_coverage"):
        prefix = "count" if field == "count_coverage" else "value"
        label = "구매수" if prefix == "count" else "구매가치"
        return f"별도 {label} 원천 {coverage[prefix+'_account_days']:,}/{expected:,}계정×일; 같은 호출 기본 성과와 공동 {coverage[prefix+'_paired_account_days']:,}계정×일"
    value = context["metrics"][field]
    if value is None:
        _bad()
    label, unit = {"purchase_count": ("플랫폼 구매전환", "건"), "purchase_value": ("플랫폼 구매 전환가치", "원"),
                   "purchase_cvr": ("동일 공동 표본의 플랫폼 구매전환/클릭", "%"),
                   "purchase_cpa": ("동일 공동 표본의 플랫폼 구매전환당 광고비", "원"),
                   "purchase_roas": ("동일 공동 표본의 플랫폼 구매 전환가치/광고비", "%")}[field]
    partial = " · 부분 표본" if context["metric_status"][field] == "partial" else ""
    return f"{label} {_formatted(value)}{unit}{partial}"
