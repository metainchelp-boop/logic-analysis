"""Two exact entity observations through the existing bounded GET reader.

Before/after configuration scans and their page cursors survive a six-call
tick. This is observation collection, never an assignment or ad executor.
"""
from collections import Counter
from copy import deepcopy
from dataclasses import dataclass, field
from datetime import date, datetime, time, timedelta
from itertools import islice
import re
from time import monotonic

from . import experiments as E, handles as H, inspection_fields as IF, naver_read as N, store as S

FIELDS = E.FIELDS
JOB_FIELDS = frozenset({"job_key", "experiment_id", "protocol_version", "possibility_id", "customer_id", "stage_revision",
    "account_key", "generation", "period_start", "period_end", "plan_version", "source_fingerprint", "arms"})
SOURCE_FIELDS = frozenset({"version", "job_key", "experiment_id", "protocol_version", "customer_id", "generation",
    "period_start", "period_end", "plan_version", "source_fingerprint", "arms", "phase", "group_index", "cursor",
    "found", "visited_cursors", "pages", "rows"})
MAX_PAGES = 1000
JOB_V2_FIELDS = JOB_FIELDS | {"version", "method", "approved_at", "measurement_lag_days", "parents"}
SOURCE_V2_FIELDS = JOB_V2_FIELDS | {"settings_ledger", "drift", "round", "daily"}
ROUND_FIELDS = frozenset({"day", "started_at", "phase", "index", "cursor", "found", "visited_cursors", "pages"})
ROUND_TTL = timedelta(minutes=20)


class CheckpointInvalid(ValueError):
    pass


class ConfigurationChanged(ValueError):
    pass


@dataclass(frozen=True)
class ExperimentsOutcome:
    code: str
    counts: dict = field(default_factory=dict)


def _invalid():
    raise CheckpointInvalid("실험 관측의 범위·설정·재개 원천이 다릅니다")


def _job(job, now=None):
    try:
        v2 = isinstance(job, dict) and job.get("version") == 2 and type(job.get("version")) is int
        if not isinstance(job, dict) or set(job) != (JOB_V2_FIELDS if v2 else JOB_FIELDS): _invalid()
        for key in ("protocol_version", "possibility_id", "customer_id", "plan_version"):
            if not E._number(job[key], 1, E.MAX_NUMBER, True): _invalid()
        if (not isinstance(job["experiment_id"], str) or not re.fullmatch(r"[0-9a-f]{32}", job["experiment_id"])
                or not isinstance(job["job_key"], str) or not re.fullmatch(r"experiment:[A-Za-z0-9:_-]{1,180}", job["job_key"])
                or not isinstance(job["stage_revision"], str) or not 1 <= len(job["stage_revision"]) <= 160
                or not isinstance(job["account_key"], str) or not E._HEX.fullmatch(job["account_key"])
                or not isinstance(job["source_fingerprint"], str) or not E._HEX.fullmatch(job["source_fingerprint"])): _invalid()
        start, end = E._day(job["period_start"]), E._day(job["period_end"])
        if not 1 <= (end-start).days+1 <= 30: _invalid()
        generation = E.moment(job["generation"])
        if now is not None and generation > E.moment(now): _invalid()
        if not isinstance(job["arms"], dict) or set(job["arms"]) != {"control", "treatment"}: _invalid()
        for arm in job["arms"].values(): E.normalize_arm(arm, job["customer_id"])
        a, b = job["arms"]["control"], job["arms"]["treatment"]
        if a["kind"] != b["kind"] or a["id"] == b["id"]: _invalid()
        scope = {key: job[key] for key in ("possibility_id", "customer_id", "account_key", "stage_revision")}
        proof = [scope, job["arms"]]
        if v2:
            if job["method"] != E.OI.METHOD or not 28 <= (end-start).days+1 <= 30: _invalid()
            if E.moment(job["approved_at"]) != generation or generation >= datetime.combine(start, time(), E.KST): _invalid()
            if not E._number(job["measurement_lag_days"], 0, 30, True): _invalid()
            parents = job["parents"]
            if not isinstance(parents, dict) or set(parents) != {"campaign", "adgroup"}: _invalid()
            for kind, arm in parents.items():
                if E.normalize_arm(arm, job["customer_id"])["kind"] != kind: _invalid()
            if parents["adgroup"]["parent_id"] != parents["campaign"]["id"]: _invalid()
            if any(arm["kind"] != "ad" or arm["parent_id"] != parents["adgroup"]["id"] or arm["campaign_id"] != parents["campaign"]["id"] for arm in job["arms"].values()): _invalid()
            proof.append(parents)
        if job["source_fingerprint"] != E.fingerprint(proof): _invalid()
        return start, end
    except (KeyError, TypeError, ValueError, OverflowError): _invalid()


def _groups(job):
    result = []
    for name in ("control", "treatment"):
        arm = job["arms"][name]
        key = (arm["kind"], arm["parent_id"])
        if key not in result: result.append(key)
    return result


def _targets(job, index):
    kind, parent = _groups(job)[index]
    return {name for name, arm in job["arms"].items() if (arm["kind"], arm["parent_id"]) == (kind, parent)}


def _initial(job):
    if job.get("version") == 2:
        return {**deepcopy(job), "settings_ledger": {}, "drift": False, "round": None, "daily": None}
    return {"version": 1, **{key: deepcopy(job[key]) for key in SOURCE_FIELDS & JOB_FIELDS},
            "phase": "before", "group_index": 0, "cursor": None, "found": [], "visited_cursors": [], "pages": 0, "rows": None}


def _snapshot(source):
    complete = all(row["complete"] for row in source["rows"].values())
    return dict(version=1, status="ok" if complete else "partial", period_start=source["period_start"],
        period_end=source["period_end"], source_fingerprint=source["source_fingerprint"], arms=deepcopy(source["rows"]),
        configuration_verified=True, checked_at=max(row["checked_at"] for row in source["rows"].values()))


def validate_progress(source, job, now=None):
    """Return a completed snapshot, or None for a valid resumable checkpoint."""
    _job(job, now)
    if job.get("version") == 2: return _validate_v2(source, job, now)
    try:
        if (not isinstance(source, dict) or set(source) != SOURCE_FIELDS or type(source["version"]) is not int
                or source["version"] != 1 or any(type(source[key]) is not type(job[key]) or source[key] != job[key] for key in SOURCE_FIELDS & JOB_FIELDS)
                or source["phase"] not in ("before", "stats", "after", "done")
                or type(source["group_index"]) is not int or not 0 <= source["group_index"] <= len(_groups(job))
                or type(source["pages"]) is not int or not 0 <= source["pages"] <= MAX_PAGES
                or not isinstance(source["found"], list) or len(set(source["found"])) != len(source["found"])
                or any(name not in ("control", "treatment") for name in source["found"])
                or not isinstance(source["visited_cursors"], list) or len(source["visited_cursors"]) > MAX_PAGES
                or len(set(source["visited_cursors"])) != len(source["visited_cursors"])): _invalid()
        for arm in source["arms"].values(): E.normalize_arm(arm, job["customer_id"])
        index, phase = source["group_index"], source["phase"]
        if phase in ("stats", "done"):
            if index != len(_groups(job)) or source["found"] or source["cursor"] is not None or source["visited_cursors"]: _invalid()
        else:
            if index >= len(_groups(job)) or not set(source["found"]) <= _targets(job, index): _invalid()
            kind = _groups(job)[index][0]
            if source["cursor"] is not None and not IF.valid_id(source["cursor"], kind): _invalid()
            if any(not IF.valid_id(cursor, kind) for cursor in source["visited_cursors"]): _invalid()
            if source["cursor"] is not None and (not source["visited_cursors"] or source["visited_cursors"][-1] != source["cursor"]): _invalid()
        if phase in ("before", "stats") and source["rows"] is not None: _invalid()
        if phase in ("after", "done"):
            rows = source["rows"]
            if not isinstance(rows, dict) or set(rows) != {"control", "treatment"}: _invalid()
            for row in rows.values():
                if not isinstance(row, dict) or set(row) != E._ROW or type(row["complete"]) is not bool or type(row["missing"]) is not bool: _invalid()
                E._fields(row["fields"])
                checked = E.moment(row["checked_at"])
                if checked < E.moment(job["generation"]) or now is not None and checked > E.moment(now): _invalid()
                cycle = E.moment(row["source_at"]) if row["source_at"] is not None else None
                if cycle is not None and cycle > checked: _invalid()
                if row["missing"] and (row["complete"] or any(v is not None for v in row["fields"].values())): _invalid()
                complete = not row["missing"] and cycle is not None and cycle.date() > E._day(job["period_end"]) and cycle.date() >= E.moment(job["generation"]).date() and all(v is not None for v in row["fields"].values())
                if row["complete"] != complete: _invalid()
            if len({row["source_at"] for row in rows.values()}) != 1: _invalid()
        return _snapshot(source) if phase == "done" else None
    except (KeyError, TypeError, ValueError, OverflowError): _invalid()


def _scan(reader, handle, job, source):
    index = source["group_index"]
    kind, parent = _groups(job)[index]
    rows, cursor = reader.get_setup_page(handle, kind, parent, page_token=source["cursor"])
    reader.check_budget()
    if not isinstance(rows, list) or len(rows) > IF.MAX_ROWS: _invalid()
    update, found, seen = deepcopy(source), set(source["found"]), set()
    for row in rows:
        try: clean = IF.sanitize_record(kind, row, job["customer_id"], parent)
        except (TypeError, ValueError): _invalid()
        identifier = clean[IF.IDS[kind]]
        if identifier in seen: _invalid()
        seen.add(identifier)
        for name in _targets(job, index):
            arm = job["arms"][name]
            if identifier != arm["id"]: continue
            if name in found or clean != arm["settings"]: raise ConfigurationChanged()
            found.add(name)
    update["pages"] += 1
    if update["pages"] > MAX_PAGES: _invalid()
    if found == _targets(job, index):
        update.update(group_index=index+1, cursor=None, found=[], visited_cursors=[])
        if update["group_index"] == len(_groups(job)):
            update["phase"] = "stats" if source["phase"] == "before" else "done"
    elif cursor is None: raise ConfigurationChanged()
    else:
        if not IF.valid_id(cursor, kind) or cursor in update["visited_cursors"]: _invalid()
        update["visited_cursors"].append(cursor)
        update.update(cursor=cursor, found=sorted(found))
    return update


def _stats(reader, handle, job, source, clock):
    ids = [job["arms"][name]["id"] for name in ("control", "treatment")]
    result = reader.get_entity_stats_summary(handle, ids, E._day(job["period_start"]), E._day(job["period_end"]), FIELDS)
    reader.check_budget()
    if (set(result.requested_ids) != set(ids) or len(result.requested_ids) != 2 or not set(result.missing_ids) <= set(ids)
            or not set(result.rows) <= set(ids) or result.until != E._day(job["period_end"])): _invalid()
    now = E.moment(clock())
    cycle = E.moment(result.cycle_base_tm) if result.cycle_base_tm is not None else None
    if cycle is not None and cycle > now: _invalid()
    rows = {}
    for name in ("control", "treatment"):
        identifier = job["arms"][name]["id"]
        missing = identifier in result.missing_ids
        if not missing and identifier not in result.rows: _invalid()
        fields = dict.fromkeys(FIELDS) if missing else E._fields(result.rows[identifier])
        complete = (not missing and cycle is not None and cycle.date() > E._day(job["period_end"])
                    and cycle.date() >= E.moment(job["generation"]).date() and all(v is not None for v in fields.values()))
        rows[name] = dict(fields=fields, missing=missing, complete=complete,
                          source_at=cycle.isoformat() if cycle is not None else None, checked_at=now.isoformat())
    return dict(deepcopy(source), phase="after", group_index=0, cursor=None, found=[], visited_cursors=[], rows=rows)


def _read(reader, handle, job, store, clock, values):
    if job.get("version") == 2: return _read_v2(reader, handle, job, store, clock, values)
    _, end = _job(job, clock())
    if end >= E.moment(clock()).date():
        values.update(status="source_wait", error_code="STATS_PERIOD_OPEN"); return
    source = store.experiments_progress(job)
    if source is not None: validate_progress(source, job, clock())
    if source is None or source["phase"] == "done" and not all(row["complete"] for row in source["rows"].values()): source = _initial(job)
    while source["phase"] != "done":
        if not store.experiments_account_valid(job, clock()): raise S.StoreRefused("현재 실험 범위가 변경되었습니다")
        update = _stats(reader, handle, job, source, clock) if source["phase"] == "stats" else _scan(reader, handle, job, source)
        validate_progress(update, job, clock())
        store.record_experiments_progress(job, clock(), update)
        values["progressed"] = True; source = update
    snapshot = validate_progress(source, job, clock())
    values.update(status="ok" if snapshot["status"] == "ok" else "partial", error_code=None if snapshot["status"] == "ok" else "STATS_INCOMPLETE", snapshot=snapshot)


def _days(job):
    start, end = E._day(job["period_start"]), E._day(job["period_end"])
    return [(start+timedelta(days=i)).isoformat() for i in range((end-start).days+1)]


def _stability(source):
    expected = _days(source)
    observed = sorted(source["settings_ledger"])
    missing = sorted(set(expected)-set(observed))
    return dict(qualifier="observed_stability", expected_days=expected, observed_days=observed, missing_days=missing,
        drift=source["drift"], coverage_complete=not missing and not source["drift"],
        first_checked_at=source["settings_ledger"][observed[0]]["first_checked_at"] if observed else None,
        last_checked_at=source["settings_ledger"][observed[-1]]["last_checked_at"] if observed else None,
        limitations=list(E.STABILITY_LIMITATIONS))


def _snapshot_v2(source):
    daily = source["daily"]
    rows = {}
    for arm in ("control", "treatment"):
        records = [day[arm] for day in daily]
        fields = {field: None if any(row["fields"][field] is None for row in records) else
                  sum(row["fields"][field] for row in records) for field in FIELDS}
        cycles = {row["source_at"] for row in records}
        rows[arm] = dict(fields=fields, missing=all(row["missing"] for row in records),
            complete=all(row["complete"] for row in records), source_at=next(iter(cycles)) if len(cycles) == 1 else None,
            checked_at=max(row["checked_at"] for row in records))
    return dict(version=2, status="ok" if all(row["complete"] for row in rows.values()) else "partial",
        period_start=source["period_start"], period_end=source["period_end"], source_fingerprint=source["source_fingerprint"],
        arms=rows, configuration_verified=not source["drift"], checked_at=max(row["checked_at"] for row in rows.values()),
        daily=deepcopy(daily), stability=_stability(source))


def _validate_v2(source, job, now):
    try:
        if (not isinstance(source, dict) or set(source) != SOURCE_V2_FIELDS
                or any(type(source[key]) is not type(job[key]) or source[key] != job[key] for key in JOB_V2_FIELDS)
                or type(source["drift"]) is not bool or not isinstance(source["settings_ledger"], dict)
                or len(source["settings_ledger"]) > 30): _invalid()
        expected = _days(job)
        for day, record in source["settings_ledger"].items():
            if day not in expected or not isinstance(record, dict) or set(record) != {"first_checked_at", "last_checked_at"}: _invalid()
            first, last = E.moment(record["first_checked_at"]), E.moment(record["last_checked_at"])
            if first.date().isoformat() != day or last.date().isoformat() != day or not E.moment(job["generation"]) <= first <= last: _invalid()
            if now is not None and last > E.moment(now): _invalid()
        round_ = source["round"]
        if round_ is None:
            if source["daily"] is not None: _invalid()
            return None
        if (not isinstance(round_, dict) or set(round_) != ROUND_FIELDS or round_["phase"] not in ("before", "daily_control", "daily_treatment", "after", "done")
                or type(round_["index"]) is not int or not 0 <= round_["index"] <= 3
                or type(round_["pages"]) is not int or not 0 <= round_["pages"] <= 2*MAX_PAGES): _invalid()
        began = E.moment(round_["started_at"])
        if began.date().isoformat() != round_["day"] or began < E.moment(job["generation"]) or now is not None and began > E.moment(now): _invalid()
        for field in ("found", "visited_cursors"):
            if not isinstance(round_[field], list) or len(round_[field]) > MAX_PAGES or len(set(round_[field])) != len(round_[field]): _invalid()
        if round_["phase"] in ("before", "after"):
            if round_["index"] >= 3: _invalid()
            kind = ("campaign", "adgroup", "ad")[round_["index"]]
            names = {"campaign"} if kind == "campaign" else {"adgroup"} if kind == "adgroup" else {"control", "treatment"}
            if not set(round_["found"]) <= names: _invalid()
            if round_["cursor"] is not None and (not IF.valid_id(round_["cursor"], kind) or not round_["visited_cursors"] or round_["visited_cursors"][-1] != round_["cursor"]): _invalid()
            if any(not IF.valid_id(token, kind) for token in round_["visited_cursors"]): _invalid()
        elif round_["index"] != 3 or round_["found"] or round_["cursor"] is not None or round_["visited_cursors"]: _invalid()
        daily = source["daily"]
        if daily is not None:
            if not isinstance(daily, list) or [row.get("day") for row in daily if isinstance(row, dict)] != expected: _invalid()
            for day in daily:
                if set(day) != {"day", "control", "treatment"}: _invalid()
                for arm in ("control", "treatment"):
                    row = day[arm]
                    if row is None:
                        if round_["phase"] != "daily_treatment" or arm != "treatment": _invalid()
                        continue
                    if not isinstance(row, dict) or set(row) != E._ROW or type(row["missing"]) is not bool or type(row["complete"]) is not bool: _invalid()
                    E._fields(row["fields"])
                    checked = E.moment(row["checked_at"])
                    if checked < began or now is not None and checked > E.moment(now): _invalid()
                    cycle = E.moment(row["source_at"]) if row["source_at"] is not None else None
                    if cycle is not None and cycle > checked: _invalid()
                    if row["missing"] and any(v is not None for v in row["fields"].values()): _invalid()
                    complete = not row["missing"] and cycle is not None and cycle.date() > E._day(job["period_end"]) and all(v is not None for v in row["fields"].values())
                    if row["complete"] != complete: _invalid()
        elif round_["phase"] in ("daily_treatment",): _invalid()
        if round_["phase"] == "before" and daily is not None: _invalid()
        if round_["phase"] == "daily_control" and daily is not None: _invalid()
        if round_["phase"] == "done" and daily is not None:
            return _snapshot_v2(source)
        return None
    except (KeyError, TypeError, ValueError, OverflowError): _invalid()


def _round(job, now):
    return dict(day=now.date().isoformat(), started_at=now.isoformat(), phase="before", index=0,
                cursor=None, found=[], visited_cursors=[], pages=0)


def _scan_v2(reader, handle, job, source, clock, mature):
    update = deepcopy(source)
    round_ = update["round"]
    index = round_["index"]
    kind = ("campaign", "adgroup", "ad")[index]
    parent = None if kind == "campaign" else job["parents"]["campaign"]["id"] if kind == "adgroup" else job["parents"]["adgroup"]["id"]
    targets = {kind: job["parents"][kind]} if index < 2 else job["arms"]
    rows, cursor = reader.get_setup_page(handle, kind, parent, page_token=round_["cursor"])
    reader.check_budget()
    now = E.moment(clock())
    found, seen = set(round_["found"]), set()
    for row in rows:
        clean = IF.sanitize_record(kind, row, job["customer_id"], parent)
        identifier = clean[IF.IDS[kind]]
        if identifier in seen: _invalid()
        seen.add(identifier)
        for name, arm in targets.items():
            if identifier == arm["id"]:
                if name in found or clean != arm["settings"]: update["drift"] = True
                found.add(name)
    round_["pages"] += 1
    if round_["pages"] > 2*MAX_PAGES: _invalid()
    if found == set(targets):
        round_.update(index=index+1, cursor=None, found=[], visited_cursors=[])
        if index == 2:
            if round_["phase"] == "before":
                round_["phase"] = "daily_control" if mature else "after"
                if not mature: round_["index"] = 0
            else: round_["phase"] = "done"
    elif cursor is None: update["drift"] = True
    else:
        if not IF.valid_id(cursor, kind) or cursor in round_["visited_cursors"]: _invalid()
        round_["visited_cursors"].append(cursor); round_.update(cursor=cursor, found=sorted(found))
    if (round_["phase"] == "done" and not update["drift"] and now.date().isoformat() == round_["day"]
            and now.date().isoformat() in _days(job)):
        day = now.date().isoformat()
        record = update["settings_ledger"].setdefault(day, dict(first_checked_at=now.isoformat(), last_checked_at=now.isoformat()))
        record["last_checked_at"] = now.isoformat()
    return update


def _daily_v2(reader, handle, job, source, clock):
    update = deepcopy(source)
    arm = "control" if source["round"]["phase"] == "daily_control" else "treatment"
    result = reader.get_entity_stats_daily(handle, job["arms"][arm]["id"], E._day(job["period_start"]), E._day(job["period_end"]), FIELDS)
    reader.check_budget()
    if result.entity_id != job["arms"][arm]["id"] or result.until != E._day(job["period_end"]): _invalid()
    expected = _days(job)
    if set(result.days) | set(result.missing_days) != set(expected) or set(result.days) & set(result.missing_days): _invalid()
    now = E.moment(clock())
    cycle = E.moment(result.cycle_base_tm) if result.cycle_base_tm is not None else None
    if cycle is not None and cycle > now: _invalid()
    if update["daily"] is None: update["daily"] = [dict(day=day, control=None, treatment=None) for day in expected]
    for day in update["daily"]:
        missing = day["day"] in result.missing_days
        fields = dict.fromkeys(FIELDS) if missing else E._fields(result.days[day["day"]])
        day[arm] = dict(fields=fields, missing=missing, complete=not missing and cycle is not None and cycle.date() > E._day(job["period_end"]) and all(v is not None for v in fields.values()),
                        source_at=cycle.isoformat() if cycle is not None else None, checked_at=now.isoformat())
    update["round"]["phase"] = "daily_treatment" if arm == "control" else "after"
    if arm == "treatment": update["round"]["index"] = 0
    return update


def _read_v2(reader, handle, job, store, clock, values):
    _job(job, clock())
    now = E.moment(clock())
    mature = now.date() >= E._day(job["period_end"])+timedelta(days=1+job["measurement_lag_days"])
    source = store.experiments_progress(job)
    if source is None: source = _initial(job)
    else: validate_progress(source, job, now)
    if source["drift"]:
        values.update(status="limited", error_code="SETTINGS_CHANGED"); return
    round_ = source["round"]
    if round_ is None or round_["phase"] == "done" or round_["day"] != now.date().isoformat() or now-E.moment(round_["started_at"]) > ROUND_TTL:
        source.update(round=_round(job, now), daily=None)
    while source["round"]["phase"] != "done":
        if not store.experiments_account_valid(job, clock()): raise S.StoreRefused("현재 실험 범위가 변경되었습니다")
        at = E.moment(clock())
        if at.date().isoformat() != source["round"]["day"] or at-E.moment(source["round"]["started_at"]) > ROUND_TTL:
            values.update(status="partial", error_code="REQUEST_DEADLINE"); return
        update = (_daily_v2(reader, handle, job, source, clock) if source["round"]["phase"] in ("daily_control", "daily_treatment")
                  else _scan_v2(reader, handle, job, source, clock, mature))
        validate_progress(update, job, clock())
        store.record_experiments_progress(job, clock(), update)
        values["progressed"] = True; source = update
        if source["drift"]: raise ConfigurationChanged()
        if (E.moment(clock()).date().isoformat() != source["round"]["day"]
                or E.moment(clock())-E.moment(source["round"]["started_at"]) > ROUND_TTL):
            values.update(status="partial", error_code="REQUEST_DEADLINE"); return
    snapshot = validate_progress(source, job, clock())
    if snapshot is None:
        tomorrow = datetime.combine(E.moment(clock()).date()+timedelta(days=1), time(), E.KST)
        values.update(status="source_wait", error_code="STATS_PERIOD_OPEN", next_check_at=tomorrow.isoformat())
    else:
        values.update(status=snapshot["status"], error_code=None if snapshot["status"] == "ok" else "STATS_INCOMPLETE", snapshot=snapshot)


def run_experiments(reader, store, clock, *, limit=24, max_calls=6, max_seconds=20,
                    per_account_calls=6, exclude_customers=()):
    if (type(limit) is not int or not 1 <= limit <= 24 or type(max_calls) is not int or not 1 <= max_calls <= 6
            or type(max_seconds) not in (int, float) or not 0 < max_seconds <= 20
            or type(per_account_calls) is not int or not 1 <= per_account_calls <= 6): raise ValueError("실험 관측 읽기 예산이 잘못되었습니다")
    try: excluded = tuple(islice(exclude_customers, 10001))
    except TypeError: raise ValueError("제외 계정 범위가 잘못되었습니다") from None
    if len(excluded) > 10000 or any(type(cid) is not int or cid <= 0 for cid in excluded): raise ValueError("제외 계정 범위가 잘못되었습니다")
    excluded = set(excluded) | set(reader.called_customers)
    if reader.rate_limited: return ExperimentsOutcome("BUDGET")
    now, initial, started = E.moment(clock()), reader.calls, monotonic()
    snapshot_at = store.inventory_snapshot(now)
    if snapshot_at is None: return ExperimentsOutcome("NOT_READY")
    counts, seen = Counter(), set()
    with reader.bounded_requests(max_calls=max_calls, max_seconds=max_seconds):
        for job in store.experiments_work(now, limit):
            if job["customer_id"] in seen or job["customer_id"] in excluded: continue
            elapsed = max((E.moment(clock())-now).total_seconds(), monotonic()-started)
            if elapsed >= max_seconds or max_calls-(reader.calls-initial) < 1: return ExperimentsOutcome("BUDGET", dict(counts))
            if E.moment(clock()) < now or E.moment(clock()).date() != now.date(): return ExperimentsOutcome("SOURCE_CHANGED", dict(counts))
            values = {}
            try:
                _job(job, clock()); seen.add(job["customer_id"])
                store.begin_experiments_check(job, clock())
                handle = H.issue_inventory_handle(customer_id=job["customer_id"], snapshot_at=snapshot_at, now=clock(),
                    validate=lambda cid, snapshot, at: store.experiments_account_valid(job, at))
                with reader.bounded_requests(max_calls=min(per_account_calls, max_calls-(reader.calls-initial)), max_seconds=min(20, max_seconds-elapsed)):
                    _read(reader, handle, job, store, clock, values)
                    reader.check_budget()
            except N.NaverApiError as exc:
                values.update(status="reauth_required" if exc.kind == N.KIND_KEY_REJECTED else "retry", error_code=exc.kind)
            except ConfigurationChanged:
                values.update(status="retry", error_code="SETTINGS_CHANGED")
            except (N.StatsShapeUnknown, CheckpointInvalid, E.ExperimentInvalid):
                values.update(status="limited", error_code="CHECKPOINT_INVALID")
            except N.RunAbort as exc:
                values.update(status="partial" if values.get("progressed") else "retry", error_code=N.KIND_RATE if reader.rate_limited else exc.cause_code or exc.code)
            except (H.NotEligible, H.HandleInvalid, S.StoreRefused):
                return ExperimentsOutcome("SOURCE_CHANGED", dict(counts))
            except S.StoreError: raise
            except Exception: values.update(status="retry", error_code="UNEXPECTED")
            if not store.experiments_account_valid(job, clock()): return ExperimentsOutcome("SOURCE_CHANGED", dict(counts))
            try: status = store.record_experiments_check(job, clock(), values)
            except S.StoreRefused: return ExperimentsOutcome("SOURCE_CHANGED", dict(counts))
            counts[status] += 1
            if reader.rate_limited: return ExperimentsOutcome("BUDGET", dict(counts))
    return ExperimentsOutcome("DONE", dict(counts))
