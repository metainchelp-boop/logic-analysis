"""Closed validation facts; no response text, references, IDs or metric values.

These optional facts are stored beside the unchanged v1 provider trace. Older
readers can ignore them without losing the trace, its usage or its cost estimate.
"""

FIELDS = frozenset((
    "document", "diagnosis", "direction", "shared_comment", "ab_comment",
    "competitive_response", "competitive_response.hypothesis", "competitive_response.basis",
    "funnel_comment", "funnel_comment.hypothesis", "funnel_comment.basis",
    "appeal_points", "appeal_points.title", "appeal_points.message", "appeal_points.basis",
    "weekly_plan.action", "weekly_plan.reason", "weekly_plan.criterion",
    "monthly_plan.action", "monthly_plan.reason", "monthly_plan.criterion",
))
RULES = frozenset((
    "document-shape", "text-shape", "market-reference-location", "funnel-reference-location",
    "exploratory-claim", "randomized-claim", "numeric-reference-required", "reference-unavailable",
    "funnel-shape", "funnel-hypothesis", "funnel-basis",
    "competition-shape", "competition-hypothesis", "competition-basis",
    "fixed-boundary", "product-unlinked", "appeal-hypothesis", "appeal-basis",
))
FLAGS = frozenset(("product_connected", "market_connected", "funnel_present",
    "exploratory_learning", "randomized_learning"))
KEYS = frozenset(("version", "field", "rule")) | FLAGS
APPEAL_REASONS = frozenset(("TITLE", "PREFIX", "SUFFIX", "LEXEME"))
ERROR_CODES = {rule: ("DOCUMENT_INVALID" if rule in ("document-shape", "text-shape") else
    "NUMERIC_CITATION_REQUIRED" if rule == "numeric-reference-required" else
    "REFERENCE_UNAVAILABLE" if rule == "reference-unavailable" else "UNCONNECTED_EVIDENCE") for rule in RULES}
_SPECIFIC_FIELDS = {
    "document-shape": {"document"}, "fixed-boundary": {"competitive_response", "funnel_comment", "ab_comment"},
    "funnel-shape": {"funnel_comment"}, "funnel-hypothesis": {"funnel_comment.hypothesis"}, "funnel-basis": {"funnel_comment.basis"},
    "competition-shape": {"competitive_response"}, "competition-hypothesis": {"competitive_response.hypothesis"},
    "competition-basis": {"competitive_response.basis"}, "product-unlinked": {"appeal_points"},
    "appeal-hypothesis": {"appeal_points.message"}, "appeal-basis": {"appeal_points.basis"},
}


def normalize(value):
    if (type(value) is not dict or set(value) not in (KEYS, KEYS | {"reason"}) or type(value["version"]) is not int
            or value["version"] != 1 or type(value["field"]) is not str or value["field"] not in FIELDS
            or type(value["rule"]) is not str or value["rule"] not in RULES
            or any(type(value[key]) is not bool for key in FLAGS)
            or value["field"] not in _SPECIFIC_FIELDS.get(value["rule"], FIELDS)
            or ("reason" in value and (value["field"] != "appeal_points.message" or
                value["rule"] != "appeal-hypothesis" or type(value["reason"]) is not str or
                value["reason"] not in APPEAL_REASONS))):
        raise ValueError("VALIDATION_SUMMARY_INVALID")
    return dict(value)


def failure(error):
    """Never expose arbitrary exception attributes or stringify an error."""
    try:
        return normalize(getattr(error, "validation", None))
    except Exception:
        return None
