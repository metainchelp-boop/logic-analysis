"""Bounded local export ingestion. No logic DB, network, provider or source collection."""
import json
import os
from pathlib import Path
import stat
from time import monotonic

from naver_engine import market_evidence as ME

DEFAULT_PATH = "/var/lib/naver-market-source/bundle.json"


def _pairs(items):
    result = {}
    for key, value in items:
        if key in result:
            raise ValueError("DUPLICATE_KEY")
        result[key] = value
    return result


def read_bundle(path, now):
    """Read a single regular, non-writable export file; caller stores the closed failure state."""
    if not isinstance(path, str) or not path or len(path) > 4096 or any(ord(c) < 32 for c in path):
        return None, "unavailable" if not path else "invalid"
    started = monotonic()
    fd = None
    try:
        filename = Path(path)
        if not filename.is_absolute() or str(filename) != path or filename.resolve() != filename:
            return None, "invalid"
        fd = os.open(filename, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
        before = os.fstat(fd)
        if not stat.S_ISREG(before.st_mode) or before.st_mode & 0o022 or before.st_size > ME.MAX_BUNDLE_BYTES:
            return None, "invalid"
        chunks, size = [], 0
        while True:
            if monotonic() - started > 5:
                return None, "unavailable"
            chunk = os.read(fd, min(65536, ME.MAX_BUNDLE_BYTES + 1 - size))
            if not chunk:
                break
            chunks.append(chunk)
            size += len(chunk)
            if size > ME.MAX_BUNDLE_BYTES:
                return None, "invalid"
        after = os.fstat(fd)
        if (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) != \
                (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns):
            return None, "invalid"
        bundle = ME.validate_bundle(json.loads(b"".join(chunks), object_pairs_hook=_pairs), now)
        if monotonic() - started > 5:
            return None, "unavailable"
        return bundle, None
    except FileNotFoundError:
        return None, "unavailable"
    except (OSError, UnicodeError, ValueError, TypeError, RecursionError, OverflowError, RuntimeError):
        return None, "invalid"
    finally:
        if fd is not None:
            os.close(fd)


def refresh(store, path, now):
    bundle, status = read_bundle(path, now)
    return store.record_market_export(bundle, now, status=status)
