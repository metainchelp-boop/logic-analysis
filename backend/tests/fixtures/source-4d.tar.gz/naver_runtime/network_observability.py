"""Bounded process counters at the existing transport seam, never request data."""
import math
import threading
import time
from datetime import datetime, timezone


SERVICES=frozenset({'naver','erp'})
PHASES=frozenset({'collection','execution','sync','profile'})
METHODS=frozenset({'GET','POST','PUT','OTHER'})
COUNTERS=('attempts','http_responses','http_successes','http_failures','transport_failures','elapsed_ms','latency_samples')
MAXIMUM=2**53-1


class NetworkObservations:
    """RAM since process start. HTTP success does not establish valid source data.

    No URL, header, body, account identifier or caller-controlled label is read.
    The caller begins only after the existing stop/deadline fence permits a send.
    """
    def __init__(self,*,clock=None,monotonic=None):
        self._clock=clock or (lambda:datetime.now(timezone.utc))
        self._monotonic=monotonic or time.monotonic
        self._started_at=self._clock().isoformat()
        self._lock=threading.Lock();self._items={};self._blocked=0

    def blocked(self):
        with self._lock:self._blocked=min(MAXIMUM,self._blocked+1)

    def begin(self,service,phase,method):
        if service not in SERVICES or phase not in PHASES:return None
        method=method if method in METHODS else 'OTHER'
        key=(service,phase,method);started=self._monotonic()
        with self._lock:
            row=self._items.setdefault(key,dict.fromkeys(COUNTERS,0))
            row['attempts']=min(MAXIMUM,row['attempts']+1)
        return key,started

    def finish(self,token,status):
        if token is None:return
        key,started=token;ended=self._monotonic()
        valid=type(status) is int and 100<=status<=599
        latency=type(started) in (int,float) and type(ended) in (int,float) and math.isfinite(started) and math.isfinite(ended) and ended>=started
        with self._lock:
            row=self._items[key]
            code='http_successes' if valid and 200<=status<300 else 'http_failures' if valid else 'transport_failures'
            row[code]=min(MAXIMUM,row[code]+1)
            if valid:row['http_responses']=min(MAXIMUM,row['http_responses']+1)
            if latency:
                row['elapsed_ms']=min(MAXIMUM,row['elapsed_ms']+min(MAXIMUM,int((ended-started)*1000)))
                row['latency_samples']=min(MAXIMUM,row['latency_samples']+1)

    def snapshot(self):
        with self._lock:
            return {'version':1,'available':True,'scope':'process_since_start','durable':False,'account_scoped':False,
                'started_at':self._started_at,'blocked_before_attempt':self._blocked,
                'items':[{'service':key[0],'phase':key[1],'method':key[2],**dict(row)} for key,row in sorted(self._items.items())]}
