"""Best-effort call-local telemetry; never grants authority or retries a provider."""
import logging
from . import provider_observability as P

log=logging.getLogger('naver_runtime.observation')


class CallObservation:
    def __init__(self,provider,prepared,actor,job_id,origin,*,write,clock):
        self.trace=None;self.provider=provider;self.saved=False;self.validation_summary=None
        self.write,self.clock=write,clock
        self.binding_confirmed=False;self.flush_confirmed=False
        try:
            self.trace=P.new_trace(provider,clock=clock)
            self.provider=P.bind_provider(provider,self.trace)
            result=write(lambda st:st.begin_provider_observation(prepared,actor,clock(),job_id,self.trace.trace_id,origin))
            self.binding_confirmed=type(result)is dict and set(result)=={'bound'} and result['bound']is True
        except Exception:
            P.emit(self.trace,'failure',diagnostic='observer-failed')
            log.warning('공급자 관측 결속 미확인')

    @classmethod
    def prepare(cls,provider,*,write,clock):
        """Pure call-local preparation; no writer visit or reservation occurs here."""
        self=cls.__new__(cls)
        self.trace=None;self.provider=provider;self.saved=False;self.validation_summary=None
        self.write,self.clock=write,clock
        self.binding_confirmed=False;self.flush_confirmed=False
        self.trace=P.new_trace(provider,clock=clock)
        self.provider=P.bind_provider(provider,self.trace)
        return self

    def accept_binding(self,result):
        if type(result)is not dict or set(result)!={'bound'} or result['bound']is not True:
            raise P.ObservationInvalid('binding acknowledgement')
        self.binding_confirmed=True

    def validated(self):P.emit(self.trace,'document_validated')
    def draft_saved(self):
        self.saved=True;P.emit(self.trace,'draft_saved')
    def failure(self,error):
        P.emit(self.trace,'failure',diagnostic=P.diagnostic(error))
        try:
            from naver_engine import strategy_validation as V
            summary=V.failure(error)
            if summary is not None and self.validation_summary is None:self.validation_summary=summary
        except Exception:log.warning('공급자 검증 관측 미확인')
    def flush(self):
        self._flush(self.write)

    def flush_in_store(self,store):
        """Reuse an existing final writer visit; never enqueue from its owner."""
        self._flush(lambda fn:fn(store))

    def _flush(self,write):
        if self.trace is None:return
        try:
            snapshot=self.trace.snapshot()
            result=write(lambda st:st.record_provider_observation(self.trace.trace_id,snapshot,self.clock()))
            self.flush_confirmed=(type(result)is dict and set(result)=={'recorded','revision'} and result['recorded']is True
                and type(result['revision'])is int and 1<=result['revision']<=8)
        except Exception:
            log.warning('공급자 관측 저장 미확인');return
        if self.validation_summary is not None:
            try:
                write(lambda st:st.record_provider_validation(self.trace.trace_id,self.validation_summary,self.clock()))
            except Exception:log.warning('공급자 검증 관측 저장 미확인')
