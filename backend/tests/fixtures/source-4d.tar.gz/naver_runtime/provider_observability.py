"""Call-local, bounded provider facts; never prompts, replies or billing proof.

Telemetry is deliberately non-authoritative: a missing event is unknown, and an
observer failure must not change a provider result or cause a second request.
"""
from copy import deepcopy
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation, ROUND_CEILING, localcontext
import hashlib
import json
import re
import threading
import uuid


MAX_EVENTS = 24
MAX_TOKENS = 2**53 - 1
MAX_COST = 2**53 - 1  # Preserve exact JSON integers in the browser as well.
PHASES = frozenset(("logical_invoke", "request_built", "pretransport_rejected",
    "delegate_attempt", "delegate_response", "transport_attempt", "client_request_written",
    "http_response", "usage_parsed", "document_parsed", "document_validated", "draft_saved", "failure"))
TOKEN_FIELDS = ("input_tokens", "output_tokens", "cache_read_input_tokens", "cache_creation_input_tokens",
    "cache_creation_5m_input_tokens", "cache_creation_1h_input_tokens")
PRICE_FIELDS = ("input_usd_per_million", "output_usd_per_million", "cache_read_usd_per_million",
    "cache_creation_5m_usd_per_million", "cache_creation_1h_usd_per_million")
_EVENT_FIELDS = frozenset(("sequence", "phase", "at", "diagnostic", "http_status", "request_bytes", "response_bytes"))
_ESTIMATE_FIELDS = frozenset(("status", "input_microusd", "output_microusd", "cache_microusd",
    "total_microusd", "price_config_fingerprint", "invoice_verified"))
_DIAGNOSTICS = frozenset(("unknown", "timeout", "tls", "network", "protocol", "configuration",
    "request-size", "response-size", "response-shape", "envelope-json", "document-json", "truncated",
    "context-invalid", "document-invalid", "numeric-citation-required", "reference-unavailable",
    "unconnected-evidence", "source-changed", "storage-failed", "observer-failed", "http"))
_ERROR_CODES = {
    "PROVIDER_TIMEOUT": "timeout", "PROVIDER_TLS_ERROR": "tls", "PROVIDER_NETWORK_ERROR": "network",
    "PROVIDER_PROTOCOL_ERROR": "protocol", "PROVIDER_NOT_CONFIGURED": "configuration",
    "PROVIDER_CONFIGURATION_INVALID": "configuration", "PROVIDER_TRANSPORT_DISABLED": "configuration",
    "PROVIDER_REQUEST_SIZE": "request-size", "PROVIDER_RESPONSE_SIZE": "response-size",
    "PROVIDER_RESPONSE_INVALID": "response-shape", "PROVIDER_ENVELOPE_JSON_INVALID": "envelope-json",
    "PROVIDER_DOCUMENT_JSON_INVALID": "document-json", "PROVIDER_RESPONSE_TRUNCATED": "truncated",
    "CONTEXT_INVALID": "context-invalid", "LEARNING_CONTEXT_INVALID": "context-invalid",
    "PLAN_CONTEXT_INVALID": "context-invalid", "DOCUMENT_INVALID": "document-invalid",
    "NUMERIC_CITATION_REQUIRED": "numeric-citation-required", "REFERENCE_UNAVAILABLE": "reference-unavailable",
    "UNCONNECTED_EVIDENCE": "unconnected-evidence",
}


class ObservationInvalid(ValueError):
    pass


def diagnostic(value):
    """Accept only closed codes; never copy exception messages into telemetry."""
    code = value if isinstance(value, str) else getattr(value, "code", None)
    if isinstance(code, str):
        if code in _DIAGNOSTICS:
            return code
        if re.fullmatch(r"PROVIDER_HTTP_[1-5][0-9]{2}", code):
            return "http"
        return _ERROR_CODES.get(code, "unknown")
    return "unknown"


def _count(value, maximum=MAX_TOKENS):
    return type(value) is int and 0 <= value <= maximum


def parse_usage(raw):
    """Unknown/malformed known fields remain null; unrelated fields are discarded."""
    result = {key: None for key in TOKEN_FIELDS}
    if raw is None:
        return {"status": "unavailable", **result}
    if not isinstance(raw, dict):
        return {"status": "invalid", **result}
    invalid = False
    for key in TOKEN_FIELDS[:4]:
        if key not in raw:
            continue
        if _count(raw[key]):
            result[key] = raw[key]
        else:
            invalid = True
    creation = raw.get("cache_creation")
    if creation is not None and not isinstance(creation, dict):
        invalid = True
    if isinstance(creation, dict):
        for source, target in (("ephemeral_5m_input_tokens", TOKEN_FIELDS[4]),
                               ("ephemeral_1h_input_tokens", TOKEN_FIELDS[5])):
            if source in creation:
                if _count(creation[source]):
                    result[target] = creation[source]
                else:
                    invalid = True
    total, five, hour = (result[key] for key in TOKEN_FIELDS[3:])
    if total is not None:
        known_parts = [part for part in (five, hour) if part is not None]
        if sum(known_parts) > total or five is not None and hour is not None and total != five + hour:
            invalid = True
    status = ("invalid" if invalid else "unavailable" if all(v is None for v in result.values())
              else "complete" if all(v is not None for v in result.values()) else "partial")
    return {"status": status, **result}


def _prices(value):
    if value is None:
        return None
    if not isinstance(value, dict) or set(value) != set(PRICE_FIELDS):
        raise ObservationInvalid("price shape")
    result = {}
    for key in PRICE_FIELDS:
        raw = value[key]
        if raw is None:
            result[key] = None
            continue
        if isinstance(raw, bool) or not isinstance(raw, (str, int, Decimal)) or len(str(raw)) > 80:
            raise ObservationInvalid("price value")
        try:
            number = Decimal(str(raw))
            if not number.is_finite() or not 0 < number <= 10000 or number.adjusted() < -30:
                raise ObservationInvalid("price bounds")
        except InvalidOperation:
            raise ObservationInvalid("price value") from None
        result[key] = str(number)
    return result


def configured_estimate(usage, prices):
    """Configured USD estimates, including confirmed cache categories only.

    Tokens * USD/million is numerically micro-USD. It is not an invoice, and
    missing cache usage/TTL/rates never becomes a zero or a complete estimate.
    """
    clean = _prices(prices)
    result = {"status": "unknown", "input_microusd": None, "output_microusd": None,
        "cache_microusd": None, "total_microusd": None, "price_config_fingerprint": None,
        "invoice_verified": False}
    if clean is None:
        return result
    result["price_config_fingerprint"] = hashlib.sha256(json.dumps(clean, sort_keys=True,
        separators=(",", ":")).encode()).hexdigest()
    def fee(count, key):
        if not _count(count):
            return None
        if count == 0:
            return Decimal(0)
        return Decimal(count) * Decimal(clean[key]) if clean[key] is not None else None
    def bounded(value):
        if value is None or not value.is_finite() or value < 0 or value > MAX_COST:
            return None
        return int(value.to_integral_value(rounding=ROUND_CEILING))
    with localcontext() as context:
        context.prec = 100
        ordinary = fee(usage.get("input_tokens"), PRICE_FIELDS[0])
        output = fee(usage.get("output_tokens"), PRICE_FIELDS[1])
        read = fee(usage.get("cache_read_input_tokens"), PRICE_FIELDS[2])
        total, five, hour = (usage.get(key) for key in TOKEN_FIELDS[3:])
        creation = Decimal(0) if total == 0 and type(total) is int else None
        if _count(total) and total > 0 and _count(five) and _count(hour) and total == five + hour:
            a, b = fee(five, PRICE_FIELDS[3]), fee(hour, PRICE_FIELDS[4])
            if a is not None and b is not None:
                creation = a + b
        cache = read + creation if read is not None and creation is not None else None
        result.update(input_microusd=bounded(ordinary), output_microusd=bounded(output), cache_microusd=bounded(cache))
        if usage.get("status") != "invalid" and all(v is not None for v in (ordinary, output, cache)):
            combined = bounded(ordinary + output + cache)
            if combined is not None:
                result.update(status="configured_estimate", total_microusd=combined)
    return result


def _time(value):
    if not isinstance(value, str) or not 20 <= len(value) <= 40:
        raise ObservationInvalid("time")
    try:
        at = datetime.fromisoformat(value)
        if at.tzinfo is None or at.utcoffset() is None:
            raise ValueError()
        return at.astimezone(timezone.utc).isoformat()
    except (ValueError, OverflowError):
        raise ObservationInvalid("time") from None


def normalize_snapshot(value):
    """Strict, bounded storage ABI. Validation never retains arbitrary raw keys."""
    if not isinstance(value, dict) or set(value) != {"version", "trace_id", "events", "usage", "estimate", "telemetry_incomplete"}:
        raise ObservationInvalid("trace shape")
    if type(value["version"]) is not int or value["version"] != 1 or not isinstance(value["trace_id"], str) or not re.fullmatch(r"[0-9a-f]{32}", value["trace_id"]):
        raise ObservationInvalid("trace identity")
    if type(value["telemetry_incomplete"]) is not bool or not isinstance(value["events"], list) or len(value["events"]) > MAX_EVENTS:
        raise ObservationInvalid("trace bounds")
    events = []
    for index, event in enumerate(value["events"], 1):
        if not isinstance(event, dict) or set(event) != _EVENT_FIELDS or type(event["sequence"]) is not int or event["sequence"] != index or not isinstance(event["phase"], str) or event["phase"] not in PHASES:
            raise ObservationInvalid("event shape")
        if event["diagnostic"] is not None and (not isinstance(event["diagnostic"], str) or event["diagnostic"] not in _DIAGNOSTICS):
            raise ObservationInvalid("diagnostic")
        if event["http_status"] is not None and (type(event["http_status"]) is not int or not 100 <= event["http_status"] <= 599):
            raise ObservationInvalid("http status")
        if any(event[key] is not None and not _count(event[key]) for key in ("request_bytes", "response_bytes")):
            raise ObservationInvalid("bytes")
        events.append({**event, "at": _time(event["at"])})
    usage = value["usage"]
    if not isinstance(usage, dict) or set(usage) != {"status", *TOKEN_FIELDS} or usage["status"] not in ("unavailable", "partial", "invalid", "complete") or any(usage[key] is not None and not _count(usage[key]) for key in TOKEN_FIELDS):
        raise ObservationInvalid("usage")
    present = sum(usage[key] is not None for key in TOKEN_FIELDS)
    total, five, hour = (usage[key] for key in TOKEN_FIELDS[3:])
    contradictory = total is not None and (sum(part for part in (five, hour) if part is not None) > total
        or five is not None and hour is not None and total != five + hour)
    if usage["status"] == "complete" and present != len(TOKEN_FIELDS) or usage["status"] == "unavailable" and present != 0 or usage["status"] == "partial" and not 0 < present < len(TOKEN_FIELDS) or contradictory and usage["status"] != "invalid":
        raise ObservationInvalid("usage status")
    estimate = value["estimate"]
    if not isinstance(estimate, dict) or set(estimate) != _ESTIMATE_FIELDS or estimate["status"] not in ("unknown", "configured_estimate") or estimate["invoice_verified"] is not False:
        raise ObservationInvalid("estimate")
    if any(estimate[key] is not None and not _count(estimate[key], MAX_COST) for key in ("input_microusd", "output_microusd", "cache_microusd", "total_microusd")):
        raise ObservationInvalid("cost")
    fp = estimate["price_config_fingerprint"]
    if fp is not None and (not isinstance(fp, str) or not re.fullmatch(r"[0-9a-f]{64}", fp)):
        raise ObservationInvalid("price identity")
    if estimate["status"] == "configured_estimate" and (estimate["total_microusd"] is None or fp is None or usage["status"] in ("invalid", "unavailable")
            or any(usage[key] is None for key in TOKEN_FIELDS[:4])
            or any(estimate[key] is None for key in ("input_microusd", "output_microusd", "cache_microusd"))) or estimate["status"] == "unknown" and estimate["total_microusd"] is not None:
        raise ObservationInvalid("cost status")
    return {**value, "events": events, "usage": deepcopy(usage), "estimate": deepcopy(estimate)}


class Trace:
    def __init__(self, trace_id=None, *, prices=None, clock=None):
        self.trace_id = trace_id or uuid.uuid4().hex
        if not isinstance(self.trace_id, str) or not re.fullmatch(r"[0-9a-f]{32}", self.trace_id):
            raise ObservationInvalid("trace identity")
        self._clock = clock or (lambda: datetime.now(timezone.utc))
        self._events, self._usage, self._incomplete = [], parse_usage(None), False
        self._lock = threading.Lock()
        try:
            self._prices = _prices(prices)
        except Exception:
            self._prices, self._incomplete = None, True

    def record(self, phase, **fields):
        """Nonthrowing observer. Unknown fields are rejected, never stored."""
        try:
            with self._lock:
                allowed = {"diagnostic", "http_status", "request_bytes", "response_bytes"}
                if phase == "usage_parsed":
                    allowed.add("usage")
                if not isinstance(phase, str) or phase not in PHASES or set(fields) - allowed or len(self._events) >= MAX_EVENTS:
                    self._incomplete = True
                    return
                at = self._clock()
                at = _time(at.isoformat() if isinstance(at, datetime) else at)
                event = {"sequence": len(self._events)+1, "phase": phase, "at": at,
                    "diagnostic": diagnostic(fields["diagnostic"]) if fields.get("diagnostic") is not None else None,
                    **{key: fields.get(key) for key in ("http_status", "request_bytes", "response_bytes")}}
                if event["http_status"] is not None and (type(event["http_status"]) is not int or not 100 <= event["http_status"] <= 599) or any(event[key] is not None and not _count(event[key]) for key in ("request_bytes", "response_bytes")):
                    self._incomplete = True
                    return
                if phase == "usage_parsed":
                    self._usage = parse_usage(fields.get("usage"))
                self._events.append(event)
        except Exception:
            self._incomplete = True

    def snapshot(self):
        with self._lock:
            try:
                estimate = configured_estimate(self._usage, self._prices)
            except Exception:
                self._incomplete = True
                estimate = configured_estimate(parse_usage(None), None)
            return {"version": 1, "trace_id": self.trace_id, "events": deepcopy(self._events),
                "usage": deepcopy(self._usage), "estimate": estimate, "telemetry_incomplete": self._incomplete}

    def mark_incomplete(self):
        self._incomplete = True


def emit(observation, phase, **fields):
    """Arbitrary injected observer failures never escape into provider control."""
    if observation is not None:
        try:
            observation.record(phase, **fields)
        except Exception:
            try:
                observation.mark_incomplete()
            except Exception:
                pass


def new_trace(provider, *, trace_id=None, clock=None):
    try:
        prices = getattr(provider, "configured_prices", None)
    except Exception:
        trace = Trace(trace_id, clock=clock)
        trace.mark_incomplete()
        return trace
    return Trace(trace_id, prices=prices, clock=clock)


def bind_provider(provider, trace):
    """Call-bound wrapper; the shared provider never gains mutable observer state."""
    def bound(context):
        invoke = getattr(provider, "invoke", None)
        if callable(invoke):
            return invoke(context, observation=trace)
        emit(trace, "logical_invoke")
        emit(trace, "delegate_attempt")
        try:
            value = provider(context)
            emit(trace, "delegate_response")
            return value
        except Exception as error:
            emit(trace, "failure", diagnostic=diagnostic(error))
            raise
    bound.model = getattr(provider, "model", None)
    return bound
