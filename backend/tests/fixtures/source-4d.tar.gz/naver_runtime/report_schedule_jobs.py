"""One bounded, explicitly delegated Claude draft worker; no session impersonation.

The store rechecks the delegation, current actor and source proof on both visits.
Provider calls own no database connection or collector lock, and are never retried
automatically after an uncertain paid attempt.
"""
import threading
from .observation_binding import CallObservation

from app.naver_auto import scope as SC
from naver_engine import marketing_strategy as STR, report_views as RV, store as S

_CONTEXT_ERRORS = (S.StoreRefused, SC.ScopeError, RV.SourceUnavailable)


_FAILURES = {
    'PROVIDER_TIMEOUT': 'timeout', 'PROVIDER_TLS_ERROR': 'tls',
    'PROVIDER_NETWORK_ERROR': 'network', 'PROVIDER_PROTOCOL_ERROR': 'protocol',
    'PROVIDER_REQUEST_SIZE': 'request-size', 'PROVIDER_RESPONSE_SIZE': 'response-size',
    'PROVIDER_RESPONSE_INVALID': 'response-shape', 'PROVIDER_ENVELOPE_JSON_INVALID': 'envelope-json',
    'PROVIDER_DOCUMENT_JSON_INVALID': 'document-json', 'PROVIDER_RESPONSE_TRUNCATED': 'truncated',
    'PROVIDER_CONFIGURATION_INVALID': 'configuration', 'PROVIDER_NOT_CONFIGURED': 'configuration',
    'PROVIDER_TRANSPORT_DISABLED': 'configuration', 'CONTEXT_INVALID': 'context-invalid',
    'LEARNING_CONTEXT_INVALID': 'context-invalid', 'PLAN_CONTEXT_INVALID': 'context-invalid',
    'DOCUMENT_INVALID': 'document-invalid', 'NUMERIC_CITATION_REQUIRED': 'numeric-citation-required',
    'REFERENCE_UNAVAILABLE': 'reference-unavailable', 'UNCONNECTED_EVIDENCE': 'unconnected-evidence',
}


def diagnostic(error):
    """Only closed codes; never exception text, credentials or model responses."""
    code = getattr(error, 'code', None)
    if type(code) is str and code.startswith('PROVIDER_HTTP_'):
        suffix = code[len('PROVIDER_HTTP_'):]
        if len(suffix) == 3 and suffix.isascii() and suffix.isdigit() and 100 <= int(suffix) <= 599:
            return {'code': 'http', 'http_status': int(suffix)}
    return {'code': _FAILURES.get(code, 'unknown') if type(code) is str else 'unknown', 'http_status': None}


class Stopped(Exception):
    pass


class Worker:
    """One launch per tick, sharing the manual provider gate and save fence.

    ``write`` is the existing single-writer callback (fn -> result). It runs
    ``fn(store)`` on the owner thread, and never returns before a started write
    finishes. No JWT, request reader or Claims object is accepted here.
    """
    def __init__(self, write, provider, gate, *, clock, stopped=None, commit_lock=None,
                 thread_factory=None, observation_write=None):
        self.write, self.provider, self.gate, self.clock = write, provider, gate, clock
        self.observation_write=observation_write if observation_write is not None else write
        self._external_stop = stopped or (lambda: False)
        self._commit_lock = commit_lock if commit_lock is not None else threading.Lock()
        self._thread_factory = thread_factory or threading.Thread
        self._lock = threading.Lock()
        self._stopped = threading.Event()
        self._needs_recovery = False
        self._started = False
        self._thread = None

    @property
    def stopped(self):
        return self._stopped.is_set() or self._external_stop()

    def _commit(self, fn):
        # This brief fence is acquired inside the writer visit, never during HTTP.
        with self._commit_lock:
            if self.stopped:
                raise Stopped()
            return fn()

    def _visit(self, method, *args, **kwargs):
        return self.write(lambda st: self._commit(lambda: getattr(st, method)(*args, **kwargs)))

    def _recover(self):
        # Recovery only records safety states; it must remain possible after stop.
        result = self.write(lambda st: st.report_schedule_recover(self.clock()))
        self._needs_recovery = False
        return result

    def start(self):
        with self._lock:
            if not self._started:
                self._recover()
                self._started = True

    def tick(self):
        with self._lock:
            if self.stopped:
                return {'state': 'stopped', 'considered': 0, 'created': 0, 'launched': 0}
            if not self._started:
                self._recover()
                self._started = True
            if self._thread is not None and self._thread.is_alive():
                return {'state': 'busy', 'considered': 0, 'created': 0, 'launched': 0}
            if self._needs_recovery:
                self._recover()
            work = self._visit('report_schedule_work', self.clock(), limit=10)
            result = {'state': 'idle', 'considered': work['considered'], 'created': work['created'], 'launched': 0}
            if self.provider is None:
                return {**result, 'state': 'provider_disabled'}
            if not work['jobs']:
                return result
            if not self.gate.acquire(blocking=False):
                return {**result, 'state': 'busy'}
            job = work['jobs'][0]
            try:
                self._thread = self._thread_factory(target=self._run, args=(job,),
                    name='naver-scheduled-claude-draft', daemon=True)
                self._thread.start()
            except BaseException:
                self.gate.release()
                # No reserve/provider start occurred. The exact queued job is safe
                # for a later launch; a launch failure is never a second paid call.
                self._thread = None
                raise
            return {**result, 'state': 'started', 'launched': 1}

    def _run(self, job):
        current, invoked, received, scope_changed = job, False, False, False
        observation=None
        try:
            if self.stopped:
                return
            observation=CallObservation.prepare(self.provider,write=self.observation_write,clock=self.clock)
            reservation = self.write(lambda st: self._commit(lambda: st.report_schedule_reserve_observed(
                current['job_id'], current['version'], self.clock(),
                getattr(self.provider, 'maximum_call_microusd', None),
                getattr(self.provider, 'monthly_budget_microusd', None),
                unlimited=getattr(self.provider, 'monthly_budget_unlimited', False),trace_id=observation.trace.trace_id)))
            current, prepared = reservation['job'], reservation['prepared']
            observation.accept_binding(reservation['binding'])
            if self.stopped:
                return

            def invoke(context):
                nonlocal current, invoked, received, scope_changed
                if self.stopped:
                    raise Stopped()
                try:
                    current = self._visit('report_schedule_started', current['job_id'], current['version'], self.clock())
                except _CONTEXT_ERRORS:
                    scope_changed = True
                    raise
                invoked = True
                if self.stopped:
                    raise Stopped()
                candidate = observation.provider(context)
                received = True
                current = self._visit('report_schedule_response', current['job_id'], current['version'], self.clock())
                return candidate
            invoke.model = getattr(self.provider, 'model', None)
            generated = STR.generate(prepared['payload'], provider=invoke,
                learning_context=prepared['learning_context'], plan_context=prepared['plan_context'],
                product_context=prepared['product_context'],
                market_context=(prepared['market_context'] if prepared['market_context']['state'] == 'stored_search_sample' else None),
                **({'funnel_context': prepared['funnel_context']} if prepared.get('funnel_context') is not None else {}))
            observation.validated()
            def finish(st):
                result=st.report_schedule_finish(current['job_id'],current['version'],generated,self.clock())
                observation.draft_saved()
                observation.flush_in_store(st)
                return result
            self.write(lambda st:self._commit(lambda:finish(st)))
        except BaseException as error:
            if observation is not None:observation.failure(error)
            if self.stopped or isinstance(error, Stopped):
                # close/restart records provider-started attempts as unknown.
                self._needs_recovery = True
                return
            code = diagnostic(error)
            if scope_changed or isinstance(error, _CONTEXT_ERRORS):
                state = 'source_changed'
                code = {'code': 'context-changed', 'http_status': None}
            else:
                state = 'failed' if received or not invoked else 'unknown'
            try:
                def fail(st):
                    result=st.report_schedule_fail(current['job_id'],current['version'],self.clock(),state=state,diagnostic=code)
                    if observation is not None:observation.flush_in_store(st)
                    return result
                self.write(lambda st:self._commit(lambda:fail(st)))
            except BaseException:
                # A writer failure cannot establish whether a preceding transition
                # committed. Durable recovery inspects the ledger, never sends again.
                self._needs_recovery = True
        finally:
            if observation is not None and not observation.flush_confirmed:observation.flush()
            self.gate.release()

    def close(self):
        with self._lock:
            with self._commit_lock:
                self._stopped.set()
            if self._started:
                self._recover()
            thread = self._thread
        if thread is not None and thread is not threading.current_thread():
            thread.join(1)
