"""기존 부를 때 판정들을 한 회차로 연결한다. 네이버 쓰기는 없다."""
from datetime import datetime, time, timedelta
from copy import deepcopy
import logging
import threading
from time import monotonic

from naver_engine import alerts as A, links as L, morning as M, store as S, sync as Y, metrics as G, naver_read as N
from naver_engine import inventory as IC, performance_reads as PR, management_store as MS, structure_reads as SR, inspection_reads as SI, funnel_reads as FR, experiments_reads as ER, randomized_experiments_reads as RR
from naver_runtime import collection_requests as CR
from naver_runtime.runtime_status import RuntimeStatus, SOURCE_STEPS

log = logging.getLogger("naver_runtime.scheduler")

# 보고서 회차 조각 상한 — 여는 조각 1 + 업체 최대 20 + 여유. 넘으면 회차가 끝나지 않는 것으로 보고 실패로 남긴다
# (저장소에 남은 회차는 다음 회차의 cycle=0 이 버린다).
REPORT_SLICES_MAX = 64


def run_report_cycle(store, now, *, progress=None):
    """보고서 한 회차를 조각으로 부른다(NV-S00). 조각 하나 = 쓰기 줄 항목 하나 — 등록 거래 1 + 업체 한 곳씩.

    예전에는 한 항목이 회차 전체를 쥐어(판이 쌓인 운영에서 10~20초) 그 뒤에 선 직원 로그인 감사가 15초를 넘겨
    「감사 기록 불가」로 막혔다. 조각 사이에는 쓰기 줄에 먼저 들어온 감사가 실행된다. 시각은 회차 내내 같은 값을 넘긴다.
    """
    calls, result = 1, store.generate_reports(now, cycle=0)
    if progress is not None:
        progress()
    while isinstance(result, dict) and "cycle" in result:
        if calls >= REPORT_SLICES_MAX:
            raise RuntimeError("보고서 회차가 끝나지 않았습니다")
        calls += 1
        result = store.generate_reports(now, cycle=result["cycle"])
        if progress is not None:
            progress()
    return result


class _ManagedMorningStore:
    """자동 아침 상세 점검도 실관리 대상만 읽게 한다. 이관 부재 판정은 유지한다."""
    def __init__(self, store, now, exclude_customers=()):
        self.store = store
        self.excluded = frozenset(exclude_customers)
        self.policies = MS.snapshot(store,now)
        self.daily = {cid for cid,row in self.policies.items() if row["decision"].cadence == "daily"}
        # 동적 메서드 노출 없이 아침 읽기/판정에서 사용하는 공개 계약만 전달한다.
        self.account_day_marks_on = store.account_day_marks_on
        self.accounts = store.accounts
        self.account_days_on = store.account_days_on
        self.accounts_read_at = store.accounts_read_at
        self.begin_run = store.begin_run
        self.decision_fingerprint = store.decision_fingerprint
        self.finish_run = store.finish_run
        self.issues = store.issues
        self.last_pairing = store.last_pairing
        self.last_sync = store.last_sync
        self.my_running_runs = store.my_running_runs
        self.prospects = store.prospects
        self.record_account_check = store.record_account_check
        self.runs_on = store.runs_on
        self.stage_as_of = store.stage_as_of

    def morning_progress(self, *args):
        return self.store.morning_progress(*args)

    def begin_morning_progress(self, *args):
        return self.store.begin_morning_progress(*args)

    def record_morning_progress(self, *args):
        return self.store.record_morning_progress(*args)

    def finish_morning_progress(self, *args, **kwargs):
        return self.store.finish_morning_progress(*args, **kwargs)

    def pairing_rows(self, pairing_id):
        # 구형 14일 eligibility 때문에 짝 목록에서 빠진 현재 관리계정도 원천으로 구성한다.
        confirmed = {(d.possibility_id,d.customer_id) for d in self.store.current_decisions() if d.decision == "confirmed"}
        rows = [{"customer_id":cid,"possibility_id":row["possibility_id"],
                 "state":S.PAIR_CONFIRMED if (row["possibility_id"],cid) in confirmed else S.PAIR_AUTO,
                 "code":None,"link":None} for cid,row in self.policies.items()
                if cid in self.daily and cid not in self.excluded]
        present = {r["customer_id"] for r in self.store.accounts() if r["present"] == 1}
        if pairing_id is not None:
            rows.extend(r for r in self.store.pairing_rows(pairing_id)
                        if r["state"] in (S.PAIR_BROKEN,S.PAIR_MISSING) and r.get("customer_id") not in present)
        return rows

    def monitoring_readiness(self, now):
        _, state = IC.catalog_status(self.store, now)
        if self.store.inventory_snapshot(now) is None:
            return M.Readiness((M.CODE_ACCOUNTS_STEP_PENDING,))
        if state != "accepted" or any(not row["source_current"] for row in self.policies.values()):
            return M.Readiness((M.CODE_PAIRING_STALE,))
        pairing = self.store.last_pairing(S.SYNC_ACCEPTED)
        return M.Readiness((), None if pairing is None else pairing["pairing_id"])

    def close_unlinked_issues(self, run_id, pairing_id, at):
        return self.store.close_unlinked_issues(run_id, pairing_id, at, account_monitoring=True)

    def monitoring_context(self, customer_id, possibility_id, now):
        row = MS.snapshot(self.store, now).get(customer_id)
        if not row or row["decision"].cadence != "daily" or row["possibility_id"] != possibility_id:
            return None
        if not self.store.inventory_account_valid(customer_id, row["snapshot_at"], now):
            return None
        if not self.store.collection_account_ready(customer_id, now):
            return None
        return dict(row, stage_as_of=datetime.fromisoformat(self.store.account_catalog()["generated_at"]))


class Scheduler:
    def __init__(self, config, store, *, erp_factory=None, naver_factory=None,
                 alert_factory=None, metrics_factory=None, clock=None, backup_job=None,
                 collection_factory=None, monotonic_clock=None, runtime_state=None, product_refresh=None, market_refresh=None, execution_factory=None,
                 report_schedule_jobs=None):
        self.config, self.store = config, store
        self.erp_factory, self.naver_factory = erp_factory, naver_factory
        self.alert_factory, self.backup_job = alert_factory, backup_job
        self.metrics_factory = metrics_factory
        self.collection_factory = collection_factory
        self.product_refresh = product_refresh
        self.market_refresh = market_refresh
        self.execution_factory = execution_factory
        self.report_schedule_jobs = report_schedule_jobs
        self.clock = clock or (lambda: datetime.now(S.KST))
        self._monotonic = monotonic_clock or monotonic
        self._runtime = runtime_state or RuntimeStatus(enabled=config.inventory_enabled,
                                                       clock=self.clock, monotonic=self._monotonic)
        self.policy = A.AlertPolicy(config.issue_alerts_from, config.issue_alerts_enabled)
        self._lock = threading.Lock()
        self._last = {}
        self._next_steps = {}
        self._inventory_ready_at = 0.0
        self._naver_rate_ready_at = 0.0
        self._naver_pacer = N.RequestPacer()
        self._morning_retry_at = {}
        self._inventory_customers = frozenset()
        self._secondary_turn = 0
        self.last_tick = None
        self.last_errors = ()
        self._collection_lock = threading.Lock()
        self._collection_pending = None
        self._collection_latest = None

    def runtime_status(self):
        return self._runtime.snapshot()

    def _reader(self, factory=None):
        reader = (factory or self.naver_factory)()
        if isinstance(reader, N.NaverReader):
            reader.share_pacing(self._naver_pacer)
        return reader

    @staticmethod
    def _runtime_problem(name, result):
        if name in SOURCE_STEPS:
            outcome = result.get("state") if isinstance(result, dict) else (
                result.outcome if isinstance(result, (Y.SyncResult, L.PairingOutcome)) else None)
            if outcome in ("failed", "refused", "braked"):
                codes = result.codes if isinstance(result, (Y.SyncResult, L.PairingOutcome)) else ()
                if any(isinstance(code, str) and (code == N.KIND_KEY_REJECTED
                       or code.startswith(N.KIND_KEY_REJECTED + "-") or code in ("status-401", "status-403"))
                       for code in codes):
                    return "blocked", "AUTH_REQUIRED"
                if (isinstance(result, Y.SyncResult) and result.needs_confirmation) or outcome == "braked":
                    return "blocked", "SOURCE_CONFIRMATION_REQUIRED"
                return "blocked", "SOURCE_SYNC_FAILED"
        if name in ("inventory", "structure", "inspection", "funnel", "experiments", "randomized_experiments") and isinstance(result, (PR.PerformanceOutcome, SR.StructureOutcome, SI.InspectionOutcome, FR.FunnelOutcome, ER.ExperimentsOutcome, RR.Outcome)) \
                and result.code in ("NOT_READY", "SOURCE_CHANGED"):
            return "blocked", "SOURCE_NOT_READY" if result.code == "NOT_READY" else "SOURCE_CHANGED"
        if name == "morning" and isinstance(result, M.MorningOutcome):
            codes = result.codes
            if any(code in codes for code in (M.CODE_KEY_REJECTED_ALL, M.CODE_KEY_REJECTED_MANY)):
                return "blocked", "AUTH_REQUIRED"
            if any(code in M.BLOCKING for code in codes):
                return "blocked", "SOURCE_NOT_READY"
            if result.outcome == M.OUT_FAILED:
                return "error", "RUNTIME_ERROR"
        return None

    def request_collection(self, actor):
        """대표 화면에서 검증한 요청을 접수만 한다. 네트워크는 tick에서만 실행한다."""
        with self._collection_lock:
            if self.collection_factory is None or not CR.restricted(self.config):
                return CR.refused("RESTRICTED_CONFIG_REQUIRED")
            try:
                if not CR.owner_allowed(self.store, actor, self.clock()):
                    return CR.refused("OWNER_REQUIRED")
                if self._collection_latest and self._collection_latest["status"] in ("accepted", "running"):
                    return dict(deepcopy(self._collection_latest), status="busy", codes=["COLLECTION_BUSY"])
                code = CR.request_limit(self.store, self.clock())
                if code:
                    return CR.refused(code)
                requested_at = self.clock()
                request_id = self.store.record_access(actor, "collection_request", "board", None,
                                                       "accepted", requested_at)
            except Exception:
                return CR.refused("AUDIT_UNAVAILABLE")
            self._collection_pending = (request_id, actor, requested_at)
            self._collection_latest = {"id": request_id, "status": "accepted", "codes": []}
            return deepcopy(self._collection_latest)

    def collection_status(self, *, read_store=None):
        """현재 메모리 상태를 먼저 본다. HTTP 복구 조회는 요청의 읽기 연결만 사용한다."""
        with self._collection_lock:
            if self._collection_latest is None and self.collection_factory is not None:
                try:
                    return CR.recovered_status(self.store if read_store is None else read_store)
                except Exception:
                    return {"id": None, "status": "failed", "codes": ["AUDIT_UNAVAILABLE"]}
            return deepcopy(self._collection_latest or {"id": None, "status": "idle", "codes": []})
    collection_status.read_store_supported = True

    def _run_collection(self):
        with self._collection_lock:
            if self._collection_pending is None:
                return False
            request_id, actor, requested_at = self._collection_pending
            self._collection_pending = None
            self._collection_latest = {"id": request_id, "status": "running", "codes": []}
        result = {"status": "failed", "codes": ["AUDIT_UNAVAILABLE"]}
        self._runtime.begin_step("collection")
        try:
            self.store.record_access(actor, "collection_run", "board", request_id, "started", self.clock())
            if not CR.restricted(self.config):
                result = CR.refused("RESTRICTED_CONFIG_REQUIRED")
            elif not CR.owner_allowed(self.store, actor, self.clock()):
                result = CR.refused("OWNER_REQUIRED")
            elif (self.clock() - requested_at >= timedelta(minutes=10)
                  or self.clock().astimezone(S.KST).date() != requested_at.astimezone(S.KST).date()):
                result = CR.refused("REQUEST_EXPIRED")
            else:
                code = CR.request_limit(self.store, self.clock(), exclude_id=request_id)
                if code:
                    result = CR.refused(code)
                else:
                    options = dict(self.collection_factory())
                    factory = options.get("naver_factory")
                    if factory:
                        options["naver_factory"] = lambda: self._reader(factory)
                    result = CR.collect(self.store, actor, options)
        except N.RunAbort:
            result = {"status": "failed", "codes": ["COLLECTION_DEADLINE"]}
        except Exception:
            result = {"status": "failed", "codes": ["COLLECTION_FAILED"]}
        except BaseException:
            result = {"status": "failed", "codes": ["COLLECTION_INTERRUPTED"]}
            raise
        finally:
            try:
                self.store.record_access(actor, "collection_run", "board", request_id,
                                         result["status"], self.clock())
            except Exception:
                result = {"status": "failed", "codes": ["AUDIT_UNAVAILABLE"]}
            with self._collection_lock:
                self._collection_latest = dict(result, id=request_id)
            problem = ("error", "RUNTIME_ERROR") if result["status"] == "failed" else None
            if any(code in result.get("codes", ()) for code in
                   ("HOLD_PENDING", "ORG_NOT_ACCEPTED", "STAGES_NOT_ACCEPTED", "ACCOUNTS_NOT_ACCEPTED", "PAIRING_NOT_ACCEPTED")):
                problem = ("blocked", "SOURCE_NOT_READY")
            self._runtime.finish_step("collection", problem)
            self._cycle_verified = result["status"] in ("done", "partial") and problem is None
        if result["status"] in ("failed", "partial"):
            self._errors.append("collection")
        return True

    def _step(self, name, action, *, note=True):
        now = self._monotonic()
        last = self._last.get(name)
        interval = 300 if name in ("product_source", "market_source") else 30 if name == "inventory" else 60
        due = last + interval if last is not None else now
        if name == "inventory":
            due = self._inventory_ready_at
        if name in ("accounts", "inventory", "morning"):
            due = max(due, self._naver_rate_ready_at)
        self._next_steps[name] = due
        if now < due:
            return
        self._last[name] = now
        self._next_steps[name] = now + interval
        if name == "inventory":
            # 일이 없거나 예외인 회차만 짧게 쉰다. HTTP 작업이 있으면 _inventory가 즉시 이어준다.
            self._inventory_ready_at = now + interval
        self._runtime.begin_step(name)
        try:
            result = action()
            if note and result is not None:
                A.note(self.store, self.clock(), result)
            problem = self._runtime_problem(name, result)
            if problem is None and name in self._errors:
                problem = ("error", "RUNTIME_ERROR")
            self._runtime.finish_step(name, problem)
        except Exception as exc:
            self._runtime.finish_step(name, ("error", "RUNTIME_ERROR"))
            # 비밀값/업체명/금액이 섞일 수 있는 예외 문자열은 기록하지 않는다.
            log.error("예약 작업 실패: %s %s", name, type(exc).__name__)
            self._errors.append(name)
            source = name if name in A.SOURCE_NAMES else "morning"
            try:
                A.record_system_alert(self.store, self.clock(), source, ["RUNTIME_FAILED"])
            except Exception:
                log.error("예약 작업 실패 기록을 저장하지 못했습니다")

    def next_delay(self):
        """회차 실행 시간을 포함한 다음 예약 대기. 비수집 회차는 60초를 유지한다."""
        if not self.config.inventory_enabled or not self._next_steps:
            return 60.0
        return min(60.0, max(0.0, min(self._next_steps.values()) - self._monotonic()))

    def _hold_naver_rate(self, reader):
        """자동 네이버 단계만 429 휴식을 공유한다. 일반 수집 간격과는 별개다."""
        if isinstance(reader, N.NaverReader) and reader.rate_limited:
            self._naver_rate_ready_at = max(self._naver_rate_ready_at, self._monotonic() + N.RATE_PAUSE)
            self._runtime.rate_pause(self._naver_rate_ready_at)
            for name in ("accounts", "inventory", "morning"):
                if name in self._next_steps:
                    self._next_steps[name] = max(self._next_steps[name], self._naver_rate_ready_at)

    def tick(self):
        result = self._tick()
        # The number collector releases its cycle lock before any paid worker launch.
        # A later collector cycle may run concurrently; the worker owns no collector lock.
        if result.get("state") != "busy" and self.report_schedule_jobs is not None:
            try:
                self.report_schedule_jobs.tick()
            except Exception as error:
                log.error("보고서 예약 작업 실패: %s", type(error).__name__)
                self.last_errors = tuple((*self.last_errors, "report_schedule"))
                result = {**result, "state": "failed", "errors": list(self.last_errors)}
        return result

    def _tick(self):
        if not self._lock.acquire(blocking=False):
            return {"state": "busy"}
        try:
            self._runtime.begin_cycle()
            self._cycle_idle = False
            self._cycle_verified = False
            self._errors = []
            self._next_steps = {}
            self._inventory_customers = frozenset()
            if self.product_refresh is not None:
                self._step("product_source", self.product_refresh, note=False)
            if self.market_refresh is not None:
                self._step("market_source", self.market_refresh, note=False)
            if self._run_collection():
                # 준비 조회를 다시 반복하지 않는다. 다음 일반 예약 회차는 원래 주기로 판정한다.
                if self.config.inventory_enabled or self.config.execution_enabled:
                    self._step("learning_sources",lambda:self.store.refresh_learning_sources(self.clock(),limit=10),note=False)
                self.last_tick = self.clock()
                self.last_errors = tuple(self._errors)
                self._runtime.finish_cycle(self.next_delay(), verified=self._cycle_verified)
                return {"state": "failed" if self.last_errors else "ok", "errors": list(self.last_errors)}
            c, st = self.config, self.store
            if c.sync_enabled:
                if Y.org_due(st, self.clock()) or (c.inventory_enabled and self._midnight_source_due(S.SYNC_ORG)):
                    self._step("org", lambda: Y.sync_org(self.erp_factory(), st, self.clock(), account_monitoring=c.inventory_enabled))
                if Y.stages_due(st, self.clock()) or (c.inventory_enabled and self._midnight_source_due(S.SYNC_STAGES)):
                    self._step("stages", lambda: Y.sync_stages(self.erp_factory(), st, self.clock()))
            if c.links_enabled or c.inventory_enabled:
                if L.accounts_due(st, self.clock()):
                    self._step("accounts", self._accounts)
            if c.links_enabled:
                if L.pairing_due(st, self.clock()):
                    self._step("pairing", lambda: L.pair_links(self.erp_factory(), st, self.clock()))
            if c.inventory_enabled:
                if IC.sync_catalog_due(st, self.clock()) or self._midnight_catalog_due():
                    self._step("inventory_catalog", lambda: IC.sync_catalog(self.erp_factory(), st, self.clock()), note=False)
                self._step("inventory", lambda: self._inventory(), note=False)
                self._step("reports", lambda: run_report_cycle(st, self.clock(),
                           progress=self._runtime.step_progress), note=False)
            if c.morning_enabled:
                now = self.clock().astimezone(S.KST)
                if M.CHECK_START <= now.time().replace(tzinfo=None) < M.CHECK_DEADLINE:
                    self._step("readiness", lambda: _ManagedMorningStore(st, self.clock()).monitoring_readiness(self.clock())
                               if c.inventory_enabled else M.readiness(st, self.clock()))
                due = M.continuous_due(_ManagedMorningStore(st, self.clock()), self.clock()) \
                    if c.inventory_enabled else M.morning_due(st, self.clock())
                if due:
                    self._step("morning", self._morning)
            # 긴 암호화/전송 때문에 시스템 알림과 아침 심박이 밀리지 않도록 먼저 처리한다.
            if c.alerts_enabled:
                self._step("alerts", lambda: self._alerts(), note=False)
            if c.backup_enabled:
                self._step("backup", lambda: self._backup(), note=False)
            if c.metrics_enabled:
                # 공유 성과 재수집/재전송은 아침 심박·백업 뒤에 제한된 회차로 수행한다.
                self._step("metrics", lambda: self._metrics(), note=False)
            if c.execution_enabled:
                self._step("execution", self._execution, note=False)
            if c.inventory_enabled or c.execution_enabled:
                self._step("learning_sources",lambda:self.store.refresh_learning_sources(self.clock(),limit=10),note=False)
            self.last_tick = self.clock()
            self.last_errors = tuple(self._errors)
            self._runtime.finish_cycle(self.next_delay(), idle=self._cycle_idle, verified=self._cycle_verified)
            return {"state": "failed" if self.last_errors else "ok", "errors": list(self.last_errors)}
        except BaseException:
            self._runtime.fail_cycle()
            raise
        finally:
            self._lock.release()

    def _midnight_source_due(self, kind):
        now = self.clock().astimezone(S.KST)
        start = datetime.combine(now.date(), time(0, 1), tzinfo=S.KST)
        if now < start or Y._hold_open(self.store, kind, now):
            return False
        last = self.store.last_sync(kind)
        return last is None or (isinstance(last, dict) and Y._aware(last.get("at")) is not None
                                and Y._aware(last["at"]) < start)

    def _midnight_catalog_due(self):
        now = self.clock().astimezone(S.KST)
        start = datetime.combine(now.date(), time(0, 1), tzinfo=S.KST)
        state = self.store.account_catalog_status()
        if now < start:
            return False
        if state is None:
            return True
        if not isinstance(state, dict):
            return False
        at = Y._aware(state.get("at"))
        return at is None or at < start or at > now

    def _accounts(self):
        reader = self._reader()
        try:
            return L.sync_accounts(reader, self.store, self.clock())
        finally:
            self._hold_naver_rate(reader)

    def _morning(self):
        reader = self._reader()
        try:
            if not self.config.inventory_enabled:
                return M.run_morning(reader, self.store, self.clock, th=self.store.thresholds())
            # 기존 경보/준비검사는 유지하되 상세 점검이 다음 성과 회차를 장시간 막지 않는다.
            with reader.bounded_requests(max_calls=24, max_seconds=30, yield_on_timeout=True):
                excluded = self._inventory_customers | {cid for cid,at in self._morning_retry_at.items()
                                                        if at > self._monotonic()}
                return M.run_continuous(reader, _ManagedMorningStore(self.store, self.clock(), excluded),
                                        self.clock, th=self.store.thresholds())
        finally:
            if self.config.inventory_enabled:
                # 미완료 첫 계정만 매분 반복해 꼬리를 굶기지 않는다. 완료 계정은 날짜 원장이 제외한다.
                self._morning_retry_at = {cid:at for cid,at in self._morning_retry_at.items() if at > self._monotonic()}
                self._morning_retry_at.update({cid:self._monotonic()+120 for cid in reader.called_customers})
            self._hold_naver_rate(reader)

    def _backup(self):
        if self.backup_job is None:
            raise RuntimeError("백업 실행기가 없습니다")
        result = self.backup_job(self.store, self.clock())
        if result.code not in ("WAITING_FOR_MORNING", "RETRY_WAIT", "ALREADY_BACKED_UP", "OFFSITE_OK"):
            self._errors.append("backup")
            A.record_system_alert(self.store, self.clock(), "morning", ["BACKUP_FAILED"])
        return result

    def _inventory(self):
        reader = self._reader()
        # 전일·일요일·수동·보고기간 보충이 한 대기열과 같은 호출 예산을 공유한다.
        started = reader._clock.monotonic()
        before = reader.calls
        secondary = {}
        try:
            with reader.bounded_requests(max_calls=24, max_seconds=40):
                result = PR.run_performance(reader, self.store, self.clock, max_calls=18, max_seconds=30)
                lanes = [("structure", SR.run_structure), ("inspection", SI.run_inspection), ("funnel", FR.run_funnel), ("experiments", ER.run_experiments), ("randomized_experiments", RR.run_randomized)]
                lanes = lanes[self._secondary_turn:]+lanes[:self._secondary_turn]
                self._secondary_turn = (self._secondary_turn+1) % len(lanes)
                for name, collect in lanes:
                    calls_left = 24-(reader.calls-before)
                    seconds_left = min(20, 40-(reader._clock.monotonic()-started))
                    if calls_left < 2 or seconds_left <= 0 or reader.rate_limited or \
                            result.code in ("NOT_READY", "SOURCE_CHANGED"):
                        break
                    # 보조 원천을 순환해 우선 처리한다. 같은 회차에서 이미 읽은 계정은
                    # 제외해 계정당 8건과 전체 24건/40초 예산을 늘리지 않는다.
                    observed = collect(reader, self.store, self.clock, max_calls=min(6, calls_left),
                        max_seconds=seconds_left, exclude_customers=reader.called_customers)
                    secondary[name] = observed
                    self._runtime.finish_step(name, self._runtime_problem(name, observed))
                    if observed.code == "SOURCE_CHANGED":
                        break
        finally:
            self._inventory_customers = reader.called_customers
            if reader.calls > before:
                # 호출 간격은 공유 pacer가 보장한다. 완료 후 고정 30초 공백은 두지 않는다.
                self._inventory_ready_at = self._monotonic()
                self._next_steps["inventory"] = self._inventory_ready_at
            self._hold_naver_rate(reader)
        # 개별 계정의 실패·재시도는 원장 경고로 남고, 원천 무효만 서비스 실패이다.
        if result.code in ("NOT_READY", "SOURCE_CHANGED"):
            self._errors.append("inventory")
        self._cycle_idle = result.code == "DONE" and not result.counts and not any(item.counts for item in secondary.values())
        self._cycle_verified = result.code in ("DONE", "BUDGET") and all(
            self._runtime_problem(name, value) is None for name, value in secondary.items())
        return result

    def _metrics(self):
        result = G.run_metrics(self.metrics_factory(), self.store, self.clock, self.alert_factory())
        bad_counts = any(result.counts.get(name, 0) for name in ('held', 'retry', 'no_client'))
        if result.code not in ('OUTSIDE_WINDOW', 'RETRY_WAIT', 'DONE') or bad_counts:
            self._errors.append('metrics')
            A.record_system_alert(self.store, self.clock(), 'metrics', ['METRICS_INCOMPLETE'])
        return result

    def _alerts(self):
        poster = self.alert_factory()
        if self.config.morning_enabled:
            return A.run_alerts(self.store, self.clock(), poster, self.policy)
        # 준비 단계에는 아침 점검을 일부러 안 돌린다. 거짓 미점검/정상 심박을 만들지 않는다.
        return A.dispatch(self.store, self.clock(), poster, kind=S.ALERT_SYSTEM)


    def _randomized_execution_slot(self):
        """A due approved assignment reserves a command or performs GET-only verification."""
        from naver_engine import naver_write as NW, execution_commands as EC
        due=self.store.randomized_execution_due(self.clock(),limit=1)
        if not due:return None
        prepared=self.store.randomized_prepare_execution(due[0],self.clock())
        if prepared['state']!='read_only_preflight':return {'state':'randomized_'+prepared['state']}
        command,binding=prepared['command'],prepared['due'];adapter=self.execution_factory()
        if hasattr(adapter,'share_pacing'):adapter.share_pacing(self._naver_pacer)
        try:
            handle=NW.issue_command_handle(command,now=self.clock(),expires_at=self.clock()+timedelta(seconds=20),phase='preflight',
                validate=lambda:self.store.randomized_due_valid(binding,self.clock()))
            result=adapter.preflight(handle)
            row=result['preflight']['target'] if result['state']=='ready' else None
            readback=EC.verify_readback(command,row) if row is not None else None
            receipt={'state':'confirmed' if readback and readback['state']=='confirmed' else 'unknown',
                'origin':'read_only_preflight','checked_at':self.clock().isoformat(),'readback':readback}
        except Exception:
            receipt={'state':'unknown','origin':'read_only_preflight','checked_at':self.clock().isoformat(),'readback':None}
        self.store.randomized_record_switch(binding['approval_ref'],binding['block_id'],binding['step'],receipt,self.clock())
        return {'state':'randomized_preflight_checked'}

    def _execution(self):
        """One execution slot after reads. Separate closed six-call/20-second adapter budget."""
        if not self.config.execution_enabled or self.execution_factory is None:return {'state':'disabled'}
        from naver_engine import naver_write as NW
        if hasattr(self.store,'randomized_sync_execution_receipts'):
            self.store.randomized_sync_execution_receipts(self.clock())
        # Incorporate an on-time durable readback before classifying a missed window.
        if hasattr(self.store,'randomized_advance'):
            self.store.randomized_advance(self.clock())
        if hasattr(self.store,'randomized_refresh_execution_sources'):
            self.store.randomized_refresh_execution_sources(self.clock(),limit=1)
        evaluated=self.store.execution_evaluate(self.clock(),limit=1)
        work=self.store.execution_work(self.clock(),limit=1)
        if not work:
            if hasattr(self.store,'randomized_execution_due'):
                randomized=self._randomized_execution_slot()
                if randomized:return randomized
            return {'state':'idle','evaluation':evaluated}
        item=work[0];rid=item['resource_id'];adapter=self.execution_factory()
        # Requests share the existing Naver pacer, but cannot consume the read lane's 24/40 budget.
        if hasattr(adapter,'share_pacing'):adapter.share_pacing(self._naver_pacer)
        if item['mode']=='evidence':
            evidence=self.store.execution_evidence_work(rid,self.clock())
            if not evidence:self.store.execution_source_abandon(rid,self.clock());return {'state':'hold'}
            handle=NW.issue_evidence_handle(evidence['binding'],evidence['target_key'],evidence['period_start'],evidence['period_end'],now=self.clock(),expires_at=self.clock()+timedelta(seconds=20),validate=lambda:self.store.execution_evidence_work(rid,self.clock())==evidence,epochs=evidence['epochs'])
            try:result=adapter.get_evidence(handle);self.store.execution_record_evidence(rid,result['evidence'] if result['state']=='ready' else None,self.clock())
            except Exception:self.store.execution_record_evidence(rid,None,self.clock())
            return {'state':'evidence_checked'}
        if item['mode']=='spend':
            source=self.store.execution_channel_work(rid,self.clock())
            if not source:self.store.execution_source_abandon(rid,self.clock());return {'state':'hold'}
            scope={k:source[k] for k in ('possibility_id','customer_id','account_key','stage_revision')}
            handle=NW.issue_spend_handle(scope,source['period_start'],now=self.clock(),expires_at=self.clock()+timedelta(seconds=20),validate=lambda:self.store.execution_channel_work(rid,self.clock())==source)
            try:result=adapter.get_spend(handle);self.store.execution_record_spend(rid,result['spend'] if result['state']=='ready' else None,self.clock())
            except Exception:self.store.execution_record_spend(rid,None,self.clock())
            return {'state':'spend_checked'}
        if item['mode']=='channels':
            channel=self.store.execution_channel_work(rid,self.clock())
            if not channel:self.store.execution_source_abandon(rid,self.clock());return {'state':'hold'}
            scope={k:channel[k] for k in ('possibility_id','customer_id','account_key','stage_revision')}
            handle=NW.issue_channels_handle(scope,now=self.clock(),expires_at=self.clock()+timedelta(seconds=20),validate=lambda:self.store.execution_channel_work(rid,self.clock())==channel)
            try:
                result=adapter.get_channels(handle)
                records=None
                if result['state']=='ready':
                    records=[{'nccBusinessChannelId':r['id'],'customerId':r['customer_id'],'name':r.get('name',''),'channelTp':r['type'],'channelKey':r['channel_key'],'status':r['status']} for r in result['channels']]
                self.store.execution_record_channels(rid,records,self.clock())
            except Exception:self.store.execution_record_channels(rid,None,self.clock())
            return {'state':'channels_checked'}
        claim=self.store.execution_claim(rid,self.clock(),lease_seconds=30)
        if not claim:return {'state':'hold'}
        token=claim['lease_token'];command=claim['command'];phase='reconcile' if claim['mode']=='reconcile' else 'preflight'
        def sealed(which):
            return NW.issue_command_handle(command,now=self.clock(),expires_at=self.clock()+timedelta(seconds=20),validate=lambda:self.store.execution_lease_valid(rid,token,self.clock(),phase=which),phase=which)
        if claim['mode']=='dispatch':
            try:
                preflight=adapter.preflight(sealed('preflight'))
                if preflight['state']!='ready':
                    self.store.execution_release_claim(rid,token,self.clock(),'PREFLIGHT_FAILED');return {'state':'hold'}
                command=self.store.execution_mark_dispatched(rid,token,self.clock(),preflight=preflight['preflight'])
                if command is None:return {'state':'hold'}
            except Exception:
                self.store.execution_release_claim(rid,token,self.clock(),'PREFLIGHT_FAILED');return {'state':'hold'}
            try:result=adapter.execute(sealed('dispatch'))
            except Exception:result={'state':'unknown','result_id':None,'error_code':'UNEXPECTED'}
            self.store.execution_record_result(rid,token,result,self.clock())
            return {'state':result['state']}
        data=self.store.execution_reconcile_data(rid,token,self.clock())
        try:result=adapter.reconcile(sealed('reconcile'),created_id=(data.get('outcome') or {}).get('result_id'));readback=result['readback'] if result['state']=='ready' else None
        except Exception:readback=None
        state=self.store.execution_record_readback(rid,token,readback,self.clock())
        return {'state':state}
