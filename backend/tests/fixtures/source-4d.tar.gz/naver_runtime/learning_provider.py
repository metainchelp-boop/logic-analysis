"""Explicitly enabled, fixed-host Claude transport and conservative cost records.

Import and configuration do not make requests. No model or price is inferred.
The store records maximum_call_microusd before each call. Only an explicit
unlimited setting disables the optional monthly application cap.
"""
from decimal import Decimal, InvalidOperation, ROUND_CEILING, ROUND_FLOOR
import http.client
import math
import os

from naver_engine.marketing_strategy import StrategyRefused
from .claude_provider import AnthropicProvider, MAX_OUTPUT_TOKENS, MAX_REQUEST_BYTES
from . import provider_observability as OBS

HOST = "api.anthropic.com"
PATH = "/v1/messages"
URL = "https://" + HOST + PATH


def _transport_error(error):
    """Classify exception types at the existing network seam, without error text."""
    if isinstance(error, TimeoutError):
        return "PROVIDER_TIMEOUT"
    if isinstance(error, http.client.ssl.SSLError):
        return "PROVIDER_TLS_ERROR"
    if isinstance(error, OSError):
        return "PROVIDER_NETWORK_ERROR"
    if isinstance(error, http.client.HTTPException):
        return "PROVIDER_PROTOCOL_ERROR"
    return "PROVIDER_UNAVAILABLE"


def _decimal(value, maximum):
    if not isinstance(value, (str, int, float)) or isinstance(value, bool):
        raise StrategyRefused("PROVIDER_CONFIGURATION_INVALID")
    try:
        number = Decimal(str(value))
        if not number.is_finite() or not 0 < number <= maximum:
            raise ValueError()
        return number
    except (InvalidOperation, ValueError):
        raise StrategyRefused("PROVIDER_CONFIGURATION_INVALID") from None


class _Response:
    def __init__(self, response, connection):
        self._response, self._connection = response, connection
        self.status = response.status

    def read(self, maximum):
        try:
            return self._response.read(maximum)
        except Exception as error:
            raise StrategyRefused(_transport_error(error)) from None

    def close(self):
        try:
            self._response.close()
        finally:
            self._connection.close()


def _transport(request, *, timeout):
    return _transport_impl(request, timeout=timeout)


def _observation_transport(request, *, timeout, observation):
    """Only this explicitly installed transport observes real HTTP boundaries."""
    return _transport_impl(request, timeout=timeout, observation=observation)


def _transport_impl(request, *, timeout, observation=None):
    """No proxy discovery, URL construction from input, redirect or retry path."""
    if (request.full_url != URL or request.allow_redirects is not False or request.get_method() != "POST" or
            not isinstance(request.data, bytes) or not 0 < len(request.data) <= MAX_REQUEST_BYTES or
            not isinstance(request.headers, dict) or set(request.headers) != {"x-api-key", "anthropic-version", "Content-Type"} or
            type(timeout) not in (int, float) or not math.isfinite(timeout) or not 1 <= timeout <= 20):
        raise StrategyRefused("PROVIDER_CONFIGURATION_INVALID")
    connection = None
    try:
        connection = http.client.HTTPSConnection(HOST, timeout=timeout)
        OBS.emit(observation, "transport_attempt")
        connection.request("POST", PATH, body=request.data, headers=dict(request.headers))
        # Client-side completion only: neither server receipt nor billed usage.
        OBS.emit(observation, "client_request_written")
        response = connection.getresponse()
        OBS.emit(observation, "http_response", http_status=response.status)
        return _Response(response, connection)
    except Exception as error:
        if connection is not None:
            try:
                connection.close()
            except Exception:
                pass
        raise StrategyRefused(_transport_error(error)) from None


def provider_from_environment(environment=None):
    """Return None without reading credentials unless the enable flag is exact.

    Price settings are explicit USD per million tokens, versioned operationally
    with the selected model. Configuration never performs a paid validation call.
    """
    env = os.environ if environment is None else environment
    if env.get("NAVER_CLAUDE_ENABLED") != "true":
        return None
    cap_setting = env.get("NAVER_CLAUDE_MONTHLY_CAP_USD")
    unlimited = cap_setting == "unlimited"
    cap = None if unlimited else _decimal(cap_setting, 100000)
    input_price = _decimal(env.get("NAVER_CLAUDE_INPUT_USD_PER_MILLION"), 10000)
    output_price = _decimal(env.get("NAVER_CLAUDE_OUTPUT_USD_PER_MILLION"), 10000)
    timeout = float(_decimal(env.get("NAVER_CLAUDE_TIMEOUT_SECONDS", "10"), 20))
    if timeout < 1:
        raise StrategyRefused("PROVIDER_CONFIGURATION_INVALID")
    provider = AnthropicProvider.from_environment(env, timeout=timeout, transport=_transport,
        observation_transport=_observation_transport)
    def optional_price(name):
        raw = env.get(name)
        if raw is None:
            return None
        try:
            return str(_decimal(raw, 10000))
        except StrategyRefused:
            # An optional telemetry price cannot alter the existing call policy.
            return None
    provider.configured_prices = {"input_usd_per_million": str(input_price),
        "output_usd_per_million": str(output_price),
        "cache_read_usd_per_million": optional_price("NAVER_CLAUDE_CACHE_READ_USD_PER_MILLION"),
        "cache_creation_5m_usd_per_million": optional_price("NAVER_CLAUDE_CACHE_CREATION_5M_USD_PER_MILLION"),
        "cache_creation_1h_usd_per_million": optional_price("NAVER_CLAUDE_CACHE_CREATION_1H_USD_PER_MILLION")}
    # A byte per token is a conservative input bound for this bounded UTF-8 body.
    # Round the call upward and the monthly allowance downward to avoid overspend.
    provider.maximum_call_microusd = int((MAX_REQUEST_BYTES * input_price + MAX_OUTPUT_TOKENS * output_price).to_integral_value(rounding=ROUND_CEILING))
    provider.monthly_budget_unlimited = unlimited
    provider.monthly_budget_microusd = None if unlimited else int((cap * 1000000).to_integral_value(rounding=ROUND_FLOOR))
    if (not unlimited and provider.monthly_budget_microusd < 1) or provider.maximum_call_microusd < 1:
        raise StrategyRefused("PROVIDER_CONFIGURATION_INVALID")
    return provider
