/* 계정별 계획 검토. 저장·승인 API만 사용하며 광고 실행 요청은 만들지 않는다. */
(function () {
  'use strict';
  var GOALS = {impressions:'노출수',clicks:'클릭수',cpa:'광고 전환 CPA',roas:'광고 전환가치 ROAS'};
  var TABS = {design:'캠페인 설계',experiments:'A/B 실험',improve:'데이터 학습 자산',settings:'AI 자동화 설정',execution:'승인 범위 집행',history:'변경 기록'};
  var NUMBERS = ['target_value','daily_spend_cap','absolute_bid_cap','experiment_days','loss_cap'];
  var EXTRA_NUMBERS = ['monthly_spend_cap','measurement_lag_days','minimum_clicks','minimum_conversions'];
  var CONVERSIONS = {platform:'플랫폼 일반 전환',purchase:'구매 완료',lead:'문의·리드'};
  var VALUES = {platform_conversion_value:'플랫폼 전환가치',paid_order_revenue:'결제 매출',gross_profit:'매출총이익'};
  var LIMITS = {single_increase_percent:'1회 인상 한도(%)',single_decrease_percent:'1회 인하 한도(%)',rolling_day_increase_percent:'최근 24시간 누적 인상 한도(%)',rolling_day_decrease_percent:'최근 24시간 누적 인하 한도(%)',weekly_increase_requires_approval_percent:'7일 누적 인상 재승인 기준(%)'};
  var BUDGET_UNITS = {vat_included_krw:'부가세 포함 금액',vat_excluded_krw:'부가세 별도 금액'};
  var BUDGET_REASONS = {SOURCE_UNAVAILABLE:'현재 계정의 최신·완결·정합 원천을 확인하지 못했습니다.',NO_CAMPAIGNS:'현재 완결 원천에 캠페인이 없습니다.',DISPLAY_TRUNCATED:'목록이 앞 100개로 잘려 전체 적용 범위를 확인할 수 없습니다.',FINITE_BUDGET_UNCONFIRMED:'모든 캠페인의 일예산 사용 여부가 확인되지 않았습니다.',AMOUNT_UNCONFIRMED:'모든 캠페인의 유한한 양의 정수 일예산을 확인하지 못했습니다.',NONSHARED_UNCONFIRMED:'공유예산을 사용하지 않는다는 근거가 없거나 공유예산 설정이 있습니다.',PLAN_AMOUNT_LIMIT:'합계 또는 부가세 반영 금액이 계획 상한 범위를 초과합니다.'};
  function finite(value) { return typeof value === 'number' && isFinite(value); }
  function existingBudget(value) {
    function closed(item,keys) { return !!item && typeof item === 'object' && !Array.isArray(item) && Object.keys(item).sort().join('|') === keys.slice().sort().join('|'); }
    function text(item,limit) { return typeof item === 'string' && item.length <= limit; }
    function generation(item) { return text(item,100) || Number.isSafeInteger(item) && item >= 0 && item <= 1e15; }
    function nullableBool(item) { return item === null || typeof item === 'boolean'; }
    function count(item) { return item === null || Number.isInteger(item) && item >= 0 && item <= 10000; }
    function amount(item) { return item === null || finite(item) && item > 0 && item <= 1e12; }
    function row(item) {
      return closed(item,['label','parent_label','budget','budget_present','use_daily_budget','shared_budget','user_lock','deleted','status']) && text(item.label,200) &&
        (item.parent_label === null || text(item.parent_label,200)) && (item.budget === null || finite(item.budget) && item.budget >= 0 && item.budget <= 1e9) && typeof item.budget_present === 'boolean' &&
        nullableBool(item.use_daily_budget) && ['none','shared','unknown'].indexOf(item.shared_budget) >= 0 && nullableBool(item.user_lock) && nullableBool(item.deleted) && (item.status === null || text(item.status,160));
    }
    if (!closed(value,['version','status','checked_at','generation','campaigns','groups','campaign_total','group_total','rows_truncated','candidate_amounts','can_prefill','reason_codes','source_unit','execution_enabled']) ||
        value.version !== 1 || ['ready','unavailable'].indexOf(value.status) < 0 || value.execution_enabled !== false || value.source_unit !== 'unconfirmed' || typeof value.can_prefill !== 'boolean' || typeof value.rows_truncated !== 'boolean' ||
        !(value.checked_at === null || text(value.checked_at,100)) || !(value.generation === null || generation(value.generation)) ||
        ![value.campaigns,value.groups].every(function (items) { return Array.isArray(items) && items.length <= 100 && items.every(row); }) || !count(value.campaign_total) || !count(value.group_total) ||
        !Array.isArray(value.reason_codes) || value.reason_codes.length > 20 || !value.reason_codes.every(function (code) { return text(code,80) && /^[A-Z_]+$/.test(code); }) ||
        !closed(value.candidate_amounts,['vat_included_krw','vat_excluded_krw']) || !Object.keys(BUDGET_UNITS).every(function (unit) { return amount(value.candidate_amounts[unit]); })) return null;
    if (value.status === 'unavailable') return !value.can_prefill && !value.campaigns.length && !value.groups.length && value.campaign_total === null && value.group_total === null &&
      Object.keys(BUDGET_UNITS).every(function (unit) { return value.candidate_amounts[unit] === null; }) ? value : null;
    if (!text(value.checked_at,100) || !isFinite(Date.parse(value.checked_at)) || !generation(value.generation) || value.campaign_total === null || value.group_total === null ||
        value.campaign_total < value.campaigns.length || value.group_total < value.groups.length || !value.rows_truncated && (value.campaign_total !== value.campaigns.length || value.group_total !== value.groups.length)) return null;
    if (value.can_prefill && (value.rows_truncated || value.reason_codes.length || !value.campaigns.length || !value.campaigns.every(function (item) {
      return item.budget_present && Number.isInteger(item.budget) && item.budget >= 70 && item.use_daily_budget === true && item.shared_budget === 'none';
    }) || !Object.keys(BUDGET_UNITS).every(function (unit) { return value.candidate_amounts[unit] !== null; }))) return null;
    if (!value.can_prefill && Object.keys(BUDGET_UNITS).some(function (unit) { return value.candidate_amounts[unit] !== null; })) return null;
    return value;
  }
  function documentPlan(raw,upgrade) {
    raw = raw || {}; var result = {goal:Object.prototype.hasOwnProperty.call(GOALS,raw.goal) ? raw.goal : null,notes:typeof raw.notes === 'string' ? raw.notes : ''};
    NUMBERS.forEach(function (key) { result[key] = finite(raw[key]) ? raw[key] : null; });
    if (raw.schema_version === 2 || upgrade === true) {
      result.schema_version = 2;
      EXTRA_NUMBERS.forEach(function (key) { result[key] = finite(raw[key]) ? raw[key] : null; });
      ['conversion_definition','value_basis','period_start','period_end'].forEach(function (key) { result[key] = typeof raw[key] === 'string' ? raw[key] : null; });
      result.change_limits = {};
      Object.keys(LIMITS).forEach(function (key) { result.change_limits[key] = raw.change_limits && finite(raw.change_limits[key]) ? raw.change_limits[key] : null; });
    }
    return result;
  }
  function day(value) {
    if (typeof value !== 'string' || !/^[0-9]{4}-[0-9]{2}-[0-9]{2}$/.test(value) || value.slice(0,4) === '0000') return null;
    var at = Date.parse(value + 'T00:00:00Z');
    return isFinite(at) && new Date(at).toISOString().slice(0,10) === value ? at : null;
  }
  function criteriaValid(plan,approve) {
    if (plan.schema_version !== 2) return !approve;
    function number(value,low,high,integer) { return finite(value) && value >= low && value <= high && (!integer || Number.isInteger(value)); }
    if (plan.monthly_spend_cap !== null && !number(plan.monthly_spend_cap,1e-12,1e12)) return false;
    if (plan.conversion_definition !== null && !Object.prototype.hasOwnProperty.call(CONVERSIONS,plan.conversion_definition) ||
        plan.value_basis !== null && !Object.prototype.hasOwnProperty.call(VALUES,plan.value_basis)) return false;
    if (!['measurement_lag_days','minimum_clicks','minimum_conversions'].every(function (key) {
      return plan[key] === null || number(plan[key],key === 'measurement_lag_days' ? 0 : 1,key === 'measurement_lag_days' ? 30 : 1e9,true);
    })) return false;
    var start = day(plan.period_start), end = day(plan.period_end), days = (end - start) / 86400000 + 1;
    if (plan.period_start !== null && start === null || plan.period_end !== null && end === null || start !== null && end !== null && (days < 1 || days > 366)) return false;
    var limits = plan.change_limits;
    if (!limits || typeof limits !== 'object' || Array.isArray(limits) || Object.keys(limits).length !== Object.keys(LIMITS).length || !Object.keys(LIMITS).every(function (key) {
      return Object.prototype.hasOwnProperty.call(limits,key) && (limits[key] === null || number(limits[key],0,key.indexOf('decrease') >= 0 ? 100 : 1000));
    })) return false;
    if (!approve) return true;
    if (plan.monthly_spend_cap === null || start === null || end === null || plan.measurement_lag_days === null || plan.minimum_clicks === null ||
        Object.keys(LIMITS).some(function (key) { return limits[key] === null; }) ||
        (plan.goal === 'cpa' || plan.goal === 'roas') && (plan.conversion_definition === null || plan.minimum_conversions === null) || plan.goal === 'roas' && plan.value_basis === null) return false;
    if (plan.absolute_bid_cap > plan.daily_spend_cap || plan.experiment_days > days) return false;
    var months = {};
    for (var at = start; at <= end; at += 86400000) { var month = new Date(at).toISOString().slice(0,7); months[month] = (months[month] || 0) + 1; }
    var capacity = Object.keys(months).reduce(function (total,month) { return total + Math.min(plan.monthly_spend_cap,plan.daily_spend_cap * months[month]); },0);
    return plan.loss_cap <= capacity;
  }
  function complete(plan) {
    return Object.prototype.hasOwnProperty.call(GOALS,plan.goal) && NUMBERS.every(function (key) { return finite(plan[key]) && plan[key] > 0 && plan[key] <= 1e12; }) &&
      Number.isInteger(plan.experiment_days) && plan.experiment_days >= 2 && plan.experiment_days <= 30 && plan.loss_cap <= plan.daily_spend_cap * plan.experiment_days &&
      (plan.schema_version !== 2 || criteriaValid(plan,true));
  }
  function renderSetup(env,data) {
    var h = env.h;
    if (!data || data.version !== 1 || !Array.isArray(data.items)) return h('section',{class:'na-section'},h('h3',null,'설정 완결 점검'),h('p',{class:'na-note'},'이 계정의 저장된 설정 점검 자료를 확인하지 못했습니다. 미확인은 설정 오류나 정상 판정이 아닙니다.'));
    var states = {attention:'확인 필요',unknown:'자료 미확인',verified:'관측 범위 확인',not_applicable:'유형상 미지원'}, source = data.source || {}, counts = data.counts || {}, detail = data.details || {}, observed = source.observation;
    var kinds = {campaign:'캠페인',adgroup:'광고그룹',keyword:'키워드',ad:'소재',SD:'요일·시간',RL:'지역',AG:'연령',negative_keywords:'제외 검색어'};
    function bounded(value,limit) { return Array.isArray(value) ? value.slice(0,limit || 100) : []; }
    function path(row) { return bounded(row.path,3).map(function (part) { return (kinds[part.entity] || part.entity) + ' ' + (part.name || part.id); }).join(' › ') || (row.id || '대상 미확인'); }
    var settingNames = {name:'이름',keyword:'검색어',campaignTp:'캠페인 유형',adgroupType:'그룹 유형',type:'유형',useDailyBudget:'일예산 사용',dailyBudget:'일예산',sharedDailyBudget:'공유 일예산',
      usePeriod:'노출 기간 사용',periodStartDt:'시작',periodEndDt:'종료',bidAmt:'입찰가',useGroupBidAmt:'그룹 입찰가 사용',userLock:'사용자 중지',status:'상태',statusReason:'상태 사유',
      title:'제목',description:'설명',headline:'제목',text:'문구',useAdvoost:'ADVoost 플랫폼 관리',state:'관측 상태',records:'조건',record_total:'조건 수',value:'값',dictionaryCode:'분류',codeName:'대상',bidWeight:'입찰 가중치',negative:'제외',enable:'사용',delFlag:'삭제'};
    function settings(value,depth) {
      depth = depth || 0;
      if (value == null) return '기록 없음';
      if (typeof value === 'boolean') return value ? '예' : '아니오';
      if (typeof value === 'string' || finite(value)) return String(value).slice(0,1000);
      if (depth > 2) return '상세 조건';
      if (Array.isArray(value)) return bounded(value,20).map(function (item) { return settings(item,depth+1); }).join(' / ').slice(0,3000) || '명시 조건 없음';
      return Object.keys(value).slice(0,24).filter(function (name) { return settingNames[name]; }).map(function (name) { return settingNames[name] + ': ' + settings(value[name],depth+1); }).join(' · ').slice(0,3000) || '표시할 설정 없음';
    }
    function metric(value) { return finite(value) ? env.num(value) : '미확인'; }
    function generation(value) { return typeof value === 'string' && value.length <= 100 ? value : metric(value); }
    var entityRows = observed && observed.usable === true ? bounded(detail.entities) : [], targetRows = observed && observed.usable === true ? bounded(detail.targets) : [], historyRows = bounded(detail.history);
    var statusNames = {ok:'관측 완료',pending:'대기',reading:'수집 중',partial:'부분 수집',retry:'재시도 필요',failed:'수집 실패',limited:'조회 제한',reauth_required:'권한 확인 필요',unknown:'자료 미확인'};
    var current = observed ? h('p',{class:'na-note'},'공유 점검 원천: ' + (statusNames[observed.status] || '자료 미확인') +
      ' · ' + (observed.freshness === 'current' ? '현재 회차' : observed.freshness === 'stale' ? '이전 회차' : '회차 미확인') +
      ' · 수집 회차 ' + generation(observed.generation) + ' · 집계 기간 ' + (observed.period_start || '미확인') + ' ~ ' + (observed.period_end || '미확인') +
      ' · 확인 ' + env.datedTime(observed.checked_at) + (observed.error_code ? ' · ' + observed.error_code : '') +
      (observed.usable === true ? '' : ' · 현재 설정·성과 판정에 사용할 완결 자료가 없습니다. 이전 성공 자료를 현재 값으로 대신 표시하지 않습니다.')) : null;
    var entities = entityRows.length ? h('details',{class:'na-section'},h('summary',null,'대상별 설정·성과 관측 ' + env.num(detail.entity_total) + '개' + (detail.entities_truncated ? ' · 앞 100개 표시' : '')),
      h('p',{class:'hint'},'전환은 플랫폼 일반 전환입니다. 미확인과 실제 0을 구분하며, 행별 집계 기간·원천 시각을 확인하세요.'),
      h('table',{class:'na-checklist'},h('thead',null,h('tr',null,['대상 경로·설정','확인 시각·사유·다음 행동','노출 / 클릭 / 광고비 / 전환 / 전환가치'].map(function (label) { return h('th',null,label); }))),
        h('tbody',null,entityRows.map(function (row) {
          var p = row.performance, fields = p && p.fields || {};
          return h('tr',null,h('th',{scope:'row'},path(row),h('p',{class:'hint'},settings(row.settings))),
            h('td',null,env.datedTime(row.checked_at),h('p',null,(row.reason || {}).meaning || '사유 미확인'),h('p',{class:'hint'},row.next_action)),
            h('td',null,p ? ['impCnt','clkCnt','salesAmt','ccnt','convAmt'].map(function (key) { return metric(fields[key]); }).join(' / ') : '자료 미확인',
              p ? h('p',{class:'hint'},p.period_start + ' ~ ' + p.period_end + ' · ' + (p.complete === true ? '수집 범위 완결' : p.missing === true ? '응답 자료 없음' : '부분·미확인') + ' · 원천 ' + env.datedTime(p.source_at) + ' · ' + (p.reason || '')) : null));
        })))) : null;
    var targets = targetRows.length ? h('details',{class:'na-section'},h('summary',null,'노출 대상·제외 설정 관측 ' + env.num(detail.target_total) + '건' + (detail.targets_truncated ? ' · 앞 100건 표시' : '')),
      h('table',{class:'na-checklist'},h('tbody',null,targetRows.map(function (row) { return h('tr',null,h('th',{scope:'row'},path(row),h('p',{class:'hint'},kinds[row.kind] || row.kind)),
        h('td',null,row.state === 'unsupported' ? '유형상 미지원' : row.record_total === 0 ? '기본 설정 관측' : '명시 설정 관측 ' + env.num(row.record_total) + '건',
          h('p',null,row.reason),h('p',{class:'hint'},env.datedTime(row.checked_at) + ' · ' + row.next_action),
          bounded(row.records,20).length ? h('p',{class:'hint'},settings(bounded(row.records,20)) + (row.records_truncated ? ' · 앞 20건' : '')) : null)); })))) : null;
    var history = observed ? h('details',{class:'na-section'},h('summary',null,'관측된 설정 변경 이력 ' + env.num(detail.history_total || 0) + '건' + (detail.history_truncated ? ' · 최근 100건 표시' : '')),
      h('p',{class:'hint'},'현재 업체·계정·계약 단계에서 확인한 과거 관측입니다. 계획·승인·실제 광고 변경 완료 기록과 다릅니다. 현재 원천이 실패하거나 오래되면 이력을 현재 설정으로 사용하지 않습니다.'),
      historyRows.length ? h('table',{class:'na-checklist'},h('tbody',null,historyRows.map(function (row) { return h('tr',null,h('th',{scope:'row'},path(row),h('p',{class:'hint'},row.entity)),
        h('td',null,env.datedTime(row.observed_at) + ' · 수집 회차 ' + generation(row.generation) + ' · ' + ({initial:'최초 관측',changed:'변경 관측',removed:'제거 관측'}[row.change_kind] || '관측'),
          h('p',{class:'hint'},'이전: ' + settings(row.before)),h('p',{class:'hint'},'이후: ' + settings(row.after)))); }))) : h('p',{class:'hint'},'현재 범위의 관측 이력이 없습니다.')) : null;
    return h('section',{class:'na-section'},h('h3',null,'설정 완결 점검'),h('div',{class:'na-actions'},Object.keys(states).map(function (name) {
      return h('span',{class:'pill ' + (name === 'attention' ? 'p-amber' : name === 'verified' ? 'p-green' : 'p-gray')},states[name] + ' ' + env.num(counts[name]));
    })),current,h('p',{class:'hint'},'저장된 원천 설정과 계획에서 확인한 범위입니다. 자료 미확인을 설정 누락으로 보지 않으며, 일부 상태 확인이 전체 세팅 완료를 뜻하지 않습니다.'),
      h('table',{class:'na-checklist'},h('thead',null,h('tr',null,h('th',null,'점검 항목'),h('th',null,'상태'),h('th',null,'관측과 다음 작업'))),h('tbody',null,bounded(data.items,32).map(function (item) {
        return h('tr',null,h('th',{scope:'row'},item.label),h('td',null,states[item.state] || '자료 미확인'),
          h('td',null,h('p',null,item.summary),h('p',{class:'hint'},item.next_action)));
      }))),h('p',{class:'na-plan-meta'},'구조 원천 수집 ' + env.datedTime((source.structure || {}).checked_at) + ' · 캠페인 원천 수집 ' + env.datedTime((source.campaigns || {}).checked_at)),
      entities,targets,history,Array.isArray(source.limitations) ? h('ul',{class:'hint'},bounded(source.limitations,10).map(function (line) { return h('li',null,line); })) : null);
  }
  function create(env) {
    var h = env.h, put = env.put, $ = env.$, epoch = 0, shown = null, displayedMark = null, displayedContext = null;
    var selected = null, rows = [], listing = null, drafts = {}, writeLocks = {}, session = 0, busy = false, controller = null, tab = env.learningEntry === true ? 'improve' : 'settings', q = '', page = 0, timer = null, initialized = false;
    var learningUI = window.NaverLearningAssets ? window.NaverLearningAssets.create(env) : null;
    var experimentsUI = window.NaverExperiments ? window.NaverExperiments.create(env) : null;
    var executionUI = window.NaverExecution ? window.NaverExecution.create(env) : null;
    var randomizedUI = window.NaverRandomizedExperiments ? window.NaverRandomizedExperiments.create(env) : null;
    function randomizedLocked(account) { return !!randomizedUI && randomizedUI.locked(account); }
    function key(account) { return account.possibility_id + '|' + account.account_key; }
    function fresh(mark,ctx) { return mark === epoch && ctx === env.context() && env.active(); }
    function identity(data,account) {
      var s = data && data.selection, m = data && data.plan && data.plan.metadata;
      return !!s && !!m && s.possibility_id === account.possibility_id && s.account_key === account.account_key &&
        m.possibility_id === account.possibility_id && m.account_key === account.account_key && Number.isSafeInteger(data.plan.version) && data.plan.version >= 0;
    }
    function hasUnsaved() { return Object.keys(drafts).some(function (name) { return drafts[name].dirty; }) || !!learningUI && learningUI.hasUnsaved() || !!experimentsUI && experimentsUI.hasUnsaved() || !!executionUI && executionUI.hasUnsaved() || !!randomizedUI && randomizedUI.hasUnsaved(); }
    function learningCapability(body) { return !!learningUI && !!selected && !writeLocks[key(selected)] && !randomizedLocked(selected) && !(experimentsUI && experimentsUI.locked(selected)) && learningUI.capability(body); }
    function learningSourceCapability(body) { return !!learningUI && !!selected && !busy && !writeLocks[key(selected)] && !randomizedLocked(selected) && !(experimentsUI && experimentsUI.locked(selected)) && typeof learningUI.sourceCapability === 'function' && learningUI.sourceCapability(body); }
    function experimentCapability(body) { return !!experimentsUI && !!selected && !busy && !writeLocks[key(selected)] && !randomizedLocked(selected) && experimentsUI.capability(body); }
    function executionCapability(body) { return !!executionUI && !!selected && (!randomizedLocked(selected) || !!body && ['stop','cancel','reconcile_request'].indexOf(body.action) >= 0) && executionUI.capability(body); }
    function randomizedCapability(body) { return !!randomizedUI && !!selected && (!!body && body.action === 'stop' || !busy && !writeLocks[key(selected)] && !(experimentsUI && experimentsUI.locked(selected)) && !(executionUI && executionUI.locked && executionUI.locked(selected))) && randomizedUI.capability(body); }
    if (window.addEventListener) window.addEventListener('beforeunload',function (event) { if (hasUnsaved()) { event.preventDefault(); event.returnValue = ''; } });
    function planCapability(body) {
      if (!body || !shown || !selected || busy || writeLocks[key(selected)] || randomizedLocked(selected) || experimentsUI && experimentsUI.locked(selected) || !fresh(displayedMark,displayedContext) || !identity(shown,selected)) return false;
      var head = shown.plan, draft = drafts[key(selected)];
      if (body.possibility_id !== selected.possibility_id || body.account_key !== selected.account_key ||
          !Number.isSafeInteger(body.expected_version) || body.expected_version !== head.version || draft && draft.baseVersion !== head.version) return false;
      if (body.action === 'save') return shown.can_edit === true && !!body.plan && typeof body.plan === 'object' && !Array.isArray(body.plan);
      return body.action === 'approve' && body.plan === undefined && shown.can_approve === true && head.state === 'draft' &&
        !(draft && draft.dirty) && complete(documentPlan(head.plan));
    }
    function listPath() { return '/automation?selection=' + encodeURIComponent(env.selection()) + '&q=' + encodeURIComponent(q) + '&page=' + page; }
    function detailPath(account) { return '/automation?possibility_id=' + account.possibility_id + '&account_key=' + encodeURIComponent(account.account_key) + '&selection=' + encodeURIComponent(env.selection()); }
    function verifiedDetail(data,account) {
      if (!identity(data,account) || data.execution_enabled !== false || data.plan.execution_status !== 'not_enabled') throw new Error('automation-data');
      var id = key(account), lock = writeLocks[id];
      if (lock && lock.state === 'saved') {
        if (data.plan.version <= lock.expected_version) throw new Error('automation-old-plan');
        delete writeLocks[id]; delete drafts[id];
      }
    }
    function init() {
      if (initialized) return; initialized = true;
      if ($('automationReload')) $('automationReload').addEventListener('click',function () { if (!busy && env.active()) load(); });
    }
    function fail(error,mark,ctx) {
      if (!fresh(mark,ctx)) return;
      if (env.denied(error)) { env.purge(error); return; }
      busy = false; shown = null;
      var locked = selected && writeLocks[key(selected)];
      put($('automationRoot'),h('div',{class:'card empty'},locked && locked.state === 'saved' ? '계획 저장·승인은 서버에서 확인되었습니다. 최신 계획 재조회가 필요하며 확인 전까지 쓰기·승인을 보류합니다. ' : '계정별 계획을 확인하지 못했습니다. 다시 확인해 주세요. ',
        h('button',{type:'button',class:'btn',onclick:load},'다시 확인')));
    }
    function load() {
      if (!env.active() || busy && fresh(displayedMark,displayedContext)) return Promise.resolve(); busy = false; init();
      if (controller) controller.abort(); controller = new AbortController();
      var mark = ++epoch, ctx = env.context(); shown = null;
      put($('automationRoot'),h('div',{class:'card empty'},'현재 담당 범위의 광고 계정을 확인 중입니다…'));
      return env.api('GET',listPath(),undefined,controller.signal).then(function (data) {
        if (!fresh(mark,ctx)) return;
        if (!data || !Array.isArray(data.accounts) || data.execution_enabled !== false) throw new Error('automation-data');
        listing = data; rows = data.accounts.slice(0,100); displayedMark = mark; displayedContext = ctx;
        var account = selected && rows.find(function (item) { return key(item) === key(selected); }); selected = null;
        if (account) return open(account); render();
      }).catch(function (error) { fail(error,mark,ctx); });
    }
    function open(account) {
      if (!env.active() || busy || !Number.isSafeInteger(account.possibility_id) || account.possibility_id <= 0 || typeof account.account_key !== 'string' || !account.account_key ||
          !rows.some(function (item) { return key(item) === key(account); })) return Promise.resolve();
      if (controller) controller.abort(); controller = new AbortController();
      var mark = ++epoch, ctx = env.context(); selected = account; shown = null; displayedMark = mark; displayedContext = ctx; render();
      return env.api('GET',detailPath(account),undefined,controller.signal).then(function (data) {
        if (!fresh(mark,ctx)) return;
        verifiedDetail(data,account);
        shown = data; render();
      }).catch(function (error) { fail(error,mark,ctx); });
    }
    function renderPicker() {
      var search = h('input',{id:'automationSearch',type:'search',maxlength:120,'aria-label':'자동화 계획 광고주·계정 검색',placeholder:'광고주·계정 검색',disabled:busy,oninput:function () {
        q = this.value.trim(); page = 0; clearTimeout(timer); timer = setTimeout(load,250);
      }}); search.value = q;
      var select = h('select',{id:'automationAccount','aria-label':'계획 작성 광고 계정',disabled:busy,onchange:function () {
        var account = rows.find(function (item) { return key(item) === this.value; },this); if (account) open(account);
      }},h('option',{value:''},'광고 계정을 선택해 주세요'),rows.map(function (item) {
        return h('option',{value:key(item)},item.company_name + ' · ' + (item.account_name || '계정') + ' · ' + (item.ad_account_no || '번호 미확인'));
      })); select.value = selected ? key(selected) : '';
      return h('div',{class:'card na-section'},h('div',{class:'na-field-grid'},h('label',{class:'na-field'},h('span',null,'담당 범위에서 찾기'),search),h('label',{class:'na-field'},h('span',null,'개별 광고 계정'),select)),
        h('div',{class:'na-actions'},h('span',{class:'hint'},'계정별 계획·승인을 따로 관리합니다. 목록은 페이지당 최대 100개입니다.'),
          page > 0 ? h('button',{type:'button',class:'btn sm',disabled:busy,onclick:function () { page--; selected = null; load(); }},'이전 계정 목록') : null,
          listing && Number.isSafeInteger(listing.next_page) ? h('button',{type:'button',class:'btn sm',disabled:busy,onclick:function () { page = listing.next_page; selected = null; load(); }},'다음 계정 목록') : null));
    }
    function status(head) { return head.state === 'approved' ? '계획 승인 · 실행 미연결' : head.state === 'draft' ? '계획 검토 전' : '계획 작성 전'; }
    function render() {
      if (!env.active()) return;
      var content = !selected ? h('div',{class:'card empty'},rows.length ? '광고 계정을 선택하면 현재 계획과 설정 점검을 확인할 수 있습니다.' : '현재 범위와 검색 조건에 맞는 광고 계정이 없습니다.') : !shown ? h('div',{class:'card empty'},'선택한 계정의 최신 계획·권한을 확인 중입니다…') : renderDetail();
      put($('automationRoot'),renderPicker(),content); if ($('automationReload')) $('automationReload').disabled = busy;
    }
    function renderDetail() {
      var data = shown, account = selected, head = data.plan, id = key(account), saved = documentPlan(head.plan), draft = drafts[id];
      if (!draft) draft = drafts[id] = {plan:documentPlan(head.plan),baseVersion:head.version,dirty:false,invalid:{}};
      if (!draft.dirty) { draft.plan = documentPlan(head.plan); draft.baseVersion = head.version; }
      if (draft.budgetSource !== data.existing_budget) { draft.budgetSource = data.existing_budget; draft.budgetUnit = ''; draft.budgetMessage = ''; }
      var stale = draft.baseVersion !== head.version, mark = displayedMark, ctx = displayedContext, locked = writeLocks[id], experimentLocked = !!(experimentsUI && experimentsUI.locked(account)) || randomizedLocked(account);
      function current() { return fresh(mark,ctx) && shown === data && selected === account; }
      function editable() { return current() && !busy && !writeLocks[id] && !randomizedLocked(account) && !(experimentsUI && experimentsUI.locked(account)) && data.can_edit === true && !stale; }
      function upgrade() { if (draft.plan.schema_version !== 2) draft.plan = documentPlan(draft.plan,true); }
      function lockMessage() { return locked && locked.state === 'saved' ? '계획 저장·승인은 서버에서 확인되었습니다. 최신 계획 재조회가 필요하며 확인 전까지 쓰기·승인을 보류합니다.' : '저장·승인 요청의 결과를 확인 중입니다. 최신 계획 확인 전까지 추가 쓰기를 보류합니다.'; }
      function update() {
        if (!current()) return;
        draft.dirty = Object.keys(draft.invalid).some(function (name) { return draft.invalid[name]; }) || JSON.stringify(draft.plan) !== JSON.stringify(saved);
        var invalid = Object.keys(draft.invalid).some(function (name) { return draft.invalid[name]; }) || draft.plan.schema_version === 2 && !criteriaValid(draft.plan,false);
        if (!$('automationPlanSave')) return;
        $('automationPlanSave').disabled = busy || !!writeLocks[id] || !!experimentLocked || data.can_edit !== true || stale || !draft.dirty || invalid;
        $('automationPlanApprove').disabled = busy || !!writeLocks[id] || !!experimentLocked || data.can_approve !== true || stale || draft.dirty || head.state !== 'draft' || !complete(saved);
        $('automationPlanStatus').textContent = writeLocks[id] ? lockMessage() : stale ? '다른 계획판이 저장되었습니다. 입력을 버린 뒤 최신 계획을 확인해 주세요.' : invalid ? '수치의 범위·정수·날짜 순서와 366일 이내 운영 기간을 확인해 주세요.' : draft.dirty ? '저장하지 않은 계획 초안입니다. 승인·실행되지 않았습니다.' : status(head);
        if ($('automationTargetUnit')) $('automationTargetUnit').textContent = targetLabel(draft.plan.goal);
        updateBudgetControls();
      }
      function targetLabel(goal) { return goal === 'cpa' ? '목표 CPA(원/정의한 전환)' : goal === 'roas' ? '목표 ROAS(가치/광고비, %)' : goal === 'impressions' ? '실험 기간 목표 노출수(회)' : goal === 'clicks' ? '실험 기간 목표 클릭수(회)' : '목표 값 · 운영 목표 선택 후 단위 확인'; }
      function input(name,label,kind,options) {
        var nested = Object.prototype.hasOwnProperty.call(LIMITS,name), value = nested ? (draft.plan.change_limits || {})[name] : draft.plan[name], element;
        var disabled = busy || !!writeLocks[id] || !!experimentLocked || data.can_edit !== true || stale;
        if (options) element = h('select',{id:'automationPlan-' + name,disabled:disabled,onchange:function () {
          if (!editable()) return; upgrade(); draft.plan[name] = this.value || null; update();
        }},h('option',{value:''},'선택 · 미정'),Object.keys(options).map(function (option) { return h('option',{value:option},options[option]); }));
        else {
          var integer = name === 'experiment_days' || name === 'measurement_lag_days' || name === 'minimum_clicks' || name === 'minimum_conversions';
          var minimum = nested || name === 'measurement_lag_days' ? 0 : name === 'experiment_days' ? 2 : 1e-12;
          var maximum = nested ? name.indexOf('decrease') >= 0 ? 100 : 1000 : name === 'experiment_days' || name === 'measurement_lag_days' ? 30 : name === 'minimum_clicks' || name === 'minimum_conversions' ? 1e9 : 1e12;
          element = h(kind === 'textarea' ? 'textarea' : 'input',{id:'automationPlan-' + name,type:kind === 'textarea' ? null : kind === 'date' ? 'date' : 'number',
            min:kind ? null : integer && minimum === 1e-12 ? 1 : minimum,max:kind ? null : maximum,step:integer ? 1 : 'any',maxlength:kind === 'textarea' ? 1000 : null,rows:kind === 'textarea' ? 5 : null,
            disabled:disabled,oninput:function () {
              if (!editable()) return; upgrade();
              var next = kind === 'textarea' ? this.value : this.value === '' ? null : kind === 'date' ? this.value : Number(this.value);
              draft.invalid[name] = kind === 'textarea' ? false : !!(this.validity && this.validity.badInput) || next !== null && (kind === 'date' ? day(next) === null : !finite(next) || next < minimum || next > maximum || integer && !Number.isInteger(next));
              if (nested) draft.plan.change_limits[name] = next; else draft.plan[name] = next;
              update();
            }});
        }
        element.value = value == null ? '' : value;
        return h('label',{class:'na-field'},h('span',name === 'target_value' ? {id:'automationTargetUnit'} : null,label),element);
      }
      function budgetEditable() { return editable() && identity(data,account) && draft.baseVersion === head.version && draft.budgetSource === data.existing_budget; }
      function budgetReady() { var source = existingBudget(data.existing_budget); return source && source.can_prefill === true && source.status === 'ready' ? source : null; }
      function updateBudgetControls() {
        var source = budgetReady(), enabled = budgetEditable() && !!source;
        if ($('automationExistingBudgetUnit')) $('automationExistingBudgetUnit').disabled = !enabled;
        if ($('automationExistingBudgetUse')) $('automationExistingBudgetUse').disabled = !enabled || !Object.prototype.hasOwnProperty.call(BUDGET_UNITS,draft.budgetUnit);
      }
      function useExistingBudget() {
        var source = budgetReady(), unit = draft.budgetUnit;
        if (!budgetEditable() || !source || !Object.prototype.hasOwnProperty.call(BUDGET_UNITS,unit)) return;
        var memo = '[기존 캠페인 예산 초안] 원천 ' + source.checked_at + ' · 원천 금액 기준: ' + BUDGET_UNITS[unit] + ' · 중지·삭제·기간 외 캠페인 포함 · 계정 총예산 미확인 · 계획 승인·실행 단위 확인 아님.',
            notes = draft.plan.notes || '', appended = notes.slice(-memo.length) === memo ? notes : notes + (notes ? '\n\n' : '') + memo;
        if (appended.length > 1000) {
          draft.budgetMessage = '원천 검토 메모를 붙이면 1000자를 초과합니다. 기존 메모와 일 상한을 보존했습니다. 메모를 직접 검토한 뒤 다시 사용해 주세요.';
          if ($('automationExistingBudgetStatus')) $('automationExistingBudgetStatus').textContent = draft.budgetMessage;
          return;
        }
        upgrade(); draft.plan.daily_spend_cap = source.candidate_amounts[unit]; draft.plan.notes = appended; draft.invalid.daily_spend_cap = false;
        if ($('automationPlan-daily_spend_cap')) $('automationPlan-daily_spend_cap').value = draft.plan.daily_spend_cap;
        if ($('automationPlan-notes')) $('automationPlan-notes').value = draft.plan.notes;
        draft.budgetMessage = '기존 캠페인 한도 합계를 저장하지 않은 계획 초안에 반영했습니다. 월·입찰·기간 기준과 실행 단위는 채우지 않았습니다.';
        if ($('automationExistingBudgetStatus')) $('automationExistingBudgetStatus').textContent = draft.budgetMessage;
        update();
      }
      function renderExistingBudget() {
        var source = existingBudget(data.existing_budget), usable = source && source.status === 'ready', ready = budgetReady();
        function bool(value) { return value === true ? '예' : value === false ? '아니오' : '미확인'; }
        function rows(items,total,label) {
          return h('details',{class:'na-section'},h('summary',null,label + ' ' + env.num(total) + '개' + (items.length < total ? ' · 앞 100개 표시' : '')),
            items.length ? h('table',{class:'na-checklist'},h('thead',null,h('tr',null,h('th',null,'대상'),h('th',null,'기존 일예산·상태'))),
              h('tbody',null,items.map(function (row) { return h('tr',null,h('th',{scope:'row'},row.label,row.parent_label === null ? null : h('p',{class:'hint'},'상위 캠페인: ' + row.parent_label)),
                h('td',null,row.budget === null ? row.budget_present ? '일예산 값 미확인' : '일예산 필드 미확인' : env.won(row.budget),
                  h('p',{class:'hint'},'일예산 사용 ' + bool(row.use_daily_budget) + ' · 공유예산 ' + ({none:'사용 안 함 확인',shared:'설정 있음',unknown:'미확인'}[row.shared_budget])),
                  h('p',{class:'hint'},'사용자 중지 ' + bool(row.user_lock) + ' · 삭제 ' + bool(row.deleted) + ' · 상태 ' + (row.status || '미확인')))); }))) : h('p',{class:'hint'},'현재 원천에서 ' + label + ' 0개를 관측했습니다. 예산 0이나 광고 안 함 판정은 아닙니다.'));
        }
        var select = h('select',{id:'automationExistingBudgetUnit',disabled:!budgetEditable() || !ready,onchange:function () {
          if (!budgetEditable() || !budgetReady()) return;
          draft.budgetUnit = Object.prototype.hasOwnProperty.call(BUDGET_UNITS,this.value) ? this.value : ''; updateBudgetControls();
        }},h('option',{value:''},'원천 금액 기준 선택 · 미확인'),Object.keys(BUDGET_UNITS).map(function (unit) { return h('option',{value:unit},BUDGET_UNITS[unit]); }));
        select.value = draft.budgetUnit || '';
        var reasons = source ? source.reason_codes : ['SOURCE_UNAVAILABLE'];
        return h('section',{class:'na-section',id:'automationExistingBudget'},h('h3',null,'기존 캠페인 예산 확인'),
          h('p',{class:'na-note'},usable ? '현재 완결 원천 · 확인 ' + env.datedTime(source.checked_at) + ' · 수집 회차 ' + source.generation : '현재 사용할 수 있는 완결 예산 원천이 없습니다. 이전 자료나 0으로 대신 채우지 않습니다.'),
          reasons.length ? h('ul',{class:'hint'},reasons.map(function (code) { return h('li',null,BUDGET_REASONS[code] || '예산 원천 기준 미확인 · ' + code); })) : null,
          usable ? [rows(source.campaigns,source.campaign_total,'캠페인'),rows(source.groups,source.group_total,'광고그룹')] : null,
          h('p',{class:'hint'},'캠페인 한도만 합산하며 그룹 예산은 더하지 않습니다. 중지·삭제·기간 외 캠페인도 임의로 빼지 않습니다. 업체 전체 계약 예산·현재 집행액·남은 잔액은 미확인입니다.'),
          ready ? h('p',{class:'na-plan-meta'},'원천 금액이 부가세 포함이면 초안 ' + env.won(ready.candidate_amounts.vat_included_krw) + ' · 부가세 별도이면 초안 ' + env.won(ready.candidate_amounts.vat_excluded_krw) + ' (부가세 10% 반영)') : null,
          h('label',{class:'na-field'},h('span',null,'담당자가 검토한 원천 금액의 VAT 기준'),select),
          h('p',{class:'hint'},'VAT 기준은 자동 확인되지 않았습니다. 이 선택은 초안 계산 가정이며 실행용 단위 승인이나 계정 총예산 확인이 아닙니다.'),
          h('div',{class:'na-actions'},h('button',{type:'button',class:'btn',id:'automationExistingBudgetUse',disabled:!budgetEditable() || !ready || !Object.prototype.hasOwnProperty.call(BUDGET_UNITS,draft.budgetUnit),onclick:useExistingBudget},'기존 캠페인 한도 합계로 초안 채우기')),
          h('p',{class:'hint',id:'automationExistingBudgetStatus','aria-live':'polite'},draft.budgetMessage || '명시 버튼을 누를 때만 일 상한과 원천 검토 메모를 채웁니다. 저장·승인·광고 변경은 수행하지 않습니다.'));
      }
      function mutate(action) {
        if (!current() || busy || writeLocks[id] || stale || action === 'save' && $('automationPlanSave').disabled || action === 'approve' && $('automationPlanApprove').disabled) return;
        var body = {possibility_id:account.possibility_id,account_key:account.account_key,expected_version:head.version,action:action};
        if (action === 'save') body.plan = documentPlan(draft.plan,true);
        if (!planCapability(body)) return;
        var requestSession = session, lock = {state:'pending',expected_version:head.version};
        // api() checks the same capability synchronously before dispatch; lock subsequent writes only after that check.
        var pending = env.api('POST','/automation/plans',body); writeLocks[id] = lock; busy = true; render();
        pending.then(function () {
          if (requestSession !== session || writeLocks[id] !== lock) return;
          lock.state = 'saved';
          if (!current()) return;
          return env.api('GET',detailPath(account)).then(function (verified) {
            if (!current()) return;
            verifiedDetail(verified,account);
            busy = false; delete drafts[id]; shown = verified; render();
            env.toast(action === 'approve' ? '계획을 승인했습니다. 실제 광고 실행은 연결되지 않았습니다.' : '계획 초안을 저장했습니다. 광고는 변경하지 않았습니다.');
          });
        }).catch(function (error) {
          if (requestSession !== session) return;
          if (lock.state === 'pending' && writeLocks[id] === lock) delete writeLocks[id];
          if (!fresh(mark,ctx)) return;
          if (env.denied(error)) { env.purge(error); return; }
          if (!current()) return;
          busy = false; render();
          var message = lock.state === 'saved' ? '계획 저장·승인은 서버에서 확인되었습니다. 최신 계획 재조회가 필요하며 확인 전까지 쓰기·승인을 보류합니다.' : error.status === 409 ? '계획판이 바뀌었습니다. 입력 초안은 보존됩니다. 새로 확인해 주세요.' : '계획을 저장·승인하지 못했습니다. 입력 내용과 연결 상태를 확인해 주세요.';
          var statusNode = $('automationPlanStatus'); if (statusNode) statusNode.textContent = message; else env.toast(message,'warn');
        }).then(function () { if (!env.active()) busy = false; });
      }
      var editor = h('article',{class:'card'},h('h2',null,'개별 계정의 목표·운영 기준'),h('p',{class:'na-plan-meta'},'계획 ' + env.num(head.version) + '판 · ' + status(head)),
        head.approval_requires_lead === true ? h('p',{class:'na-note warn'},'계정별 지출·입찰·실험 위험·변경 한도 인상이나 운영 기간 확대는 팀장 등급의 검토가 필요할 수 있습니다. 현재 승인 가능 여부는 서버 권한을 따릅니다.') : null,
        saved.schema_version !== 2 ? h('p',{class:'na-note'},'기존 저장 계획은 보존됩니다. 새 운영 기준은 미정이며 판단을 보류합니다. 입력을 편집하면 추가 기준을 포함한 새 초안으로 저장됩니다.') : null,
        renderExistingBudget(),
        h('div',{class:'na-field-grid'},input('goal','운영 목표',null,GOALS),input('target_value',targetLabel(draft.plan.goal)),
          input('daily_spend_cap','계정 하루 광고비 상한(원)'),input('monthly_spend_cap','계정 월 광고비 상한(원)'),input('absolute_bid_cap','계정 절대 입찰 상한(원)'),input('experiment_days','실험 기간(2~30일)'),input('loss_cap','실험 광고비 위험 한도(원)'),
          input('period_start','운영 시작일','date'),input('period_end','운영 종료일','date'),input('conversion_definition','목표 전환의 정의',null,CONVERSIONS),input('value_basis','ROAS 가치 기준',null,VALUES),
          input('measurement_lag_days','전환 측정 대기 기간(0~30일)'),input('minimum_clicks','최소 클릭 표본(회)'),input('minimum_conversions','최소 전환 표본(회)')),
        h('h3',null,'계정별 변경 한도'),h('div',{class:'na-field-grid'},Object.keys(LIMITS).map(function (name) { return input(name,LIMITS[name]); })),
        h('p',{class:'hint'},'미입력은 미정입니다. 0은 해당 방향의 변경 금지이며, 7일 인상 기준 0은 모든 인상에 재승인이 필요하다는 뜻입니다. 공통 비율을 자동 입력하지 않습니다.'),
        h('div',{class:'na-section'},input('notes','운영 방향·검토 메모','textarea')),
        h('p',{class:'hint'},'상한은 이 개별 관리 계정의 기준이며 업체 전체 예산이나 남은 잔액을 뜻하지 않습니다. 실험 광고비 위험 한도는 실제 손실액이 아닙니다. 플랫폼 일반 전환을 구매·리드로, 플랫폼 전환가치를 결제 매출·이익으로 바꾸어 평가하지 않습니다.'),
        h('p',{class:'hint'},'CPA·ROAS는 전환 정의·최소 전환 표본, ROAS는 가치 기준까지 필요합니다. 모든 목표는 월 상한·운영 기간·측정 대기·최소 클릭·변경 한도가 필요합니다. 최소 표본은 담당자 기준이며 A/B 승자나 통계적 유의성을 보장하지 않습니다.'),
        h('p',{class:'na-note',id:'automationPlanStatus','aria-live':'polite'},locked ? lockMessage() : stale ? '다른 계획판과 입력 초안의 버전이 다릅니다.' : draft.dirty ? '저장하지 않은 계획 초안입니다.' : status(head)),
        h('div',{class:'na-actions'},h('button',{type:'button',class:'btn primary',id:'automationPlanSave',disabled:busy || !!locked || !!experimentLocked || data.can_edit !== true || stale || !draft.dirty || Object.keys(draft.invalid).some(function (name) { return draft.invalid[name]; }) || draft.plan.schema_version === 2 && !criteriaValid(draft.plan,false),onclick:function () { mutate('save'); }},'계획 초안 저장'),
          h('button',{type:'button',class:'btn',id:'automationPlanApprove',disabled:busy || !!locked || !!experimentLocked || data.can_approve !== true || stale || draft.dirty || head.state !== 'draft' || !complete(saved),onclick:function () { mutate('approve'); }},'검토 후 계획 승인'),
          h('button',{type:'button',class:'btn',disabled:busy || !!locked,onclick:function () { if (!current() || busy || writeLocks[id]) return; delete drafts[id]; render(); }},'입력 초안 버리기')));
      var empty = {design:['캠페인 설계',executionUI ? '목표·예산·입찰 상한·실험 기간을 검토합니다. 운영계획과 별도로 승인 범위 집행 탭에서 정확한 생성·변경 명령과 자동 운영 위임을 작성합니다.' : '목표·예산·입찰 상한·실험 기간을 저장하고 구체적인 대상·변경 범위를 검토합니다. 현재는 계획 기록 단계이며 광고 변경 경로는 연결되지 않았습니다.'],
        experiments:['A/B 비교·판정','실험군·배분·소재별 성과·전환 지연을 연결한 판정 자료가 없습니다. 이전 기간 비교를 통제된 A/B 실험이나 승자 선정으로 표시하지 않습니다.'],
        improve:['유지·다음 실험','실제 변경·성숙한 전환·비교 조건이 확인된 결과만 다음 방향에 반영합니다. 지금은 자동 개선 실행과 승자 판정 자료가 미연결입니다.'],
        execution:['승인 범위 집행','현재 계정의 실행 문서·권한을 확인한 뒤 자동 운영 위임과 개별 명령을 작성합니다.']};
      var content = tab === 'settings' ? editor : tab === 'history' ? h('article',{class:'card'},h('h2',null,'현재 계획과 승인 기록'),
        h('p',{class:'na-plan-meta'},'계획 ' + env.num(head.version) + '판 · ' + status(head)),head.author ? h('p',null,'작성자 ID ' + env.num(head.author.actor) + ' · ' + env.datedTime(head.author.at)) : null,
        h('p',null,'승인자 ID ' + (head.approved_by == null ? '미승인' : env.num(head.approved_by)) + ' · ' + env.datedTime(head.approved_at)),
        h('p',{class:'na-note'},executionUI ? '이곳은 운영계획 기록입니다. 명령별 송신·반영·복구 초안은 승인 범위 집행 탭에서 확인합니다.' : '광고 실행·변경·복구 기록은 없습니다. 계획 승인이 실행 완료를 뜻하지 않습니다.')) : h('article',{class:'card'},h('h2',null,empty[tab][0]),h('p',{class:'na-note'},empty[tab][1]),
          h('button',{type:'button',class:'btn',onclick:function () { if (!current()) return; tab = 'settings'; render(); }},'목표·계획 작성 열기'));
      if (experimentsUI && tab === 'experiments') {
        content = h('article',{class:'card'},experimentsUI.render(data.experiments,account,current,function () { return busy || !!writeLocks[id] || randomizedLocked(account); },render,head.version),randomizedUI ? randomizedUI.render(data.randomized_experiments,account,current,function () { return busy || !!writeLocks[id] || !!(experimentsUI && experimentsUI.locked(account)); },render,head.version) : null);
      } else { if (experimentsUI) experimentsUI.suspend(); if (randomizedUI) randomizedUI.suspend(); }
      if (executionUI && tab === 'execution') {
        content = h('article',{class:'card'},executionUI.render(data.execution,account,current,function () { return busy || !!writeLocks[id] || randomizedLocked(account) || !!(experimentsUI && experimentsUI.locked(account)); },render,head.version));
      } else if (executionUI) executionUI.suspend();
      if (learningUI && (tab === 'improve' || tab === 'history')) {
        content = h('article',{class:'card'},learningUI.render(data.learning_assets,account,data.can_edit === true && !locked && !experimentLocked,current,function () { return open(account); }));
      }
      var assessment = data.operating_criteria, reliable = assessment && assessment.version === 1 && assessment.execution_enabled === false;
      var criteria = reliable ? assessment : null, limits = saved.schema_version === 2 ? saved.change_limits : {};
      function percent(name) { return finite(limits[name]) ? env.num(limits[name]) + '%' : '미정'; }
      function money(value) { return finite(value) ? env.won(value) : '미정'; }
      var budget = criteria && criteria.budget || {}, metric = criteria && criteria.metric || {};
      var assessmentView = h('section',{class:'na-section'},h('h3',null,'현재 저장 기준의 성과 판정'),
        h('p',{class:'na-note'},criteria && criteria.state === 'reviewable' && criteria.criteria_complete === true && criteria.approval_current === true ? executionUI ? '동일 기준의 성과 비교 가능 · 집행은 별도 승인·원천 검사' : '동일 기준의 성과 비교 가능 · 실제 광고 실행 미연결' : '판단 보류 · 기준·승인·관측 자료를 확인하세요.'),
        h('p',{class:'hint'},'계정 하루 광고비 상한 ' + money(budget.daily_cap) + ' · 월 상한 ' + money(budget.monthly_cap) + ' · 남은 잔액 미확인'),
        criteria && Array.isArray(criteria.reasons) ? h('ul',{class:'hint'},criteria.reasons.slice(0,20).map(function (reason) { return h('li',null,typeof reason.message === 'string' ? reason.message.slice(0,1000) : '판단 근거 미확인'); })) : h('p',{class:'hint'},'운영 기준 판정 자료를 확인하지 못했습니다. 이전 자료나 0으로 대신 판단하지 않습니다.'),
        criteria && criteria.state === 'reviewable' && criteria.criteria_complete === true && criteria.approval_current === true && finite(metric.value) && (metric.status === 'at_target' || metric.status === 'below_target') ? h('p',{class:'na-plan-meta'},(GOALS[metric.goal] || '성과') + ' 관측 값 ' + env.num(metric.value) + (metric.goal === 'cpa' ? '원/정의한 전환' : metric.goal === 'roas' ? '%' : '회') + ' · ' + (metric.status === 'at_target' ? '목표 충족' : '목표 미충족') + ' · 인과 효과·A/B 승자 판정 아님') : null,
        Array.isArray(budget.months) && budget.months.length ? h('p',{class:'hint'},'운영 기간의 월별 가능 상한: ' + budget.months.slice(0,13).map(function (row) { return row.month + ' · ' + env.num(row.active_days) + '일 · ' + money(row.capacity); }).join(' / ') + '. 집행액·잔액을 뜻하지 않습니다.') : null);
      return h('div',{class:'na-content'},h('div',{class:'na-section'},h('h2',null,account.company_name + ' · ' + (account.account_name || '개별 계정')),
        h('p',{class:'na-plan-meta'},'광고 계정 ID ' + (account.ad_account_no || '미확인') + ' · 계약 단계 ' + (account.workflow || '미확인'))),
        h('div',{class:'na-note warn'},executionUI ? '운영계획·학습·관측 비교 승인과 실제 집행을 구분합니다. 무작위 시간 블록 실험의 승인은 별도 소재 전환 일정 위임입니다. 서버 실행 기능과 광고주별 구체적 승인 상태, 송신·반영 재조회를 확인하세요.' : '계획·성과·세팅·실험 이력을 기록하고 검수합니다. 계획 승인과 학습 기록은 실제 광고 집행이 아닙니다. 실제 광고 자동 실행은 미연결 상태입니다. Claude는 키·모델 연결 설정 후 보고서에서 명시적으로 생성합니다.'),
        locked ? h('div',{class:'na-note warn','aria-live':'polite'},lockMessage(),locked.state === 'saved' ? h('button',{type:'button',class:'btn',id:'automationPlanRefresh',disabled:busy,onclick:function () { if (current() && !busy) open(account); }},'최신 계획 재조회') : null) : null,
        experimentLocked ? h('p',{class:'na-note warn'},'A/B 실험 요청의 최신 판 확인 전까지 운영계획·학습 자산의 추가 쓰기를 보류합니다. A/B 실험 탭에서 최신 계획·관측을 확인하세요.') : null,
        h('nav',{class:'na-tabs','aria-label':'자동화 계획 보기'},Object.keys(TABS).map(function (name) { return h('button',{type:'button',class:'chip' + (tab === name ? ' on' : ''),'aria-pressed':String(tab === name),onclick:function () { if (!current()) return; tab = name; render(); }},TABS[name]); })),
        h('div',{class:'na-layout'},h('div',null,content),h('aside',{class:'card'},h('h3',null,'실행 전 준비 상태'),h('p',{class:'na-note'},executionUI ? '목표·한도·대상 운영계획과 실행 위임·개별 명령을 별도로 승인합니다. 운영계획 승인만으로 송신을 시작하지 않습니다.' : '목표·한도·대상 계획을 검토하는 단계입니다. 승인 후에도 현재 실행 기능은 활성화되지 않습니다.'),
          h('p',{class:'hint'},executionUI ? '송신 전 계약 단계·현재 설정·자체 자동입찰·성과 원천·한도를 재검사합니다. 자체 큐 중단과 플랫폼 광고 잠금 확인은 다릅니다.' : '향후 실행 전에는 계약 단계·현재 설정·네이버 자체 자동입찰 여부를 확인해야 합니다. 현재 실제 실행 검증 경로는 미연결입니다.'),
          h('p',{class:'na-plan-meta'},'현재 저장한 계정별 한도: 1회 인상 +' + percent('single_increase_percent') + ' / 인하 −' + percent('single_decrease_percent') +
            ' · 최근 24시간 인상 +' + percent('rolling_day_increase_percent') + ' / 인하 −' + percent('rolling_day_decrease_percent') +
            ' · 7일 누적 인상 +' + percent('weekly_increase_requires_approval_percent') + ' 초과는 재승인'),
          assessmentView,h('button',{type:'button',class:'btn',disabled:!executionUI,onclick:function () { if (!current() || !executionUI) return; tab = 'execution'; render(); }},executionUI ? '실행 승인·상태 보기' : '자동 실행 · 미연결'))),renderSetup(env,data.setup_checks));
    }
    function suspend() { epoch++; if (controller) controller.abort(); clearTimeout(timer); busy = false; shown = null; if (learningUI && typeof learningUI.suspend === 'function') learningUI.suspend(); if (experimentsUI) experimentsUI.suspend(); if (executionUI) executionUI.suspend(); if (randomizedUI) randomizedUI.suspend(); displayedMark = null; displayedContext = null; if ($('automationRoot')) put($('automationRoot')); }
    function reset() { epoch++; session++; if (controller) controller.abort(); clearTimeout(timer); busy = false; shown = null; selected = null; rows = []; listing = null; drafts = {}; writeLocks = {}; if (learningUI) learningUI.reset(); if (experimentsUI) experimentsUI.reset(); if (executionUI) executionUI.reset(); if (randomizedUI) randomizedUI.reset(); displayedMark = null; displayedContext = null; q = ''; page = 0; tab = env.learningEntry === true ? 'improve' : 'settings'; if ($('automationRoot')) put($('automationRoot')); }
    return {load:load,reset:reset,suspend:suspend,planCapability:planCapability,learningCapability:learningCapability,learningSourceCapability:learningSourceCapability,experimentCapability:experimentCapability,randomizedCapability:randomizedCapability,executionCapability:executionCapability,hasUnsaved:hasUnsaved};
  }
  window.NaverAutomation = {create:create,renderSetup:renderSetup,model:{documentPlan:documentPlan,complete:complete}};
}());
