/* Source-bound experiment plans and observations. No advertising or AI execution. */
(function () {
  'use strict';
  var EXPLORATORY = 'exploratory_paired_day_hac_v1';
  var METHODS = {two_proportion_fixed_horizon_95_80_v1:'비율 차이의 고정 기간 설계 · 양측 95% / 검정력 80%',observational_only_v1:'관측 비교만 계획 · 통계적 승자 판정 없음',exploratory_paired_day_hac_v1:'일별 짝 관측 · 탐색적 운영 비교(비교정 진단)'};
  var EXPLORATORY_NOTICE = '탐색적 · 비교정 · 비무작위 · 비인과. 진단 밴드는 상대 차이 ±3×일별 짝 관측의 HAC 표준오차이며 계수 3은 검증되지 않은 운영 휴리스틱입니다. 확정 승자·통계적 동등성·인과 효과를 입증하지 않으며 광고 변경을 시작하지 않습니다.';
  var DECISION_FIELDS = ['version','method','evidence_grade','decision','recommended_arm','winner','causal_claim','randomized','formal_equivalence','calibration_verified','calibration','effect_percent','margin_percent','band','standard_error_percent','paired_days','bandwidth','band_multiplier','complete_week_blocks','remainder_days','preregistered','reason_codes','qualifiers'];
  var DECISIONS = {conditional_preference:'조건부 관측 추천',within_material_margin:'관측 기준 내 차이',inconclusive:'탐색적 비교 결론 보류',hold:'탐색적 비교 조건 미충족 · 보류'};
  var QUALIFIERS = {exploratory_policy_not_calibrated:'진단 계수와 판정 정책의 보장 수준은 교정되지 않았습니다.',observed_settings_not_full_history:'조회 사이의 설정 변경과 전체 설정 이력은 미확인입니다.',no_random_assignment:'실제 무작위 배정·독립 실험 단위를 확인한 자료가 아닙니다.',general_platform_events_not_orders:'일반 플랫폼 전환 이벤트이며 실제 주문·고유 고객 수가 아닙니다.',vat_basis_not_commerce_profit:'광고비는 VAT 포함 집계이며 실제 결제 매출·순이익이 아닙니다.',residual_days_in_full_estimate:'완결 7일 블록 밖의 잔여일도 전체 합계와 진단 밴드 계산에 포함합니다.'};
  var GOALS = {ctr:'클릭률(CTR)',cvr:'플랫폼 일반 전환율(CVR)',cpa:'플랫폼 일반 전환 CPA',roas:'플랫폼 일반 전환가치 ROAS'};
  var KINDS = {campaign:'캠페인',adgroup:'광고그룹',keyword:'키워드',ad:'소재'};
  var STATES = {draft:'계획 초안',approved:'계획 승인 · 광고 집행 아님',empty:'계획 작성 전'};
  var FIELDS = ['schema_version','single_variable','hypothesis','goal','control_key','treatment_key','period_start','period_end','measurement_lag_days','sample_share','mde_percent','declared_control_sample','declared_treatment_sample','method','experiment_spend_cap','control_daily_cap','treatment_daily_cap'];
  var METRICS = {impCnt:'노출수',clkCnt:'클릭수',salesAmt:'광고비(VAT 포함, 원)',ccnt:'플랫폼 일반 전환수',convAmt:'플랫폼 일반 전환가치(원)'};
  var REASONS = {OBSERVATIONAL_METHOD:'관측 비교 방법을 선택함 · 통계적 승자 판정 없음',CTR_DESIGN_ONLY:'조건부 표본 설계는 현재 CTR에만 지원',BASELINE_UNAVAILABLE:'완결된 동일 대조군 기준 기간 자료 미확인',BASELINE_RATE_INVALID:'기준 CTR이 0 또는 1이어서 이 설계로 표본 계산 불가',ALTERNATIVE_RATE_INVALID:'선택한 상대 차이로 유효한 대립 비율을 만들 수 없음',SAMPLE_OUT_OF_RANGE:'계산 표본이 지원 범위를 벗어남',DECLARED_SAMPLE_TOO_SMALL:'선언한 표본이 조건부 필요 표본보다 적음',VOLUME_ESTIMATE_UNAVAILABLE:'같은 기간 양군 노출량이 없어 예상 기간 미확인',COST_ESTIMATE_UNAVAILABLE:'양군의 같은 기간 노출·광고비가 없어 예상 비용 미확인',ESTIMATED_HORIZON_EXCEEDS_PLAN:'조건부 예상 기간이 계획 기간을 초과',ESTIMATED_SPEND_EXCEEDS_CAP:'조건부 예상 광고비가 실험 상한을 초과',ASSIGNMENT_PROOF_UNAVAILABLE:'실제 무작위 배정·독립 관측 단위 증거 미연결',EXECUTION_NOT_CONNECTED:'실제 광고 집행 기능 미연결',PLAN_CHANGED:'승인한 운영계획이 현재 판과 다름',SOURCE_CHANGED:'대상 설정·귀속·원천 판이 바뀜',NOT_APPROVED:'실험 계획 미승인',NOT_PREREGISTERED:'시작 전 사전 승인 미확인',SOURCE_UNAVAILABLE:'현재 관측 원천 미확인',SOURCE_INVALID:'원천 검증 실패',SOURCE_PENDING:'관측 수집 대기',SOURCE_PARTIAL:'관측 수치 부분 수집',SOURCE_RETRY:'관측 수집 재시도 필요',SOURCE_LIMITED:'원천 조회 제한',SOURCE_REAUTH_REQUIRED:'계정 권한 확인 필요',SOURCE_SUPERSEDED:'승인 또는 원천 판 변경으로 수집 보류',PARTIAL_METRICS:'비교에 필요한 양군 수치가 완결되지 않음',SOURCE_CYCLE_MISMATCH:'양군의 원천 수집 회차가 달라 비교 보류',GOAL_METRIC_UNAVAILABLE:'정의한 목표 지표를 계산할 원천 미확인',CONVERSION_DEFINITION_MISMATCH:'플랫폼 일반 전환과 승인한 전환 정의가 다름',VALUE_BASIS_MISMATCH:'플랫폼 전환가치와 승인한 가치 기준이 다름',MEASUREMENT_LAG_NOT_MATURE:'계획 기간 종료와 전환 지연 대기가 아직 끝나지 않음',HORIZON_NOT_COMPLETE:'사전 계획한 비교 기간 미완료',CONTROL_SAMPLE_BELOW_PLAN:'대조군 실제 표본이 선언 기준보다 적음',TREATMENT_SAMPLE_BELOW_PLAN:'비교군 실제 표본이 선언 기준보다 적음',OBSERVED_SPEND_AT_CAP_NO_AD_STOP:'관측 광고비가 실험 상한에 도달 · 실제 광고 중단은 실행되지 않음',VARIANCE_UNAVAILABLE:'CPA·ROAS 합계의 분산 자료 미확인 · 승자 판정 불가'};
  REASONS.CONTROL_DAILY_CAP_INSUFFICIENT = '대조군의 조건부 예상 광고비가 하루 상한과 계획 기간의 가능 범위를 초과';
  REASONS.TREATMENT_DAILY_CAP_INSUFFICIENT = '비교군의 조건부 예상 광고비가 하루 상한과 계획 기간의 가능 범위를 초과';
  REASONS.BUDGET_HORIZON_OUT_OF_RANGE = '상한을 적용한 예상 기간이 안전한 계산 범위를 벗어남';
  Object.assign(REASONS,{EXPLORATORY_UNCALIBRATED_METHOD:'일별 짝 관측의 비교정 휴리스틱 · 통계적 보장 수준 미검증',SOURCE_NOT_CURRENT:'현재 승인 대상과 원천 설정을 다시 확인해야 함',SETTINGS_NOT_OBSERVED:'비교 기간에 필요한 설정 관측 날짜 미확인',SETTINGS_DRIFT:'관측 중 관련 설정 변경이 감지되어 비교 보류',DAILY_COVERAGE_INCOMPLETE:'연속한 양군 일별 수치가 완결되지 않음',MEASUREMENT_LAG_UNDEFINED:'전환 지연 대기 일수가 미정',SOURCE_CYCLE_UNAVAILABLE:'일별 원천 수집 회차 미확인',SOURCE_CYCLE_BEHIND:'현재 승인 판 이후의 원천 재확인 필요',MATERIAL_MARGIN_UNDEFINED:'사전 실질차이 기준 미입력',SAMPLE_UNDEFINED:'양군의 선언 표본 기준 미입력',CONTROL_CLICKS_BELOW_PLAN:'대조군 실제 클릭 수가 승인 운영 최소 기준보다 적음',TREATMENT_CLICKS_BELOW_PLAN:'비교군 실제 클릭 수가 승인 운영 최소 기준보다 적음',CONTROL_CONVERSIONS_BELOW_PLAN:'대조군 일반 전환수가 승인 운영 최소 기준보다 적음',TREATMENT_CONVERSIONS_BELOW_PLAN:'비교군 일반 전환수가 승인 운영 최소 기준보다 적음',SPEND_UNAVAILABLE:'판정에 필요한 광고비 원천 미확인',CONTROL_DAILY_CAP_EXCEEDED:'대조군 관측 광고비가 하루 한도를 초과',TREATMENT_DAILY_CAP_EXCEEDED:'비교군 관측 광고비가 하루 한도를 초과',REQUIRED_METRIC_UNAVAILABLE:'선택한 목표와 운영 최소 기준에 필요한 원천 수치 미확인',DENOMINATOR_UNAVAILABLE:'목표 비율의 분모가 없거나 0이어서 비교 보류',CONTROL_REFERENCE_UNAVAILABLE:'상대 차이의 대조군 기준값이 없거나 0',NONFINITE_DIAGNOSTIC:'진단 계산 범위를 벗어난 수치로 비교 보류',ZERO_VARIANCE:'일별 변동 근거가 없어 진단 밴드로 판단하지 않음',WEEK_BLOCK_UNAVAILABLE:'완결된 7일 블록별 비교 근거 미확인',DIAGNOSTIC_AND_BLOCKS_INCONCLUSIVE:'진단 밴드와 네 주간 블록이 사전 기준을 함께 충족하지 않음'});
  var DIAGNOSTIC_REASONS = 'NOT_APPROVED NOT_PREREGISTERED PLAN_CHANGED SOURCE_CHANGED SOURCE_UNAVAILABLE SOURCE_NOT_CURRENT SETTINGS_NOT_OBSERVED SETTINGS_DRIFT DAILY_COVERAGE_INCOMPLETE HORIZON_NOT_COMPLETE MEASUREMENT_LAG_UNDEFINED MEASUREMENT_LAG_NOT_MATURE SOURCE_CYCLE_UNAVAILABLE SOURCE_CYCLE_MISMATCH SOURCE_CYCLE_BEHIND CONVERSION_DEFINITION_MISMATCH VALUE_BASIS_MISMATCH MATERIAL_MARGIN_UNDEFINED SAMPLE_UNDEFINED CONTROL_SAMPLE_BELOW_PLAN TREATMENT_SAMPLE_BELOW_PLAN CONTROL_CLICKS_BELOW_PLAN TREATMENT_CLICKS_BELOW_PLAN CONTROL_CONVERSIONS_BELOW_PLAN TREATMENT_CONVERSIONS_BELOW_PLAN SPEND_UNAVAILABLE OBSERVED_SPEND_AT_CAP_NO_AD_STOP CONTROL_DAILY_CAP_EXCEEDED TREATMENT_DAILY_CAP_EXCEEDED REQUIRED_METRIC_UNAVAILABLE DENOMINATOR_UNAVAILABLE CONTROL_REFERENCE_UNAVAILABLE NONFINITE_DIAGNOSTIC ZERO_VARIANCE WEEK_BLOCK_UNAVAILABLE DIAGNOSTIC_AND_BLOCKS_INCONCLUSIVE'.split(' ');
  var STABILITY_FIELDS = ['qualifier','expected_days','observed_days','missing_days','drift','coverage_complete','first_checked_at','last_checked_at','limitations'];
  var FIELD_LABELS = {method:'설계 방법',goal:'비교 지표',single_variable:'비교 변수',hypothesis:'검증 가설',control_key:'대조군',treatment_key:'비교군',period_start:'시작일',period_end:'종료일',measurement_lag_days:'전환 지연 대기',mde_percent:'최소 의미 차이',sample_share:'표본 배분 비중',declared_control_sample:'대조군 선언 표본',declared_treatment_sample:'비교군 선언 표본',experiment_spend_cap:'실험 광고비 상한',control_daily_cap:'대조군 하루 상한',treatment_daily_cap:'비교군 하루 상한'};
  function emptyProtocol() { var out = {}; FIELDS.forEach(function (name) { out[name] = name === 'schema_version' ? 1 : name === 'hypothesis' ? '' : null; }); return out; }
  function plain(value) { return !!value && typeof value === 'object' && !Array.isArray(value); }
  function copy(value) { return JSON.parse(JSON.stringify(value)); }
  function finite(value) { return typeof value === 'number' && Number.isFinite(value); }
  function opaque(value) { return typeof value === 'string' && /^[0-9a-f]{32}$/.test(value); }
  function version(value) { return Number.isSafeInteger(value) && value >= 0; }
  function bounded(value,limit) { return Array.isArray(value) ? value.slice(0,limit || 100) : []; }
  function day(value) { return typeof value === 'string' && /^[0-9]{4}-[0-9]{2}-[0-9]{2}$/.test(value) && value.slice(0,4) !== '0000' && finite(Date.parse(value+'T00:00:00Z')) && new Date(value+'T00:00:00Z').toISOString().slice(0,10) === value; }
  function requestId() {
    var crypto = window.crypto;
    if (crypto && typeof crypto.randomUUID === 'function') return crypto.randomUUID().replace(/-/g,'');
    if (crypto && typeof crypto.getRandomValues === 'function') return Array.from(crypto.getRandomValues(new Uint8Array(16)),function (v) { return ('0'+v.toString(16)).slice(-2); }).join('');
    return null;
  }
  function create(env) {
    var h = env.h, put = env.put, shown = null, drafts = {}, locks = {}, cache = {}, inputs = {}, failures = {}, floors = {}, session = 0, revision = 0, controller = null;
    function key(account) { return account.possibility_id+'|'+account.account_key; }
    function active(ctx) { return shown === ctx && ctx.session === session && ctx.guard() && env.active() && ctx.context === env.context() && (ctx.mounting || ctx.root.isConnected !== false); }
    function locked(account) { return !!account && !!locks[key(account)]; }
    function planCurrent(ctx) { var plan = ctx.data.plan_ref; return plain(plan) && plan.state === 'approved' && version(plan.version) && plan.version > 0 && (ctx.parentPlanVersion === undefined || plan.version === ctx.parentPlanVersion); }
    function hasUnsaved() { return Object.keys(drafts).some(function (id) { return drafts[id].dirty; }); }
    function identity(data,account) {
      return Number.isSafeInteger(account.possibility_id) && account.possibility_id > 0 && /^[0-9a-f]{64}$/.test(account.account_key || '') && plain(data) && data.execution_enabled === false && plain(data.selection) && data.selection.possibility_id === account.possibility_id && data.selection.account_key === account.account_key &&
        Array.isArray(data.candidates) && Array.isArray(data.experiments) && (data.selected === null || plain(data.selected) && opaque(data.selected.id) && version(data.selected.version) && valid({protocol:data.selected.protocol,invalid:{}}));
    }
    function head(ctx) { return ctx.data.selected; }
    function draft(ctx) { return drafts[key(ctx.account)]; }
    function stale(ctx,item) { var current = head(ctx); return item.id !== (current ? current.id : null) || item.baseVersion !== (current ? current.version : 0); }
    function editable(ctx,item) { return active(ctx) && planCurrent(ctx) && !ctx.busy && !locked(ctx.account) && !failures[key(ctx.account)] && !ctx.blocked() && ctx.data.can_edit === true && !stale(ctx,item) && (!head(ctx) || head(ctx).state === 'draft'); }
    function capability(body) {
      var ctx = shown, item = ctx && draft(ctx), current = ctx && head(ctx);
      if (!ctx || !active(ctx) || !planCurrent(ctx) || ctx.busy || ctx.blocked() || !plain(body) || body.possibility_id !== ctx.account.possibility_id || body.account_key !== ctx.account.account_key ||
          !version(body.expected_version) || body.expected_version !== (current ? current.version : 0) || body.experiment_id !== (current ? current.id : null) || typeof body.request_id !== 'string' || !/^[0-9a-f]{32}$/.test(body.request_id)) return false;
      var recovery = locks[key(ctx.account)];
      if (recovery && recovery.state === 'unknown') return ctx.data.can_edit === true && JSON.stringify(body) === JSON.stringify(recovery.body);
      if (locked(ctx.account) || failures[key(ctx.account)]) return false;
      var base = 'account_key|action|expected_version|experiment_id|possibility_id|request_id';
      if (body.action === 'save') return Object.keys(body).sort().join('|') === 'account_key|action|expected_version|experiment_id|possibility_id|protocol|request_id' && !!item && editable(ctx,item) && item.dirty && valid(item) && JSON.stringify(body.protocol) === JSON.stringify(item.protocol);
      return Object.keys(body).sort().join('|') === base && !!current && !(item && (item.dirty || stale(ctx,item))) && (body.action === 'approve' && current.state === 'draft' && ctx.data.can_approve === true || body.action === 'collect_request' && current.state === 'approved' && ctx.data.can_collect === true);
    }
    function path(ctx,id) { var lock = locks[key(ctx.account)]; return '/experiments?possibility_id='+ctx.account.possibility_id+'&account_key='+encodeURIComponent(ctx.account.account_key)+(id ? '&experiment_id='+encodeURIComponent(id) : '')+(lock && lock.state === 'unknown' ? '&request_id='+lock.request_id : ''); }
    function message(ctx,text) { ctx.message = text; if (active(ctx)) draw(ctx); }
    function accept(ctx,data) {
      if (!identity(data,ctx.account)) throw new Error('experiment-identity');
      var id = key(ctx.account), lock = locks[id], current = data.selected;
      if (current && (floors[id+'|'+current.id] || 0) > current.version) throw new Error('experiment-old-version');
      if (lock && lock.state === 'unknown') {
        var recovered = data.recovery_receipt;
        if (!plain(recovered) || Object.keys(recovered).sort().join('|') !== 'experiment_id|protocol_version|request_id|version' || !opaque(recovered.experiment_id) ||
            !version(recovered.version) || recovered.version <= lock.expectedVersion || !version(recovered.protocol_version) || recovered.protocol_version < 1 || recovered.request_id !== lock.request_id ||
            lock.id !== null && lock.id !== recovered.experiment_id || !current || current.id !== recovered.experiment_id || current.version < recovered.version) throw new Error('experiment-recovery-unconfirmed');
        lock.state = 'saved'; lock.id = recovered.experiment_id; lock.version = recovered.version;
      }
      if (lock && lock.state === 'saved') {
        if (!version(lock.version) && current && current.request_id === lock.request_id) { lock.id = current.id; lock.version = current.version; }
        if (!version(lock.version)) throw new Error('experiment-receipt-unconfirmed');
        if (!current || current.id !== lock.id || current.version < lock.version || current.version <= lock.expectedVersion) throw new Error('experiment-old-version');
        delete locks[id]; delete drafts[id];
      }
      if (current) floors[id+'|'+current.id] = current.version;
      if (!lock && drafts[id] && drafts[id].id === null && drafts[id].dirty) data = Object.assign({},data,{selected:null});
      delete failures[id]; cache[id] = data; ctx.data = data;
    }
    function refresh(ctx,id) {
      if (!active(ctx) || ctx.busy) return Promise.resolve();
      if (controller) controller.abort(); controller = new AbortController(); var mark = ++revision; ctx.busy = true; draw(ctx);
      return env.api('GET',path(ctx,id || (locks[key(ctx.account)] || {}).id || (head(ctx) || {}).id),undefined,controller.signal).then(function (data) {
        if (!active(ctx) || mark !== revision) return; accept(ctx,data); ctx.message = ''; ctx.busy = false; draw(ctx); ctx.onChange();
      }).catch(function (error) {
        if (!active(ctx) || mark !== revision) return; ctx.busy = false; failures[key(ctx.account)] = true;
        if (env.denied(error)) { env.purge(error); return; }
        message(ctx,locked(ctx.account) ? requestMessage(locks[key(ctx.account)]) : '최신 계획·관측을 확인하지 못했습니다. 이전 성공 결과를 현재 상태로 사용하지 않습니다.');
      });
    }
    function requestMessage(lock) { return lock.state === 'unknown' ? '실험 요청의 처리 결과가 미확인입니다. 요청 식별자와 입력을 보존했으며 저장 영수증 확인 전까지 새 저장·승인·수집을 보류합니다.' : '실험 요청은 서버에서 확인되었습니다. 최신 판 확인 전까지 추가 저장·승인·수집 요청을 보류합니다.'; }
    function mutate(ctx,action) {
      if (!active(ctx)) return;
      var current = head(ctx), token = requestId();
      if (!token || !/^[0-9a-f]{32}$/.test(token)) { message(ctx,'안전한 요청 식별자를 만들 수 없습니다. 보안 연결에서 다시 열어 주세요.'); return; }
      var body = {possibility_id:ctx.account.possibility_id,account_key:ctx.account.account_key,experiment_id:current ? current.id : null,expected_version:current ? current.version : 0,request_id:token,action:action};
      if (action === 'save') body.protocol = copy(draft(ctx).protocol);
      if (!capability(body)) return;
      return submit(ctx,body);
    }
    function replay(ctx) { var lock = locks[key(ctx.account)]; if (lock && lock.state === 'unknown' && capability(lock.body)) return submit(ctx,copy(lock.body)); }
    function submit(ctx,body) {
      var id = key(ctx.account), token = body.request_id, currentSession = session, prior = locks[id], uncertain = prior && prior.state === 'unknown', pending = env.api('POST','/experiments',body);
      locks[id] = {state:'pending',expectedVersion:body.expected_version,id:body.experiment_id,request_id:token,body:copy(body)}; ctx.busy = true; draw(ctx); ctx.onChange();
      return pending.then(function (receipt) {
        if (currentSession !== session || !locks[id] || locks[id].request_id !== token) return;
        var lock = locks[id]; lock.state = 'saved';
        if (!plain(receipt) || !opaque(receipt.experiment_id) || !version(receipt.version) || receipt.version <= body.expected_version || receipt.request_id !== token) throw new Error('experiment-receipt');
        lock.id = receipt.experiment_id; lock.version = receipt.version;
        if (!shown || key(shown.account) !== id || !active(shown)) return;
        shown.busy = false; return refresh(shown,lock.id);
      }).catch(function (error) {
        if (currentSession !== session || !locks[id] || locks[id].request_id !== token) return;
        if (env.denied(error)) { env.purge(error); return; }
        var saved = locks[id].state === 'saved', definite = error && (error.status === 400 || error.status === 409);
        if (!saved && (uncertain || !definite)) locks[id].state = 'unknown';
        else if (!saved) delete locks[id];
        if (!shown || key(shown.account) !== id || !active(shown)) return;
        shown.busy = false; message(shown,locks[id] ? requestMessage(locks[id]) : error && error.status === 409 ? '실험 계획 또는 원천 판이 바뀌었습니다. 입력 초안은 보존했으며 최신 자료 확인이 필요합니다.' : '요청을 완료하지 못했습니다. 입력 초안을 보존했습니다.');
      });
    }
    function valid(item) {
      if (!item || !plain(item.protocol) || Object.keys(item.protocol).sort().join('|') !== FIELDS.slice().sort().join('|') || Object.keys(item.invalid).some(function (name) { return item.invalid[name]; })) return false;
      var p = item.protocol;
      if (p.schema_version !== 1 || typeof p.hypothesis !== 'string' || p.hypothesis.length > 1000 || p.single_variable !== null && (typeof p.single_variable !== 'string' || p.single_variable.length > 160)) return false;
      if (p.goal !== null && !Object.prototype.hasOwnProperty.call(GOALS,p.goal) || p.method !== null && !Object.prototype.hasOwnProperty.call(METHODS,p.method)) return false;
      if (['control_key','treatment_key'].some(function (name) { return p[name] !== null && (typeof p[name] !== 'string' || !/^[0-9a-f]{64}$/.test(p[name])); }) || p.control_key !== null && p.control_key === p.treatment_key) return false;
      if (['period_start','period_end'].some(function (name) { return p[name] !== null && !day(p[name]); }) || p.period_start !== null && p.period_end !== null && (p.period_start > p.period_end || (Date.parse(p.period_end)-Date.parse(p.period_start))/86400000 >= 30)) return false;
      return ['measurement_lag_days','sample_share','mde_percent','declared_control_sample','declared_treatment_sample','experiment_spend_cap','control_daily_cap','treatment_daily_cap'].every(function (name) {
        var value = p[name], integer = name === 'measurement_lag_days' || name.indexOf('declared_') === 0;
        var low = name === 'measurement_lag_days' ? 0 : name === 'sample_share' ? 0.1 : name.indexOf('declared_') === 0 ? 1 : 1e-12;
        var high = name === 'measurement_lag_days' ? 30 : name === 'sample_share' ? 0.9 : name === 'mde_percent' ? 100 : integer ? 1e9 : 1e12;
        return value === null || finite(value) && value >= low && value <= high && (!integer || Number.isSafeInteger(value));
      });
    }
    function start(ctx) {
      if (!active(ctx) || !planCurrent(ctx) || ctx.busy || locked(ctx.account) || failures[key(ctx.account)] || ctx.blocked() || ctx.data.can_edit !== true) return;
      if (draft(ctx) && draft(ctx).dirty) { message(ctx,'저장하지 않은 입력이 있습니다. 저장하거나 초안을 버린 뒤 새 계획을 작성해 주세요.'); return; }
      // The server template carries nullable values; never fill universal numerical defaults.
      ctx.data = Object.assign({},ctx.data,{selected:null}); cache[key(ctx.account)] = ctx.data;
      var protocol = emptyProtocol();
      drafts[key(ctx.account)] = {id:null,baseVersion:0,protocol:protocol,baseline:JSON.stringify(protocol),dirty:true,invalid:{}};
      ctx.message = ''; draw(ctx);
    }
    function text(value) { return typeof value === 'string' ? value.slice(0,1000) : ''; }
    function number(value,suffix) { return finite(value) ? env.num(value)+(suffix || '') : '미확인'; }
    function candidateLabel(row,index) { var path = bounded(row.path,3).filter(function (part) { return typeof part === 'string'; }).map(function (part) { return part.slice(0,160); }); return (KINDS[row.kind] || '대상')+' '+env.num(index+1)+' · '+(path.length ? path.join(' › ') : text(row.label) || '이름 미확인'); }
    function reasons(value) { return bounded(value,30).map(function (row) { return h('li',null,text(row.message) || '추가 조건 확인 필요',row.next_action ? h('p',{class:'hint'},text(row.next_action)) : null); }); }
    function draw(ctx) {
      if (!active(ctx)) return;
      var data = ctx.data, current = head(ctx), item = draft(ctx), lock = locks[key(ctx.account)];
      if (!item && current) item = drafts[key(ctx.account)] = {id:current.id,baseVersion:current.version,protocol:copy(current.protocol),baseline:JSON.stringify(current.protocol),dirty:false,invalid:{}};
      if (item && !item.dirty && current) { item.id = current.id; item.baseVersion = current.version; item.protocol = copy(current.protocol); item.baseline = JSON.stringify(current.protocol); }
      put(ctx.root,h('h3',null,'원천 연결 A/B 계획·관측 비교'),
        h('p',{class:'na-note'},'계획 승인과 관측 요청은 광고 집행이 아닙니다. 실제 무작위 배정·독립 표본 원천이 연결되지 않아 현재 결과는 관측 비교이며 승자·인과 효과를 확정하지 않습니다.'),
        ctx.message ? h('p',{class:'na-note warn','aria-live':'polite'},ctx.message) : null,
        !planCurrent(ctx) ? h('p',{class:'na-note warn'},'현재 승인된 운영계획과 화면의 판이 일치하지 않습니다. 계정 전체 자료를 새로 확인하기 전까지 실험 저장·승인·수집 요청을 보류합니다.') : null,
        lock ? h('p',{class:'na-note warn','aria-live':'polite'},lock.state === 'pending' ? '실험 요청 결과를 확인 중입니다. 중복 저장·승인·수집을 보류합니다.' : requestMessage(lock)) : null,
        h('div',{class:'na-actions'},h('button',{type:'button',class:'btn',id:'experimentNew',disabled:ctx.busy || !!lock || !planCurrent(ctx) || !!failures[key(ctx.account)] || ctx.blocked() || data.can_edit !== true,onclick:function () { start(ctx); }},'새 A/B 계획'),
          h('button',{type:'button',class:'btn',id:'experimentRefresh',disabled:ctx.busy,onclick:function () { refresh(ctx); }},'최신 계획·관측 확인'),
          lock && lock.state === 'unknown' ? h('button',{type:'button',class:'btn',disabled:!capability(lock.body),onclick:function () { replay(ctx); }},'같은 요청 다시 확인') : null),
        sourceView(ctx),candidateView(ctx),historyPicker(ctx),item ? editor(ctx,item) : h('p',{class:'hint'},'같은 종류의 서로 다른 대상을 선택하고 비교할 한 가지 변수와 계획을 작성하세요.'),
        current ? planningView(ctx,current.planning) : null,current ? resultView(ctx,current) : null,
        h('ul',{class:'hint'},bounded(data.limitations,12).map(function (line) { return h('li',null,text(line)); })));
    }
    function sourceView(ctx) {
      var source = ctx.data.source || {}, plan = ctx.data.plan_ref || {}, criteria = head(ctx) && head(ctx).criteria || {};
      var definitions = {platform:'플랫폼 일반 전환',purchase:'구매 전환 정의',lead:'문의·리드 정의'}, values = {platform_conversion_value:'플랫폼 전환가치',paid_order_revenue:'결제 매출 기준',gross_profit:'매출총이익 기준'};
      return h('div',{class:'na-section'},h('p',{class:'hint'},'후보 원천: '+({ready:'현재 후보 확인',unavailable:'현재 후보 미확인',stale:'이전 원천 · 현재 사용 보류'}[source.status] || '현재 상태 미확인')+' · 기준 기간 '+text(source.period_start || '미확인')+' ~ '+text(source.period_end || '미확인')+' · 확인 '+env.datedTime(source.checked_at)),
        h('p',{class:'hint'},'운영계획 '+(version(plan.version) ? env.num(plan.version)+'판' : '판 미확인')+' · '+(plan.state === 'approved' ? '승인' : '현재 승인 미확인')+' · 전환 정의: '+(definitions[criteria.conversion_definition || plan.conversion_definition] || '미확인')+' · 가치 기준: '+(values[criteria.value_basis || plan.value_basis] || '미확인')));
    }
    function candidateView(ctx) {
      var candidates = bounded(ctx.data.candidates);
      return h('details',{class:'na-section'},h('summary',null,'현재 원천 후보 '+env.num(candidates.length)+'개'),
        h('p',{class:'hint'},'동일 종류의 서로 다른 대상을 한 개씩 비교합니다. 현재 업체·계정에서 확인한 원천 후보이며 설정이나 귀속이 바뀌면 다시 선택·승인해야 합니다.'),
        candidates.length ? h('ul',{class:'hint'},candidates.map(function (row,index) { return h('li',null,candidateLabel(row,index)); })) : h('p',{class:'na-note'},'현재 사용할 완결 후보가 없습니다. 설정 수집 상태·캠페인 보유 여부를 확인하세요.'));
    }
    function historyPicker(ctx) {
      return bounded(ctx.data.experiments,50).length ? h('div',{class:'na-section'},h('h4',null,'저장한 실험 계획'),h('div',{class:'na-actions'},bounded(ctx.data.experiments,50).map(function (row,index) {
        return h('button',{type:'button',class:'btn sm',disabled:ctx.busy || locked(ctx.account),onclick:function () {
          if (!active(ctx) || ctx.busy || locked(ctx.account) || !opaque(row.id)) return;
          if (draft(ctx) && draft(ctx).dirty) { message(ctx,'저장하지 않은 입력을 먼저 저장하거나 버려 주세요.'); return; }
          delete drafts[key(ctx.account)]; refresh(ctx,row.id);
        }},'실험 '+env.num(index+1)+' · 문서 '+env.num(row.protocol_version)+'판 · '+(STATES[row.state] || '상태 미확인'));
      }))) : null;
    }
    function editor(ctx,item) {
      var p = item.protocol, current = head(ctx), readOnly = !editable(ctx,item);
      function update(name,value,error) {
        if (!editable(ctx,item)) return;
        p[name] = value; item.invalid[name] = !!error; item.dirty = item.baseVersion === 0 || JSON.stringify(p) !== item.baseline || Object.keys(item.invalid).some(function (field) { return item.invalid[field]; });
        var save = ctx.root.querySelector('[data-experiment-save]'); if (save) save.disabled = !editable(ctx,item) || !item.dirty || !valid(item);
        ['approve','collect'].forEach(function (action) { var button = ctx.root.querySelector('[data-experiment-'+action+']'); if (button) button.disabled = item.dirty || ctx.busy || locked(ctx.account) || ctx.blocked() || !current || action === 'approve' && (current.state !== 'draft' || ctx.data.can_approve !== true) || action === 'collect' && (current.state !== 'approved' || ctx.data.can_collect !== true); });
        var status = ctx.root.querySelector('[data-experiment-draft]'); if (status) status.textContent = valid(item) ? '저장하지 않은 입력 초안입니다. 계획 승인·광고 집행 전입니다.' : '입력 수치·날짜·대상을 확인하세요. 빈 값은 미정이며 0과 다릅니다.';
      }
      function field(name,label,kind,choices) {
        var el, integer = name === 'measurement_lag_days' || name.indexOf('declared_') === 0;
        if (choices) el = h('select',{id:'experiment-'+name,disabled:readOnly,onchange:function () { update(name,this.value || null); if (name === 'method' && editable(ctx,item)) draw(ctx); }},h('option',{value:''},'선택 · 미정'),Object.keys(choices).map(function (value) { return h('option',{value:value},choices[value]); }));
        else el = h(kind === 'textarea' ? 'textarea' : 'input',{id:'experiment-'+name,type:kind === 'textarea' ? null : kind || 'number',disabled:readOnly,
          maxlength:kind === 'textarea' ? 1000 : kind === 'text' ? 160 : null,rows:kind === 'textarea' ? 4 : null,step:kind ? null : integer ? 1 : 'any',
          min:kind ? null : name === 'measurement_lag_days' ? 0 : name === 'sample_share' ? 0.1 : integer ? 1 : 1e-12,
          max:kind ? null : name === 'measurement_lag_days' ? 30 : name === 'sample_share' ? 0.9 : name === 'mde_percent' ? 100 : integer ? 1e9 : 1e12,
          oninput:function () {
            var value = kind === 'textarea' ? this.value : this.value === '' ? null : kind ? this.value : Number(this.value);
            update(name,value,!!(this.validity && this.validity.badInput) || !kind && value !== null && (!finite(value) || integer && !Number.isSafeInteger(value)));
          }});
        el.value = p[name] == null ? '' : p[name];
        return h('label',{class:'na-field'},h('span',null,label),el);
      }
      var candidateChoices = {}; bounded(ctx.data.candidates).forEach(function (row,index) { if ((p.method !== EXPLORATORY || row.kind === 'ad') && typeof row.key === 'string' && /^[0-9a-f]{64}$/.test(row.key)) candidateChoices[row.key] = candidateLabel(row,index); });
      ['control_key','treatment_key'].forEach(function (name) { if (p[name] && !candidateChoices[p[name]]) candidateChoices[p[name]] = '이전 판 대상 · 현재 후보 미확인'; });
      var writeLock = locks[key(ctx.account)], blocked = ctx.busy || !!writeLock || !planCurrent(ctx) || ctx.blocked() || failures[key(ctx.account)] || stale(ctx,item);
      return h('section',{class:'na-section'},h('h4',null,current ? '문서 '+env.num(current.protocol_version)+'판 · '+(STATES[current.state] || '상태 미확인') : '새 실험 계획'),
        current && current.state === 'approved' ? h('p',{class:'na-note'},'승인한 문서는 읽기 전용입니다. 조건 변경은 새 실험 계획으로 작성하고 다시 승인합니다.') : null,
        stale(ctx,item) ? h('p',{class:'na-note warn'},'서버에 다른 판이 있습니다. 입력 초안을 보존했으며 이 판으로 저장·승인할 수 없습니다.') : null,
        h('div',{class:'na-field-grid'},field('control_key','대조군 A · 현재 원천 대상',null,candidateChoices),field('treatment_key','비교군 B · 현재 원천 대상',null,candidateChoices)),
        field('single_variable','비교할 한 가지 변수','text'),field('hypothesis','검증할 가설과 소재·랜딩 제안','textarea'),
        h('div',{class:'na-field-grid'},field('goal','비교 지표',null,GOALS),field('method','명시적으로 선택할 설계 방법',null,METHODS)),
        p.method === EXPLORATORY ? h('div',{'data-experiment-method-explanation':''},h('p',{class:'na-note warn'},EXPLORATORY_NOTICE),
          h('p',{class:'hint'},'동일 광고그룹의 같은 유형 소재 두 개를 비교합니다. 실제로 닫힌 연속 28~30일, 시작 전 승인, 고정 종료, 명시한 전환 지연 대기와 표본·운영 최소 기준, 광고비 한도를 확인합니다. 28일은 탐색 정책이며 통계적 보증 기준이 아닙니다.'),
          h('p',{class:'hint'},'조건부 관측 추천은 진단 밴드와 완결된 7일 블록 4개의 상대 차이가 모두 같은 방향으로 사전 기준을 넘을 때만 표시합니다. 밴드와 블록이 기준 안에 있어도 실제 무승부나 동등성을 뜻하지 않습니다. 계획 승인은 읽기 전용 관측 예약을 시작하며 광고 집행이 아닙니다.')) :
          h('p',{class:'hint'},'비율 차이 설계는 독립 Bernoulli 표본·실제 무작위 배정·고정 기간을 가정한 조건부 계산입니다. 현재 노출·클릭 집계는 고유 사용자나 배정 원장이 아니며 표본 수 충족만으로 승자를 정하지 않습니다.'),
        h('div',{class:'na-field-grid'},field('period_start','계획 시작일','date'),field('period_end','계획 종료일','date'),field('measurement_lag_days','전환 지연 대기(일)')),
        h('div',{class:'na-field-grid'},field('sample_share','대조군 표본 비중(0.1~0.9)'),field('mde_percent',p.method === EXPLORATORY ? '사전 실질차이 기준 · ±상대 % 밴드' : '최소 의미 차이 · 기준 비율 대비 상대 %'),field('declared_control_sample','선언할 대조군 표본 수'),field('declared_treatment_sample','선언할 비교군 표본 수')),
        p.method === EXPLORATORY ? h('p',{class:'hint'},'실질차이 기준은 담당자가 직접 정합니다. 필요 표본·검정력 계산이나 통계적으로 검증된 동등성 한계가 아닙니다. 관측한 일수와 노출·클릭 등의 선언 표본은 서로 구분합니다. CTR은 노출·클릭, 일반 CVR은 클릭·일반 전환, CPA는 광고비·일반 전환, ROAS는 광고비·일반 전환가치가 필요하며 모든 비교에서 광고비와 클릭 및 승인 운영 최소 기준을 확인합니다.') : null,
        h('p',{class:'hint'},'표본 비중과 예산 비중은 다릅니다. 수치와 기간을 자동으로 채우지 않으며, 빈 값은 미정입니다. 0일은 명시적으로 선택한 전환 지연 대기 없음입니다.'),
        h('div',{class:'na-field-grid'},field('experiment_spend_cap','실험 전체 광고비 상한(원)'),field('control_daily_cap','대조군 하루 광고비 상한(원)'),field('treatment_daily_cap','비교군 하루 광고비 상한(원)')),
        h('p',{class:'hint'},'현재 승인 운영계획의 하루·월·기간·위험 지출 한도 안에서 검증합니다. 관측 광고비는 VAT 포함이며 잔액·순손실·미래 집행을 뜻하지 않습니다. 전환 정의·가치 기준은 승인한 운영계획에서 확인합니다.'),
        h('p',{class:'na-note','data-experiment-draft':'','aria-live':'polite'},writeLock ? writeLock.state === 'saved' ? '입력은 보존되어 있으며 최신 저장판 확인을 기다립니다.' : '요청 결과를 확인 중이며 입력은 보존되어 있습니다.' : item.dirty ? '저장하지 않은 입력 초안입니다. 계획 승인·광고 집행 전입니다.' : '저장한 문서입니다. 승인과 실제 광고 집행을 구분합니다.'),
        h('div',{class:'na-actions'},h('button',{type:'button',class:'btn primary','data-experiment-save':'',disabled:readOnly || !item.dirty || !valid(item),onclick:function () { mutate(ctx,'save'); }},'A/B 계획 초안 저장'),
          h('button',{type:'button',class:'btn','data-experiment-approve':'',disabled:blocked || !current || current.state !== 'draft' || item.dirty || ctx.data.can_approve !== true,onclick:function () { mutate(ctx,'approve'); }},'검토 후 A/B 계획 승인'),
          h('button',{type:'button',class:'btn','data-experiment-collect':'',disabled:blocked || !current || current.state !== 'approved' || item.dirty || ctx.data.can_collect !== true,onclick:function () { mutate(ctx,'collect_request'); }},'승인 기간의 관측 수집 요청'),
          h('button',{type:'button',class:'btn',disabled:ctx.busy || locked(ctx.account),onclick:function () { if (!active(ctx) || ctx.busy || locked(ctx.account)) return; delete drafts[key(ctx.account)]; ctx.message = ''; draw(ctx); }},'실험 입력 초안 버리기')));
    }
    function codes(value) { return bounded(value,30).map(function (code) { return h('li',null,REASONS[code] || '추가 조건 확인이 필요합니다. 최신 계획·원천을 재대조하세요.'); }); }
    function decisionShape(value,protocol) {
      if (!plain(value) || Object.keys(value).sort().join('|') !== DECISION_FIELDS.slice().sort().join('|') || value.version !== 1 || value.method !== EXPLORATORY || protocol.method !== EXPLORATORY ||
          value.evidence_grade !== 'exploratory' || !Object.prototype.hasOwnProperty.call(DECISIONS,value.decision) || value.winner !== null || value.causal_claim !== false || value.randomized !== false ||
          value.formal_equivalence !== false || value.calibration_verified !== false || value.calibration !== 'unvalidated_diagnostic' || value.bandwidth !== 7 || value.band_multiplier !== 3 || typeof value.preregistered !== 'boolean') return false;
      if (!['effect_percent','margin_percent','standard_error_percent'].every(function (field) { return value[field] === null || finite(value[field]) && Math.abs(value[field]) <= Number.MAX_SAFE_INTEGER; }) ||
          value.margin_percent !== null && (value.margin_percent <= 0 || value.margin_percent > 100 || value.margin_percent !== protocol.mde_percent) || value.standard_error_percent !== null && value.standard_error_percent < 0 ||
          !Number.isSafeInteger(value.paired_days) || value.paired_days < 0 || value.paired_days > 30 || !Number.isSafeInteger(value.complete_week_blocks) || value.complete_week_blocks < 0 || value.complete_week_blocks > 4 ||
          !Number.isSafeInteger(value.remainder_days) || value.remainder_days < 0 || value.remainder_days > 2 ||
          !Array.isArray(value.reason_codes) || value.reason_codes.length > DIAGNOSTIC_REASONS.length || new Set(value.reason_codes).size !== value.reason_codes.length || value.reason_codes.some(function (code) { return DIAGNOSTIC_REASONS.indexOf(code) < 0; }) ||
          !Array.isArray(value.qualifiers) || value.qualifiers.length > 6 || new Set(value.qualifiers).size !== value.qualifiers.length || value.qualifiers.some(function (code) { return !Object.prototype.hasOwnProperty.call(QUALIFIERS,code); }) ||
          ['exploratory_policy_not_calibrated','observed_settings_not_full_history','no_random_assignment'].some(function (code) { return value.qualifiers.indexOf(code) < 0; })) return false;
      if (value.band !== null && (!plain(value.band) || Object.keys(value.band).sort().join('|') !== 'lower_percent|upper_percent' || !finite(value.band.lower_percent) || !finite(value.band.upper_percent) || Math.abs(value.band.lower_percent) > Number.MAX_SAFE_INTEGER || Math.abs(value.band.upper_percent) > Number.MAX_SAFE_INTEGER || value.band.lower_percent > value.band.upper_percent)) return false;
      if (value.decision === 'conditional_preference' ? value.recommended_arm !== 'control' && value.recommended_arm !== 'treatment' : value.recommended_arm !== null) return false;
      return value.decision === 'hold' || value.preregistered === true && value.paired_days >= 28 && value.complete_week_blocks === 4 && value.remainder_days === value.paired_days-28 &&
        finite(value.effect_percent) && finite(value.margin_percent) && finite(value.standard_error_percent) && value.standard_error_percent > 0 && value.band !== null &&
        (value.decision !== 'conditional_preference' || (value.recommended_arm === 'treatment' ? value.band.lower_percent > value.margin_percent : value.band.upper_percent < -value.margin_percent)) &&
        (value.decision !== 'within_material_margin' || value.band.lower_percent > -value.margin_percent && value.band.upper_percent < value.margin_percent);
    }
    function exploratoryView(ctx,current,result,usable,rawCurrent,observation) {
      var item = draft(ctx), value = usable && !(item && (item.dirty || stale(ctx,item))) && result.observational_decision;
      var rows = dailyRows(current,observation,rawCurrent);
      var ready = decisionShape(value,current.protocol) && (value.decision === 'hold' || current.state === 'approved' && rows && rows.length === value.paired_days && stabilityShape(observation.stability,current.protocol) && observation.stability.coverage_complete && !observation.stability.drift);
      if (!ready) return h('section',{class:'na-section','data-experiment-exploratory-result':''},h('h4',null,'탐색적 관측 판정 · 현재 확인 보류'),
        h('p',{class:'na-note warn'},EXPLORATORY_NOTICE),h('p',{class:'hint'},'현재 원천·저장판의 탐색적 진단을 확인하지 못했습니다. 이전 추천과 진단 밴드를 현재 판단에 사용하지 않습니다.'));
      return h('section',{class:'na-section','data-experiment-exploratory-result':''},h('h4',null,DECISIONS[value.decision]),
        h('p',{class:'na-note warn','data-experiment-evidence-grade':''},EXPLORATORY_NOTICE),
        h('p',{class:'na-note'},value.decision === 'conditional_preference' ? '조건부 관측 추천 대상: '+(value.recommended_arm === 'control' ? '대조군 A' : '비교군 B')+' · 담당자 검토 자료이며 실제 집행·09 자동 변경의 직접 트리거가 아닙니다.' : value.decision === 'within_material_margin' ? '사전에 정한 관측 기준 안의 차이입니다. 실제 무승부나 통계적 동등성을 입증하지 않습니다.' : '판정에 필요한 관측 일수·사전 승인·측정 대기·설정 관측·표본·지출 조건과 주간 일관성을 확인하세요.'),
        h('table',{class:'na-checklist'},h('tbody',null,[['개선 방향을 맞춘 상대 차이',number(value.effect_percent,'%')],['사전 실질차이 밴드',finite(value.margin_percent) ? '±'+number(value.margin_percent,'%') : '미확인'],
          ['비교정 진단 밴드',value.band ? '['+number(value.band.lower_percent,'%')+', '+number(value.band.upper_percent,'%')+']' : '미확인'],['일별 짝 관측 HAC 표준오차',number(value.standard_error_percent,'%')],
          ['완결된 양군 날짜 쌍',number(value.paired_days,'일')],['완결 7일 블록',number(value.complete_week_blocks,'개')],['전체 계산에 포함한 잔여일',number(value.remainder_days,'일')]].map(function (row) { return h('tr',null,h('th',{scope:'row'},row[0]),h('td',null,row[1])); }))),
        h('p',{class:'hint'},'상대 차이는 % 단위이며 %p가 아닙니다. CPA는 감소, CTR·일반 CVR·ROAS는 증가 방향을 개선으로 맞춥니다. 진단 계수 '+number(value.band_multiplier)+' · 자기상관 조정 지연 '+number(value.bandwidth,'일')+' · 사전 승인 '+(value.preregistered ? '확인' : '미확인')),
        h('ul',{class:'hint'},codes(value.reason_codes),value.qualifiers.map(function (code) { return h('li',null,QUALIFIERS[code]); })));
    }
    function stabilityShape(value,protocol) {
      if (!plain(value) || Object.keys(value).sort().join('|') !== STABILITY_FIELDS.slice().sort().join('|') || value.qualifier !== 'observed_stability' || !day(protocol.period_start) || !day(protocol.period_end) ||
          !Array.isArray(value.expected_days) || value.expected_days.length < 28 || value.expected_days.length > 30 || typeof value.drift !== 'boolean' || typeof value.coverage_complete !== 'boolean' ||
          !Array.isArray(value.observed_days) || !Array.isArray(value.missing_days) ||
          ['expected_days','observed_days','missing_days'].some(function (field) { var days = value[field]; return new Set(days).size !== days.length || days.some(function (at,index) { return !day(at) || at < protocol.period_start || at > protocol.period_end || index && days[index-1] >= at; }); }) ||
          value.expected_days.length !== (Date.parse(protocol.period_end)-Date.parse(protocol.period_start))/86400000+1 ||
          value.expected_days.some(function (at,index) { return Date.parse(at) !== Date.parse(protocol.period_start)+index*86400000; }) ||
          value.observed_days.some(function (at) { return value.expected_days.indexOf(at) < 0; }) ||
          JSON.stringify(value.missing_days) !== JSON.stringify(value.expected_days.filter(function (at) { return value.observed_days.indexOf(at) < 0; })) ||
          value.coverage_complete !== (!value.missing_days.length && !value.drift) ||
          !Array.isArray(value.limitations) || value.limitations.join('|') !== 'intraday_changes_unobserved|unobserved_fields_unknown' ||
          ['first_checked_at','last_checked_at'].some(function (at) { return value[at] !== null && (typeof value[at] !== 'string' || value[at].length > 64 || !finite(Date.parse(value[at]))); })) return false;
      return value.observed_days.length ? value.first_checked_at !== null && value.last_checked_at !== null && Date.parse(value.first_checked_at) <= Date.parse(value.last_checked_at) : value.first_checked_at === null && value.last_checked_at === null;
    }
    function stabilityView(ctx,current,observation,rawCurrent) {
      var allowed = planCurrent(ctx) && !failures[key(ctx.account)] && !locked(ctx.account) && ['source_wait','queued','reading','ok','partial'].indexOf(current.collection_status) >= 0;
      var value = allowed && current.observed_stability;
      if (!stabilityShape(value,current.protocol)) value = allowed && rawCurrent && observation.stability;
      if (!stabilityShape(value,current.protocol)) return h('section',{class:'na-section','data-experiment-observed-stability':''},h('h4',null,'기간 중 설정 관측 · 현재 확인 보류'),h('p',{class:'hint'},'현재 판의 일별 설정 관측 진척을 확인하지 못했습니다. 지금 조회한 설정으로 과거 날짜를 채우지 않습니다.'));
      return h('section',{class:'na-section','data-experiment-observed-stability':''},h('h4',null,'기간 중 설정 관측 · 전체 이력 보증 아님'),
        h('p',{class:'na-note'},'관련 설정 관측 '+number(value.observed_days.length,'일')+' / 계획 '+number(value.expected_days.length,'일')+' · '+(value.drift ? '관련 설정 변경 감지 · 비교 보류' : '확인한 관측점에서 변경 미감지')),
        h('p',{class:'hint'},'관측 날짜 '+(value.missing_days.length ? '미완결' : '전체 확인')+' · 최초 '+env.datedTime(value.first_checked_at)+' · 최신 '+env.datedTime(value.last_checked_at)),
        h('p',{class:'hint'},'조회 사이의 변경과 수집하지 않은 설정 필드는 미확인입니다. 날짜별 관측 확인은 기간 전체 설정 불변을 보증하지 않으며, 앞으로 올 날짜도 미관측 날짜에 포함됩니다.'),
        value.missing_days.length ? h('details',null,h('summary',null,'미관측 날짜 '+number(value.missing_days.length,'일')),h('p',{class:'hint'},value.missing_days.join(' · '))) : null);
    }
    function dailyRows(current,observation,rawCurrent) {
      var rows = rawCurrent && observation.version === 2 && observation.daily;
      if (!Array.isArray(rows) || rows.length > 30 || new Set(rows.map(function (row) { return row && row.day; })).size !== rows.length || rows.some(function (row) {
        return !plain(row) || !day(row.day) || row.day < current.protocol.period_start || row.day > current.protocol.period_end || ['control','treatment'].some(function (side) {
          var arm = row[side]; return !plain(arm) || !plain(arm.fields) || Object.keys(METRICS).some(function (field) { return arm.fields[field] !== null && (!finite(arm.fields[field]) || arm.fields[field] < 0); });
        });
      })) return null;
      return rows;
    }
    function dailyView(current,observation,rawCurrent) {
      var rows = dailyRows(current,observation,rawCurrent);
      if (!rows) return null;
      return h('details',{class:'na-section','data-experiment-daily-observations':''},h('summary',null,'양군 일별 원천 수치 '+number(rows.length,'일')+' · 비율 재계산 없음'),h('p',{class:'hint'},'미확인은 0과 구분합니다. 목표와 무관한 수치의 누락만으로 목표 비교를 취소하지 않으며 필요한 지표·운영 최소 기준의 완결 여부는 서버에서 검증합니다.'),
        h('div',{class:'table-wrap'},h('table',{class:'na-checklist'},h('thead',null,h('tr',null,['날짜','대상'].concat(Object.keys(METRICS).map(function (field) { return METRICS[field]; })).map(function (label) { return h('th',null,label); }))),h('tbody',null,rows.map(function (row) {
          return ['control','treatment'].map(function (side) { return h('tr',null,h('th',{scope:'row'},row.day),h('td',null,side === 'control' ? '대조군 A' : '비교군 B'),Object.keys(METRICS).map(function (field) { return h('td',null,number(row[side].fields[field])); })); });
        })))));
    }
    function planningView(ctx,planning) {
      if (draft(ctx) && draft(ctx).protocol.method !== ((head(ctx) || {}).protocol || {}).method) return h('section',{class:'na-section'},h('h4',null,'설계 방법 변경 · 새 계산 대기'),h('p',{class:'hint'},'변경한 방법을 초안으로 저장한 뒤 최신 서버 계획을 확인하세요. 이전 방법의 계산을 새 계획에 사용하지 않습니다.'));
      if (!plain(planning) || !planCurrent(ctx) || failures[key(ctx.account)] || locked(ctx.account)) return h('section',{class:'na-section'},h('h4',null,'조건부 계획 계산'),h('p',{class:'na-note'},'최신 서버 계획 계산을 아직 확인하지 못했습니다. 이전 계산을 승인 근거로 대신 사용하지 않습니다.'));
      if (planning.method === EXPLORATORY) return h('section',{class:'na-section','data-experiment-exploratory-plan':''},h('h4',null,'탐색적 관측 계획 · 미래 성과 보장 아님'),
        h('p',{class:'na-note warn'},EXPLORATORY_NOTICE),
        h('p',{class:'hint'},'승인 기간 '+text((head(ctx) || {}).protocol && head(ctx).protocol.period_start || '미정')+' ~ '+text((head(ctx) || {}).protocol && head(ctx).protocol.period_end || '미정')+' · 후보 원천 기준 기간 '+text((ctx.data.source || {}).period_start || '미확인')+' ~ '+text((ctx.data.source || {}).period_end || '미확인')),
        h('p',{class:'hint'},'연속한 실제 닫힌 날짜 28~30일과 기간 중 관련 설정 관측이 필요합니다. 과거 후보 원천은 미래의 노출·단가·일수 완결·표본·성과를 보장하지 않으며 현재 조회로 과거 설정 관측을 소급해서 채우지 않습니다.'),
        bounded(planning.missing,20).length ? h('p',{class:'na-note'},'미입력: '+bounded(planning.missing,20).map(function (name) { return FIELD_LABELS[name] || '추가 입력'; }).join(' · ')) : null,
        h('ul',{class:'hint'},codes(planning.reason_codes)));
      return h('section',{class:'na-section'},h('h4',null,'조건부 계획 계산 · 미래 성과 보장 아님'),
        h('p',{class:'na-note'},planning.state === 'conditional' ? '선택한 수학 가정 아래 계산 가능 · 실제 배정·집행 효과 미입증' : planning.state === 'observation_only' ? '관측 비교 계획 · 통계적 승자 판정 없음' : '계획 계산 보류 · 입력·원천·한도를 확인하세요.'),
        h('p',{class:'hint'},METHODS[planning.method] || '설계 방법 미정',finite(planning.alpha) && finite(planning.power) ? ' · 양측 유의수준 '+number(planning.alpha*100,'%')+' / 검정력 '+number(planning.power*100,'%') : ''),
        h('table',{class:'na-checklist'},h('tbody',null,[['대조군 기준 CTR',finite(planning.baseline_rate) ? number(planning.baseline_rate*100,'%') : '미확인'],['가정한 비교군 CTR',finite(planning.alternative_rate) ? number(planning.alternative_rate*100,'%') : '미확인'],['조건부 필요 대조군 표본',number(planning.required_control_sample,'회')],['조건부 필요 비교군 표본',number(planning.required_treatment_sample,'회')],['양군 과거 노출 속도·하루 상한을 가정한 예상 기간',number(planning.estimated_days,'일')],['대조군 과거 노출당 광고비를 가정한 예상 비용',number(planning.estimated_control_spend,'원(VAT 포함)')],['비교군 과거 노출당 광고비를 가정한 예상 비용',number(planning.estimated_treatment_spend,'원(VAT 포함)')],['양군의 조건부 예상 광고비 합계',number(planning.estimated_spend,'원(VAT 포함)')]].map(function (row) { return h('tr',null,h('th',{scope:'row'},row[0]),h('td',null,row[1])); }))),
        bounded(planning.missing,20).length ? h('p',{class:'na-note'},'미입력: '+bounded(planning.missing,20).map(function (name) { return FIELD_LABELS[name] || '추가 입력'; }).join(' · ')) : null,
        h('ul',{class:'hint'},codes(planning.reason_codes)),
        h('p',{class:'hint'},'기간·비용은 선언 표본과 필요 표본 중 큰 수를 기준으로 계산합니다. 과거 기간 전체의 설정 동일성·예산 VAT 정합성은 미확인입니다. 필요 표본·예상 기간·광고비는 조건부 설계 추정이며 실제 노출·단가·집행·성과·잔액을 보장하지 않습니다.'));
    }
    function resultView(ctx,current) {
      var result = current.result, trusted = plain(result) && planCurrent(ctx) && result.winner === null && result.causal_claim === false && result.execution_enabled === false && !failures[key(ctx.account)] && !locked(ctx.account);
      var usable = trusted && (current.collection_status === 'ok' || current.collection_status === 'partial');
      var observation = usable && current.observations, rawCurrent = plain(observation) && (observation.version === 1 || current.protocol.method === EXPLORATORY && observation.version === 2) && observation.configuration_verified === true &&
        (observation.status === 'ok' || observation.status === 'partial') && observation.status === current.collection_status && observation.period_start === current.protocol.period_start && observation.period_end === current.protocol.period_end;
      var collection = {unavailable:'수집 전',queued:'수집 요청 대기',reading:'수집 중',ok:'원천 관측 수집 완료',partial:'부분 수집',retry:'재시도 대기',source_wait:'원천 재대조 대기',limited:'조회 제한',reauth_required:'계정 권한 확인 필요',superseded:'승인·원천 판 변경으로 보류'};
      function arm(side,label) {
        var row = usable && result.arms && result.arms[side], raw = rawCurrent && observation.arms && observation.arms[side], fields = row && row.fields || raw && raw.fields || {}, ratios = row && row.metrics || {};
        return h('tr',null,h('th',{scope:'row'},label,raw ? h('p',{class:'hint'},raw.complete === true ? '원천 수치 완결' : '현재 부분 응답 · 비교 판정 보류',h('br'),env.datedTime(raw.source_at)) : null),Object.keys(METRICS).map(function (name) { return h('td',null,number(fields[name])); }),
          ['ctr','cpc','cvr','cpa','roas'].map(function (name) { return h('td',null,number(ratios[name],name === 'ctr' || name === 'cvr' || name === 'roas' ? '%' : '원')); }));
      }
      var differences = usable && result.outcome === 'observation' && result.differences, unit = result && (result.goal === 'ctr' || result.goal === 'cvr' || result.goal === 'roas') ? '%p' : '원';
      return h('section',{class:'na-section'},h('h4',null,'실제 원천 관측 · A/B 효과 확정 아님'),
        h('p',{class:'na-note'},usable && result.outcome === 'observation' ? '같은 기간에 수집한 두 대상의 수치를 관측 비교합니다. 승자 없음 · 인과 효과 미입증' : '현재 비교 판단 보류 · 미확인을 0으로 채우지 않습니다.'),
        h('p',{class:'hint'},'수집 상태: '+(collection[current.collection_status] || '상태 미확인')+' · 관측 저장 시각 '+env.datedTime(usable ? result.checked_at : null)+' · 최신 재확인 '+env.datedTime(current.last_checked_at)+' · 기간 '+text(current.protocol.period_start || '미정')+' ~ '+text(current.protocol.period_end || '미정')),
        result ? h('p',{class:'hint'},'지표 역할: '+(result.metric_role === 'primary' ? '승인 운영계획의 주 지표' : result.metric_role === 'proxy' ? '운영 목표의 보조 지표 · 주 지표 승자로 해석하지 않음' : '미확인')+' · '+(GOALS[result.goal] || '지표 미정')) : null,
        h('div',{class:'table-wrap'},h('table',{class:'na-checklist'},h('thead',null,h('tr',null,['대상'].concat(Object.keys(METRICS).map(function (name) { return METRICS[name]; }),['CTR','CPC','일반 전환 CVR','일반 전환 CPA','일반 전환가치 ROAS']).map(function (label) { return h('th',null,label); }))),h('tbody',null,arm('control','대조군 A'),arm('treatment','비교군 B')))),
        differences ? h('p',{class:'hint'},'관측 지표 차이(B−A): '+number(differences.absolute,unit)+' · 상대 변화 '+number(differences.relative_percent,'%')+' · 인과 효과·승자·유의성 아님') : null,
        current.protocol.method === EXPLORATORY ? exploratoryView(ctx,current,result || {},usable,rawCurrent,observation) : null,
        current.protocol.method === EXPLORATORY ? stabilityView(ctx,current,observation,rawCurrent) : null,
        current.protocol.method === EXPLORATORY ? dailyView(current,observation,rawCurrent) : null,
        usable && result.stopped_for_spend === true ? h('p',{class:'na-note warn'},'관측 광고비가 실험 상한에 도달했습니다. 실제 광고 중단은 실행되지 않았습니다. 담당자가 집행 설정을 확인해야 합니다.') : null,
        h('ul',{class:'hint'},reasons(current.hold_reasons),trusted ? codes(result.reason_codes) : null),
        h('p',{class:'hint'},'수집 전후의 현재 설정 확인은 과거 비교 기간 전체의 설정 불변을 입증하지 않습니다. 기간 중 설정 변경 이력과 실제 배정 원장은 미확인입니다.'),
        h('p',{class:'hint'},'전환은 플랫폼 일반 전환 집계입니다. 실제 주문·고유 구매자·구매 퍼널·태그 정상·최종 귀속을 확인한 자료가 아닙니다. 이벤트 비율은 100%를 넘을 수 있으며 CPA·ROAS 합계만으로 통계적 승자를 정하지 않습니다.'),
        current.approved_at ? h('p',{class:'na-plan-meta'},'계획 승인 '+env.datedTime(current.approved_at)+' · 관측 요청 '+env.datedTime(current.requested_at)+' · 광고 실행 미연결') : null);
    }
    function render(data,account,guard,blocked,onChange,parentPlanVersion) {
      if (!account || !identity(data,account) || typeof guard !== 'function' || typeof blocked !== 'function') { suspend(); return h('p',{class:'na-note'},'이 계정의 원천 연결 A/B 자료를 확인하지 못했습니다. 기존 수동 학습 자산은 데이터 학습 자산에서 확인할 수 있습니다.'); }
      var id = key(account);
      var incoming = inputs[id] !== data; if (incoming) { inputs[id] = data; cache[id] = data; }
      var ctx = {account:account,data:cache[id],guard:guard,blocked:blocked,onChange:typeof onChange === 'function' ? onChange : function () {},parentPlanVersion:parentPlanVersion,context:env.context(),session:session,busy:!!locks[id] && locks[id].state === 'pending',message:'',mounting:true,root:h('section',{class:'na-section'})}; shown = ctx;
      if (incoming) try { accept(ctx,ctx.data); } catch (error) { failures[id] = true; ctx.message = '저장된 실험 요청의 최신 판을 아직 확인하지 못했습니다. 다시 조회해 주세요.'; }
      draw(ctx); ctx.mounting = false; return ctx.root;
    }
    function suspend() { shown = null; revision++; if (controller) controller.abort(); }
    function reset() { suspend(); session++; drafts = {}; locks = {}; cache = {}; inputs = {}; failures = {}; floors = {}; }
    return {render:render,capability:capability,hasUnsaved:hasUnsaved,locked:locked,suspend:suspend,reset:reset};
  }
  window.NaverExperiments = {create:create,model:{emptyProtocol:emptyProtocol}};
}());
