/* Versioned account evidence. All verdicts come from the server; no advertising writes. */
(function () {
  'use strict';
  var KINDS = {performance:'성과 관측',setting_change:'세팅 변경 기록',experiment:'A/B 실험'};
  var STATES = {draft:'검수 전',reviewed:'검수 완료',rejected:'반려'};
  var OUTCOMES = {observation:'관측 기록 · 인과 미입증',unknown:'판정 보류',invalid:'유효 조건 미충족',inconclusive:'차이 미확정',winner:'통계적 차이 확인'};
  var REASONS = {observed_performance:'성과 관측',planned_change:'변경 계획 · 실제 집행 아님',observed_change:'변경 관측',applied_change:'적용 기록',no_causal_control:'인과 비교 없음',running:'진행 중',stopped:'중단됨',horizon_not_complete:'계획 기간 미완료',not_preregistered:'실험 전 사전 등록 미확인',not_randomized:'무작위 배정 미확인',not_independent:'독립 관측 단위 미확인',independent_units_unknown:'독립 관측 단위 미확인',multiple_variables:'단일 변수 비교 미확인',measurement_incomplete:'집계 미완료',conversion_definition_unknown:'전환 정의 미확인',lag_not_mature:'전환 지연 미반영',allocation_invalid:'배정 유효성 미확인',sample_ratio_mismatch:'표본 비율 불일치',missing_metrics:'필요 수치 미확인',invalid_binary_counts:'비율 분자·분모 오류',goal_requires_variance:'CPA·ROAS 분산 자료 필요',insufficient_sample:'표본 부족',predeclared_sample_below_power:'사전 표본 기준 부족',no_statistical_separation:'통계적 차이 없음',below_mde:'최소 의미 차이 미달',qualified_difference:'계획 조건 내 차이 확인',protocol_changed:'사전 실험 계획 변경'};
  var ENUMS = {
    industry:{food:'식품',pet:'반려동물',home:'생활·주거',beauty:'뷰티',fashion:'패션',local_service:'지역 서비스',b2b:'B2B',other:'기타'},
    goal:{impressions:'노출수',clicks:'클릭수',cpa:'광고 전환 CPA',roas:'광고 전환가치 ROAS',ctr:'클릭률',cvr:'광고 전환율'},
    ad_type:{powerlink:'파워링크',shopping:'쇼핑',brand:'브랜드',place:'플레이스',display:'디스플레이',other:'기타'},
    budget_band:{under_300k:'월 30만원 미만', '300k_1m':'월 30만~100만원 미만','1m_3m':'월 100만~300만원 미만',over_3m:'월 300만원 이상'}
  };
  var METRICS = {impressions:'노출수',clicks:'클릭수',spend:'광고비(원)',conversions:'광고 전환수',conversion_value:'광고 전환가치(원)'};
  var SETTINGS = {goal:'운영 목표',target_value:'목표 값',daily_spend_cap:'하루 지출 상한(원)',absolute_bid_cap:'절대 입찰 상한(원)',experiment_days:'실험 기간(일)',loss_cap:'허용 손실 상한(원)',bid:'입찰가(원)',daily_budget:'일 예산(원)',enabled:'광고 활성 여부'};
  var CONVERSIONS = {unknown:'미확인',platform:'플랫폼 전체 전환',purchase:'구매 완료로 확인',lead:'문의·신청으로 확인'};
  var LESSONS = {collect_more_data:'추가 관측 자료 확보',verify_measurement:'측정 정의·누락 점검',verify_configuration:'실제 설정 재확인',respect_risk_limit:'예산·위험 한도 준수',monitor_execution:'송신·반영 상태 추적',retain_observation:'관측 기록 보존',no_transferable_lesson:'일반화할 교훈 미확인'};
  var CONFOUNDERS = {non_randomized:'무작위 배정 없음',non_independent:'독립 표본 미확인',unequal_delivery:'노출·배분 차이',multiple_changes:'여러 설정 동시 변경',measurement_incomplete:'측정·집계 미완료',lag_pending:'전환 지연 미반영',source_changed:'원천·프로토콜 변경',external_factors_unknown:'외부 요인 미확인'};
  var SOURCE_STATES = {planned:'계획 · 송신 전',approved:'승인 · 반영 전',queued:'자체 큐 대기',dispatched:'송신 · 반영 미확인',accepted:'HTTP 수락 · 반영 미확인',unknown:'송신 결과 미확인',rejected:'거절',cancelled:'자체 큐 취소',stopped:'자체 운영 중단',confirmed:'정확 대상 재조회로 반영 확인',ok:'수치 관측',partial:'부분 관측',pending:'관측 대기',failed:'관측 실패',stale:'현재 원천 재확인 필요',unavailable:'원천 미확인',superseded:'프로토콜 변경 · 이전 원천'};
  var ACTIONS = {create_campaign:'캠페인 생성',create_adgroup:'광고그룹 생성',create_keyword:'키워드 생성',create_text_ad:'소재 생성',update_bid:'입찰가 변경',update_daily_budget:'하루 예산 변경',set_user_lock:'플랫폼 잠금 변경'};
  var MEASUREMENTS = {complete:'기간 수치 완결 · 측정 정확성 별도',partial:'일부 수치 미확인',unavailable:'성과 수치 미확인',not_applicable:'성과 판정 대상 아님'};
  function copy(value) { return JSON.parse(JSON.stringify(value)); }
  function plain(value) { return !!value && typeof value === 'object' && !Array.isArray(value); }
  function exact(value,keys) { return plain(value) && Object.keys(value).sort().join('|') === keys.slice().sort().join('|'); }
  function version(value) { return Number.isSafeInteger(value) && value >= 0; }
  function isAuto(row) { return !!row && (/^auto-(exp|exec)-/.test(row.asset_id || '') || plain(((row.document || {}).source_refs || {}).auto_source)); }
  function validAnnotation(doc) {
    return exact(doc,['metadata','lesson_codes','confounder_codes','private_comment']) && exact(doc.metadata,Object.keys(ENUMS)) && Object.keys(ENUMS).every(function (k) { return doc.metadata[k] === null || Object.prototype.hasOwnProperty.call(ENUMS[k],doc.metadata[k]); }) && [['lesson_codes',LESSONS],['confounder_codes',CONFOUNDERS]].every(function (pair) { var values = doc[pair[0]]; return Array.isArray(values) && values.length <= 6 && new Set(values).size === values.length && values.every(function (k) { return Object.prototype.hasOwnProperty.call(pair[1],k); }); }) && typeof doc.private_comment === 'string' && doc.private_comment.length <= 1000 && !/[<>\x00-\x1f\x7f-\x9f\u202a-\u202e\u2066-\u2069\ud800-\udfff]/.test(doc.private_comment);
  }
  function safeNumber(value, integer) { return typeof value === 'number' && isFinite(value) && value >= 0 && value <= 1e15 && (!integer || Number.isSafeInteger(value)); }
  function localTime(value) {
    if (!value) return ''; var d = new Date(value); if (isNaN(d)) return '';
    function pad(n) { return ('0' + n).slice(-2); }
    return d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate())+'T'+pad(d.getHours())+':'+pad(d.getMinutes());
  }
  function validDay(value) { return typeof value === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(value) && !isNaN(new Date(value)) && new Date(value).toISOString().slice(0,10) === value; }
  function create(env) {
    var h = env.h, put = env.put, drafts = {}, shown = null, busy = false, generation = 0;
    var sourceDrafts = {}, sourceLocks = {}, sourceSelected = {}, sourceFailures = {}, sourceFloors = {};
    function accountKey(account) { return account.possibility_id+'|'+account.account_key; }
    function active(ctx) { return shown === ctx && ctx.generation === generation && ctx.guard() && env.active() && ctx.context === env.context() && (ctx.mounting || !ctx.root || ctx.root.isConnected !== false); }
    function items(ctx) { return ctx.assets.items; }
    function draftFor(ctx) { return drafts[accountKey(ctx.account)]; }
    function rowFor(ctx,id) { return items(ctx).find(function (item) { return item.asset_id === id; }); }
    function stale(ctx,draft) { var row = rowFor(ctx,draft.asset_id); return (row ? row.version : 0) !== draft.baseVersion; }
    function sourceLocked(account) { return !!account && !!sourceLocks[accountKey(account)]; }
    function editable(ctx,draft) { return ctx.canEdit && !busy && !sourceLocked(ctx.account) && !stale(ctx,draft) && !Object.keys(draft.document.source_refs || {}).length; }
    function hasUnsaved() { return Object.keys(drafts).some(function (key) { return drafts[key].dirty; }) || Object.keys(sourceDrafts).some(function (key) { return sourceDrafts[key].dirty; }); }
    if (window.addEventListener) window.addEventListener('beforeunload',function (event) { if (hasUnsaved()) { event.preventDefault(); event.returnValue = ''; } });
    function valid(draft) {
      var doc = draft.document, e = doc.evidence;
      if (!doc.title.trim() || doc.title.length > 160 || Object.keys(draft.invalid).some(function (key) { return draft.invalid[key]; })) return false;
      if (doc.kind !== 'setting_change') {
        if (!validDay(e.period_start) || !validDay(e.period_end) || e.period_start > e.period_end || (new Date(e.period_end)-new Date(e.period_start))/86400000 > 366) return false;
      }
      if (doc.kind === 'experiment' && (!(e.min_sample_per_arm > 0) || !(e.mde_percent >= 0.1 && e.mde_percent <= 100) || !(e.control_share >= 0.1 && e.control_share <= 0.9) || e.baseline_rate !== null && !(e.baseline_rate > 0 && e.baseline_rate < 1))) return false;
      if (doc.kind === 'setting_change' && e.execution !== 'planned' && !e.observed_at) return false;
      return true;
    }
    function capability(body) {
      var ctx = shown; if (!ctx || !active(ctx) || busy || sourceLocked(ctx.account) || !ctx.canEdit || !plain(body) || body.possibility_id !== ctx.account.possibility_id || body.account_key !== ctx.account.account_key) return false;
      if (body.action === 'capture') return Object.keys(body).sort().join('|') === 'account_key|action|possibility_id';
      if (!Number.isSafeInteger(body.expected_version) || !/^[A-Za-z0-9_-]{1,80}$/.test(body.asset_id || '')) return false;
      var draft = draftFor(ctx), row = rowFor(ctx,body.asset_id);
      if (isAuto(row)) return false;
      if (body.action === 'save') return Object.keys(body).sort().join('|') === 'account_key|action|asset_id|document|expected_version|possibility_id' && !!draft && draft.asset_id === body.asset_id && draft.baseVersion === body.expected_version && draft.dirty && editable(ctx,draft) && valid(draft) && JSON.stringify(body.document) === JSON.stringify(draft.document);
      return (body.action === 'review' || body.action === 'reject') && Object.keys(body).sort().join('|') === 'account_key|action|asset_id|expected_version|possibility_id' && !!row && row.state === 'draft' && row.version === body.expected_version && !(draft && draft.asset_id === row.asset_id && draft.dirty);
    }
    function write(ctx,body) {
      if (!active(ctx) || !capability(body)) return;
      var mark = generation, pending = env.api('POST','/automation/learning',body); busy = true; draw(ctx);
      return pending.then(function () {
        if (!active(ctx)) return;
        busy = false;
        if (body.action === 'save') delete drafts[accountKey(ctx.account)];
        env.toast(body.action === 'capture' ? '저장 보고서를 성과 관측 자산으로 연결했습니다.' : body.action === 'review' ? '학습 자산을 검수했습니다. 서버 판정과 한계를 함께 참고합니다.' : body.action === 'reject' ? '학습 자산을 반려했습니다. 기록은 보존됩니다.' : '학습 자산 초안을 저장했습니다. 광고는 변경하지 않았습니다.');
        return ctx.onSaved();
      }).catch(function (error) {
        if (mark !== generation) return;
        busy = false;
        if (env.denied(error)) { env.purge(error); return; }
        if (!active(ctx)) return;
        ctx.message = error && error.status === 409 ? '저장 판이 변경되었습니다. 입력 초안은 보존됩니다. 최신 자료를 확인해 주세요.' : '저장 또는 최신 자료 확인을 완료하지 못했습니다. 입력과 연결 상태를 확인해 주세요.';
        draw(ctx);
      }).then(function () { if (mark === generation) busy = false; });
    }
    function start(ctx,kind,row) {
      if (!active(ctx) || busy || (!row && (!ctx.canEdit || sourceLocked(ctx.account)))) return;
      if (isAuto(row)) { sourceSelected[accountKey(ctx.account)] = row.asset_id; ctx.message = ''; draw(ctx); return; }
      var old = draftFor(ctx); if (old && old.dirty) { ctx.message = '저장하지 않은 초안이 있습니다. 먼저 저장하거나 입력 초안을 버려 주세요.'; draw(ctx); return; }
      if (!row && (!window.crypto || typeof window.crypto.randomUUID !== 'function')) { ctx.message = '안전한 자산 식별자를 만들 수 없습니다. 보안 연결에서 다시 열어 주세요.'; draw(ctx); return; }
      var document = copy(row ? row.document : ctx.assets.templates[kind]);
      drafts[accountKey(ctx.account)] = {asset_id:row ? row.asset_id : 'manual-'+window.crypto.randomUUID(),baseVersion:row ? row.version : 0,document:document,baseline:JSON.stringify(document),dirty:!row,invalid:{}};
      ctx.message = ''; draw(ctx);
    }
    function sourceRow(ctx) { var lock = sourceLocks[accountKey(ctx.account)]; return rowFor(ctx,lock ? lock.body.asset_id : sourceSelected[accountKey(ctx.account)]); }
    function sourceShape(row) { var a = row && row.source_annotation; return isAuto(row) && version(row.version) && row.version > 0 && plain(a) && version(a.version) && validAnnotation(a.document) && ['empty','draft','reviewed','rejected'].indexOf(a.state) >= 0 && typeof a.current === 'boolean'; }
    function sourceDraft(ctx,row) {
      if (!sourceShape(row)) return null; var k = accountKey(ctx.account), d = sourceDrafts[k];
      if (!d || !d.dirty && (d.asset_id !== row.asset_id || d.sourceVersion !== row.version || d.annotationVersion !== row.source_annotation.version)) {
        d = sourceDrafts[k] = {asset_id:row.asset_id,sourceVersion:row.version,annotationVersion:row.source_annotation.version,document:copy(row.source_annotation.document),baseline:JSON.stringify(row.source_annotation.document),dirty:false};
      }
      return d;
    }
    function sourceStale(row,d,ctx) { return !sourceShape(row) || !d || d.asset_id !== row.asset_id || d.sourceVersion !== row.version || d.annotationVersion !== row.source_annotation.version || ctx && row.version < (sourceFloors[accountKey(ctx.account)+'|'+row.asset_id] || 0); }
    function sourceEditable(ctx,row,d) { return active(ctx) && ctx.canEdit && !busy && !ctx.sourceReading && !sourceLocked(ctx.account) && !sourceFailures[accountKey(ctx.account)] && !sourceStale(row,d,ctx) && row.source_annotation.can_edit === true; }
    function sourceCapability(body) {
      var ctx = shown, keys = ['possibility_id','account_key','asset_id','expected_source_version','expected_annotation_version','request_id','action'];
      if (!ctx || !active(ctx) || !ctx.canEdit || busy || ctx.sourceReading || !plain(body) || body.possibility_id !== ctx.account.possibility_id || body.account_key !== ctx.account.account_key || !/^[0-9a-f]{32}$/.test(body.request_id || '') || !version(body.expected_source_version) || !version(body.expected_annotation_version) || ['save','review','reject'].indexOf(body.action) < 0) return false;
      if (body.action === 'save') keys.push('document'); if (!exact(body,keys)) return false;
      var row = rowFor(ctx,body.asset_id), lock = sourceLocks[accountKey(ctx.account)], d = sourceDrafts[accountKey(ctx.account)];
      if (lock) return lock.state === 'unknown' && JSON.stringify(lock.body) === JSON.stringify(body);
      if (!sourceShape(row) || row.version < (sourceFloors[accountKey(ctx.account)+'|'+row.asset_id] || 0) || sourceFailures[accountKey(ctx.account)] || row.version !== body.expected_source_version || row.source_annotation.version !== body.expected_annotation_version) return false;
      if (body.action === 'save') return !!d && d.dirty && sourceEditable(ctx,row,d) && validAnnotation(d.document) && JSON.stringify(body.document) === JSON.stringify(d.document);
      return !(d && d.asset_id === row.asset_id && d.dirty) && row.source_annotation[body.action === 'review' ? 'can_review' : 'can_reject'] === true;
    }
    function receiptValid(receipt,body) { return exact(receipt,['asset_id','source_version','annotation_version','request_id']) && receipt.asset_id === body.asset_id && receipt.request_id === body.request_id && version(receipt.source_version) && receipt.source_version > body.expected_source_version && version(receipt.annotation_version) && receipt.annotation_version > body.expected_annotation_version; }
    function sourceMessage(lock) { return lock.state === 'pending' ? '주석·검수 요청을 처리 중입니다. 추가 학습 자산 쓰기를 보류합니다.' : lock.state === 'saved' ? '요청은 서버에서 확인됐습니다. 최신 원천·주석 판 확인을 기다립니다. 입력은 보존합니다.' : '처리 결과가 미확인입니다. 같은 요청의 영수증을 확인하기 전까지 새 요청을 만들지 않습니다.'; }
    function sourceRefresh(ctx) {
      var row = sourceRow(ctx), k = accountKey(ctx.account), lock = sourceLocks[k]; if (!active(ctx) || ctx.sourceReading || lock && lock.state === 'pending' || !row) return Promise.resolve();
      var mark = generation; ctx.sourceReading = true; draw(ctx);
      var path = '/automation/learning/source?possibility_id='+ctx.account.possibility_id+'&account_key='+encodeURIComponent(ctx.account.account_key)+'&asset_id='+encodeURIComponent(row.asset_id)+(lock && lock.state === 'unknown' ? '&request_id='+lock.body.request_id : '');
      return env.api('GET',path).then(function (data) {
        if (!active(ctx) || mark !== generation) return;
        if (!plain(data) || !exact(data.selection,['possibility_id','account_key']) || data.selection.possibility_id !== ctx.account.possibility_id || data.selection.account_key !== ctx.account.account_key || !sourceShape(data.item) || data.item.asset_id !== row.asset_id) throw new Error('source-identity');
        var current = data.item, floor = sourceFloors[k+'|'+row.asset_id] || 0; if (current.version < row.version || current.version < floor || current.source_annotation.version < row.source_annotation.version) throw new Error('source-old-version');
        if (lock) {
          var receipt = lock.state === 'unknown' ? data.recovery_receipt : lock.receipt;
          if (!receiptValid(receipt,lock.body) || current.version < receipt.source_version || current.source_annotation.version < receipt.annotation_version) throw new Error('source-receipt-unconfirmed');
          delete sourceLocks[k]; if (lock.body.action === 'save') delete sourceDrafts[k];
        }
        sourceFloors[k+'|'+row.asset_id] = current.version; var updated = items(ctx).map(function (item) { return item.asset_id === current.asset_id ? current : item; }), counts = {}; Object.keys(STATES).forEach(function (state) { counts[state] = updated.filter(function (item) { return item.state === state; }).length; }); ctx.assets = Object.assign({},ctx.assets,{items:updated,counts:counts});
        delete sourceFailures[k]; ctx.sourceReading = false; ctx.message = ''; draw(ctx);
      }).catch(function (error) {
        if (mark !== generation) return; if (env.denied(error)) { env.purge(error); return; } if (!active(ctx)) return;
        ctx.sourceReading = false; sourceFailures[k] = true; ctx.message = sourceLocks[k] ? sourceMessage(sourceLocks[k]) : '최신 원천·검수 상태를 확인하지 못했습니다. 이전 검색 자격을 현재 상태로 사용하지 않습니다.'; draw(ctx);
      });
    }
    function sourceSubmit(ctx,body) {
      if (!sourceCapability(body)) return; var k = accountKey(ctx.account), old = sourceLocks[k], uncertain = !!old, mark = generation;
      var pending = env.api('POST','/automation/learning/source',body); sourceLocks[k] = {state:'pending',body:copy(body)}; draw(ctx);
      return pending.then(function (receipt) {
        var lock = sourceLocks[k]; if (mark !== generation || !lock || lock.body.request_id !== body.request_id) return;
        if (!receiptValid(receipt,body)) { lock.state = 'unknown'; throw new Error('source-receipt'); } lock.state = 'saved'; lock.receipt = copy(receipt);
        if (shown && accountKey(shown.account) === k && active(shown)) return sourceRefresh(shown);
      }).catch(function (error) {
        var lock = sourceLocks[k]; if (mark !== generation || !lock || lock.body.request_id !== body.request_id) return;
        if (env.denied(error)) { env.purge(error); return; }
        if (lock.state !== 'saved') { if (uncertain || !error || error.status !== 400 && error.status !== 409) lock.state = 'unknown'; else delete sourceLocks[k]; }
        if (!shown || accountKey(shown.account) !== k || !active(shown)) return; shown.message = sourceLocks[k] ? sourceMessage(sourceLocks[k]) : '요청이 거절되었습니다. 기준 판·입력 조건을 확인하세요. 입력 초안은 보존합니다.'; draw(shown);
      });
    }
    function sourceMutate(ctx,row,action) {
      var token = window.crypto && typeof window.crypto.randomUUID === 'function' ? window.crypto.randomUUID().replace(/-/g,'') : null;
      if (!/^[0-9a-f]{32}$/.test(token || '')) { ctx.message = '안전한 요청 식별자를 만들 수 없습니다.'; draw(ctx); return; }
      var body = {possibility_id:ctx.account.possibility_id,account_key:ctx.account.account_key,asset_id:row.asset_id,expected_source_version:row.version,expected_annotation_version:row.source_annotation.version,request_id:token,action:action};
      if (action === 'save') body.document = copy(sourceDrafts[accountKey(ctx.account)].document); return sourceSubmit(ctx,body);
    }
    function sourceEvidence(ctx,row) {
      var e = row.document.evidence || {}, f = e.source_facts || {}, summary = row.source_summary || {}, failed = sourceFailures[accountKey(ctx.account)], lines = [];
      function value(v) { return typeof v === 'boolean' ? v ? '활성' : '중지' : safeNumber(v,false) ? env.num(v) : '미확인'; }
      function exploratory() {
        if (f.method !== 'exploratory_paired_day_hac_v1') return null;
        var d = f.exploratory_diagnostic, labels = {hold:'판단 보류',inconclusive:'방향 불명확',conditional_preference:'조건부 관측 추천',within_material_margin:'사전 관측 기준 안의 차이'};
        function finite(v) { return typeof v === 'number' && Number.isFinite(v) && Math.abs(v) <= Number.MAX_SAFE_INTEGER; }
        function signed(v) { return finite(v) ? env.num(v)+'%' : '미확인'; }
        var current = !failed && row.source_annotation && row.source_annotation.current === true;
        var valid = current && plain(d) && d.version === 1 && d.method === f.method && d.evidence_grade === 'exploratory' &&
          d.calibration === 'unvalidated_diagnostic' && d.calibration_verified === false && d.causal_claim === false &&
          d.formal_equivalence === false && d.randomized === false && d.winner === null && Object.prototype.hasOwnProperty.call(labels,d.decision) &&
          Number.isInteger(d.paired_days) && d.paired_days >= 0 && d.paired_days <= 30 &&
          (d.decision === 'conditional_preference' ? d.recommended_arm === 'control' || d.recommended_arm === 'treatment' : d.recommended_arm === null);
        valid = valid && (d.band === null || plain(d.band) && finite(d.band.lower_percent) && finite(d.band.upper_percent) && d.band.lower_percent <= d.band.upper_percent) &&
          (d.decision === 'hold' || finite(d.effect_percent) && finite(d.margin_percent) && d.margin_percent > 0 && d.paired_days >= 28 && d.complete_week_blocks === 4 && d.remainder_days === d.paired_days-28 && d.band !== null);
        if (!valid) return h('section',{class:'na-section','data-learning-exploratory':''},h('h4',null,'탐색적 관측 · 현재 원천 확인 보류'),h('p',{class:'hint'},'최신 원천과 진단 형식을 확인하기 전에는 과거 추천을 표시하지 않습니다.'));
        return h('section',{class:'na-section','data-learning-exploratory':''},h('h4',null,'탐색적 관측 · '+labels[d.decision]),
          h('p',{class:'na-note'},'비교정·비무작위·비인과 관찰입니다. 정식 승자·무승부·동등성 검정 결과가 아니며 자동 광고 변경을 실행하지 않습니다.'),
          d.decision === 'conditional_preference' ? h('p',null,'관측 추천: '+(d.recommended_arm === 'control' ? '대조군 A' : '비교군 B')+' · 담당자 검토 필요') : null,
          h('p',{class:'hint'},'목표 기준 상대 차이 '+signed(d.effect_percent)+' · 사전 상대 차이 기준 '+signed(d.margin_percent)),
          h('p',{class:'hint'},'진단 밴드 '+signed(d.band && d.band.lower_percent)+' ~ '+signed(d.band && d.band.upper_percent)+' · 신뢰구간 아님'),
          h('p',{class:'hint'},'양군 관측 '+value(d.paired_days)+'일 · 완결 주간 블록 '+value(d.complete_week_blocks)+'개 · 잔여 '+value(d.remainder_days)+'일도 전체 계산에 포함'),
          h('p',{class:'hint'},d.decision === 'hold' ? '사전 승인·기간·설정 관측·측정 지연·표본·광고비 조건을 실험 탭에서 확인하세요.' : '조회 사이 설정 변경과 외부 요인은 모두 확인할 수 없습니다. 이 기록은 과거 사례로만 재사용합니다.'));
      }
      function settingValue(key,v) { return key === 'goal' ? ENUMS.goal[v] || '미확인' : key === 'userLock' ? v === true ? '잠금' : v === false ? '잠금 해제' : '미확인' : value(v); }
      function metrics(name,m) { if (!plain(m)) return h('p',{class:'hint'},name+' 성과 미연결'); var definitions = {unknown:'전환 정의 미확인',platform:'플랫폼 전체 전환',platform_all_conversions:'플랫폼 전체 전환',purchase:'플랫폼 구매 전환 · 실제 결제 주문 별도',lead:'문의·신청 정의'},bases = {unknown:'금액 기준 미확인',platform_conversion_value:'플랫폼 전환가치',paid_order_revenue:'결제 주문 매출 기준',gross_profit:'매출총이익 기준'}; return h('section',{class:'na-section'},h('h4',null,name),h('p',{class:'hint'},'기간 '+(validDay(m.period_start) ? m.period_start : '미확인')+' ~ '+(validDay(m.period_end) ? m.period_end : '미확인')),h('dl',{class:'na-field-grid'},Object.keys(METRICS).map(function (key) { return h('div',null,h('dt',null,METRICS[key]),h('dd',null,value(m[key]))); })),h('p',{class:'hint'},'수치 완결 '+(m.measurement_complete === true ? '확인' : '미확인')+' · 전환 지연 '+(m.lag_mature === true ? '반영' : '미확인')+' · 원천 시각 '+env.datedTime(m.source_at)),h('p',{class:'hint'},(definitions[m.conversion_definition] || '전환 정의 미확인')+' · '+(bases[m.value_basis] || '금액 기준 미확인')+' · 정의 선택은 실제 구매·결제 검증을 뜻하지 않습니다.')); }
      if (failed) return h('p',{class:'na-note warn'},'최신 원천 조회 실패 · 이전 검색 자격과 반영 상태 사용 보류');
      if (summary.kind === 'execution_result') {
        var settings = Object.assign({},SETTINGS,{bidAmt:'입찰가(원)',dailyBudget:'하루 예산(원)',userLock:'플랫폼 잠금'});
        lines.push(h('table',{class:'na-checklist'},h('thead',null,h('tr',null,h('th',null,'설정'),h('th',null,'변경 전 관측'),h('th',null,'의도한 변경'),h('th',null,'재조회 확인 후'))),h('tbody',null,Object.keys(settings).filter(function (key) { return [e.before,f.desired,e.after].some(function (obj) { return plain(obj) && Object.prototype.hasOwnProperty.call(obj,key); }); }).map(function (key) { return h('tr',null,h('th',null,settings[key]),h('td',null,settingValue(key,(e.before || {})[key])),h('td',null,settingValue(key,(f.desired || {})[key])),h('td',null,summary.status === 'confirmed' ? settingValue(key,(e.after || {})[key]) : '반영 미확인')); }))),h('p',{class:'hint'},'송신 '+env.datedTime(f.dispatched_at)+' · 반영 재조회 '+env.datedTime(f.confirmed_at)),metrics('변경 판단에 사용한 성과',f.baseline),metrics('변경 후 별도 관측',f.followup));
      } else {
        lines.push(h('p',{class:'hint'},'관측 기간 '+(validDay(e.period_start) ? e.period_start : '미확인')+' ~ '+(validDay(e.period_end) ? e.period_end : '미확인')),
          h('p',{class:'hint'},'사전 대조군 표본 '+value(f.declared_control_sample)+' · 사전 실험군 표본 '+value(f.declared_treatment_sample)+' · MDE '+value(e.mde_percent)+'% · 계획 대조군 비중 '+value(e.control_share)),
          metrics('대조군 A · 기간 관측',Object.assign({period_start:e.period_start,period_end:e.period_end,source_at:f.source_at,measurement_complete:e.measurement_complete,lag_mature:e.lag_mature,conversion_definition:e.conversion_definition,value_basis:f.value_basis},e.control)),metrics('실험군 B · 기간 관측',Object.assign({period_start:e.period_start,period_end:e.period_end,source_at:f.source_at,measurement_complete:e.measurement_complete,lag_mature:e.lag_mature,conversion_definition:e.conversion_definition,value_basis:f.value_basis},e.treatment)),h('p',{class:'hint'},'사전 등록 '+env.datedTime(e.preregistered_at)+' · 무작위 배정·독립 표본·유효 배분 미입증 · 승자 미확정'));
      }
      return h('section',{class:'na-section'},h('h4',null,'서버 원천 · 수정 불가'),h('p',{class:'na-note'},SOURCE_STATES[summary.status] || '원천 상태 미확인'),h('p',{class:'hint'},(ACTIONS[summary.action] || (summary.kind === 'experiment_observation' ? '두 대상 성과 관측 비교' : '동작 미확인'))+' · '+(MEASUREMENTS[summary.measurement] || '측정 자격 미확인')),lines,exploratory(),h('p',{class:'hint'},'계획·HTTP 수락·자체 중단은 실제 광고 반영 확인과 다릅니다. 전후 수치 차이를 인과 개선이나 성공 공식으로 해석하지 않습니다.'));
    }
    function sourceEditor(ctx,row) {
      if (!sourceShape(row)) return h('p',{class:'na-note warn'},'자동 원천·주석 판을 확인하지 못했습니다. 원천 수동 편집은 허용되지 않습니다.');
      var d = sourceDraft(ctx,row), a = row.source_annotation, locked = !sourceEditable(ctx,row,d), lock = sourceLocks[accountKey(ctx.account)];
      function update(key,value) { if (!sourceEditable(ctx,row,d)) return; d.document[key] = value; d.dirty = JSON.stringify(d.document) !== d.baseline; var button = ctx.root.querySelector('[data-source-save]'); if (button) button.disabled = !d.dirty || !validAnnotation(d.document); ['review','reject'].forEach(function (action) { var el = ctx.root.querySelector('[data-source-'+action+']'); if (el) el.disabled = d.dirty || a[action === 'review' ? 'can_review' : 'can_reject'] !== true; }); var status = ctx.root.querySelector('[data-source-draft]'); if (status) status.textContent = d.dirty ? '미저장 주석입니다. 저장하면 기존 검수를 철회하고 재검수합니다.' : '저장된 주석판입니다.'; }
      function codes(key,choices,title) { return h('fieldset',null,h('legend',null,title+' · 최대 6개'),Object.keys(choices).map(function (code) { return h('label',{class:'na-field'},h('input',{type:'checkbox',id:'learning-source-'+code,checked:d.document[key].indexOf(code) >= 0 ? true : null,disabled:locked,onchange:function () { var v = d.document[key].slice(), at = v.indexOf(code); if (this.checked && at < 0) v.push(code); if (!this.checked && at >= 0) v.splice(at,1); update(key,v); }}),choices[code]); })); }
      var comment = h('textarea',{id:'learning-source-private_comment',rows:3,maxlength:1000,disabled:locked,oninput:function () { update('private_comment',this.value); }}); comment.value = d.document.private_comment;
      return h('article',{class:'na-section'},h('h3',null,'자동 원천과 담당자 주석'),h('p',null,row.document.title || '자동 수집 기록'),h('p',{class:'hint'},'자산 '+env.num(row.version)+'판 · 원천 '+(version(a.source_revision) ? env.num(a.source_revision) : '미확인')+'판 · 주석 '+env.num(a.version)+'판 · '+(a.state === 'empty' ? '미분류 · 미검수' : STATES[a.state] || '검수 미확인')),
        sourceStale(row,d,ctx) ? h('p',{class:'na-note warn'},'원천 또는 주석에 새 판이 있습니다. 입력은 보존하지만 이 기준으로 저장·검수할 수 없습니다.') : null,
        lock ? h('p',{class:'na-note warn','aria-live':'polite'},sourceMessage(lock)) : null,sourceEvidence(ctx,row),
        h('p',{class:'na-note'},sourceFailures[accountKey(ctx.account)] ? '현재 AI 검색 자격 미확인' : a.current === true ? '현재 원천 참조 확인 · AI 사용은 검수·정의·검색 조건도 확인합니다.' : '현재 원천 참조 재확인 필요 · 과거 원장은 보존합니다.'),
        h('ul',{class:'hint'},(Array.isArray(a.hold_reasons) ? a.hold_reasons.slice(0,20) : []).map(function (r) { return h('li',null,plain(r) && typeof r.message === 'string' ? r.message.slice(0,1000) : '현재 검색·검수 조건을 확인하세요.',plain(r) && r.next_action ? h('p',null,String(r.next_action).slice(0,1000)) : null); })),
        h('div',{class:'na-field-grid'},Object.keys(ENUMS).map(function (key) { var el = h('select',{id:'learning-source-'+key,disabled:locked,onchange:function () { var metadata = copy(d.document.metadata); metadata[key] = this.value || null; update('metadata',metadata); }},h('option',{value:''},'미확인 · 미분류'),Object.keys(ENUMS[key]).map(function (code) { return h('option',{value:code},ENUMS[key][code]); })); el.value = d.document.metadata[key] || ''; return label({industry:'업종',goal:'운영 목표',ad_type:'광고 유형',budget_band:'월 예산 구간'}[key],el); })),
        codes('lesson_codes',LESSONS,'기록에서 확인할 교훈'),codes('confounder_codes',CONFOUNDERS,'혼란 요인·해석 한계'),
        label('내부 검수 코멘트 · AI에 전송하지 않음',comment),
        h('p',{'data-source-draft':'',class:'hint'},lock && lock.state === 'saved' ? '입력은 보존되어 있으며 최신 저장판 확인을 기다립니다.' : d.dirty ? '미저장 주석입니다. 저장하면 기존 검수를 철회하고 재검수합니다.' : '저장된 주석판입니다.'),
        h('div',{class:'na-actions'},h('button',{type:'button',class:'btn primary','data-source-save':'',disabled:locked || !d.dirty || !validAnnotation(d.document),onclick:function () { sourceMutate(ctx,row,'save'); }},'분류·주석 초안 저장'),['review','reject'].map(function (action) { var attrs = {type:'button',class:'btn',disabled:sourceLocked(ctx.account) || busy || ctx.sourceReading || !ctx.canEdit || sourceFailures[accountKey(ctx.account)] || sourceStale(row,d,ctx) || d.dirty || a[action === 'review' ? 'can_review' : 'can_reject'] !== true,onclick:function () { sourceMutate(ctx,row,action); }}; attrs['data-source-'+action] = ''; return h('button',attrs,action === 'review' ? '원천·주석 검수 완료' : '자동 자산 반려'); }),
          h('button',{type:'button',class:'btn',disabled:ctx.sourceReading || lock && lock.state === 'pending',onclick:function () { sourceRefresh(ctx); }},'최신 원천·영수증 확인'),lock && lock.state === 'unknown' ? h('button',{type:'button',class:'btn',disabled:ctx.sourceReading || !ctx.canEdit,onclick:function () { sourceSubmit(ctx,copy(lock.body)); }},'동일 요청 재확인') : null,
          h('button',{type:'button',class:'btn',disabled:!!lock || ctx.sourceReading,onclick:function () { if (!active(ctx) || sourceLocked(ctx.account)) return; delete sourceDrafts[accountKey(ctx.account)]; draw(ctx); }},'주석 입력 버리기')));
    }
    function label(text,control) { return h('label',{class:'na-field'},h('span',null,text),control); }
    function editor(ctx,draft) {
      var doc = draft.document, evidence = doc.evidence, locked = !editable(ctx,draft), id = 'learning-'+draft.asset_id+'-';
      function change(path,value,error) {
        if (!active(ctx) || !editable(ctx,draft)) return;
        var target = doc; path.slice(0,-1).forEach(function (key) { target = target[key]; }); target[path[path.length-1]] = value;
        draft.invalid[path.join('.')] = !!error;
        draft.dirty = JSON.stringify(doc) !== draft.baseline || draft.baseVersion === 0 || Object.keys(draft.invalid).some(function (key) { return draft.invalid[key]; });
        var save = ctx.root.querySelector('[data-learning-save]'); if (save) save.disabled = !draft.dirty || !valid(draft) || !editable(ctx,draft);
        var status = ctx.root.querySelector('[data-learning-draft]'); if (status) status.textContent = draft.dirty ? '저장되지 않은 입력 초안입니다. 검수·실제 집행 전입니다.' : '저장된 자산을 보고 있습니다.';
      }
      function select(path,text,choices,nullable) {
        var value = doc; path.forEach(function (key) { value = value[key]; });
        var el = h('select',{id:id+path.join('-'),disabled:locked,onchange:function () { change(path,this.value || null); }},nullable ? h('option',{value:''},'미확인 · 미분류') : null,Object.keys(choices).map(function (key) { return h('option',{value:key},choices[key]); })); el.value = value == null ? '' : value; return label(text,el);
      }
      function input(path,text,kind,integer) {
        var value = doc; path.forEach(function (key) { value = value[key]; });
        var el = h('input',{id:id+path.join('-'),type:kind || 'number',step:integer ? 1 : 'any',min:kind ? null : 0,max:kind ? null : 1e15,maxlength:kind === 'text' ? 160 : null,disabled:locked,oninput:function () {
          var parsed = this.value === '' ? null : this.value, invalid = false;
          if (!kind) { parsed = this.value === '' ? null : Number(this.value); invalid = !!(this.validity && this.validity.badInput) || parsed !== null && !safeNumber(parsed,integer); }
          if (kind === 'datetime-local' && parsed) { var date = new Date(parsed); invalid = isNaN(date); parsed = invalid ? null : date.toISOString(); }
          change(path,kind === 'text' && parsed === null ? '' : parsed,invalid);
        }}); el.value = kind === 'datetime-local' ? localTime(value) : value == null ? '' : value; return label(text,el);
      }
      function check(path,text) {
        var value = doc; path.forEach(function (key) { value = value[key]; });
        var el = h('input',{type:'checkbox',disabled:locked,onchange:function () { change(path,this.checked); }}); el.checked = value === true;
        return h('label',null,el,' ',text);
      }
      function metrics(prefix) { return h('div',{class:'na-field-grid'},Object.keys(METRICS).map(function (key) { return input(prefix.concat(key),METRICS[key],null,['impressions','clicks','conversions'].indexOf(key) !== -1); })); }
      var fields = [input(['title'],'기록 이름','text'),h('div',{class:'na-field-grid'},Object.keys(ENUMS).map(function (key) { return select(['metadata',key],{industry:'업종',goal:'운영 목표',ad_type:'광고 유형',budget_band:'월 예산 구간'}[key],ENUMS[key],true); }))];
      if (doc.kind !== 'setting_change') fields.push(h('div',{class:'na-field-grid'},input(['evidence','period_start'],'관측 시작일','date'),input(['evidence','period_end'],'관측 종료일','date')));
      if (doc.kind === 'performance') fields.push(metrics(['evidence']));
      if (doc.kind === 'experiment') {
        fields.push(h('p',{class:'hint'},'실험 시작 전에 계획을 등록합니다. 과거 결과를 사후 입력하면 사전 등록된 실험으로 인정되지 않습니다. 실험 표본과 지출은 실제 관측값을 입력하세요.'),
          h('div',{class:'na-field-grid'},select(['evidence','status'],'실험 상태',{running:'진행 중',completed:'종료',stopped:'중단'}),select(['evidence','goal'],'1차 판정 지표',{ctr:'클릭률',cvr:'광고 전환율',cpa:'광고 전환 CPA',roas:'광고 전환가치 ROAS'}),
            input(['evidence','min_sample_per_arm'],'사전 최소 표본 수 · 각 군',null,true),input(['evidence','baseline_rate'],'사전 기준 비율(0~1)'),input(['evidence','mde_percent'],'최소 의미 차이(상대 %)'),input(['evidence','control_share'],'계획 대조군 비중(0.1~0.9)'),input(['evidence','preregistered_at'],'사전 계획 시각 · 브라우저 현지 시각','datetime-local')),
          h('fieldset',null,h('legend',null,'대조군 A · 실제 성과'),metrics(['evidence','control'])),h('fieldset',null,h('legend',null,'실험군 B · 실제 성과'),metrics(['evidence','treatment'])),
          h('div',{class:'na-actions'},check(['evidence','randomized'],'무작위 배정을 확인함'),check(['evidence','independent_units'],'독립 관측 단위 확인'),check(['evidence','one_variable'],'한 가지 변수만 비교함'),check(['evidence','allocation_valid'],'계획에 따른 배정과 집행을 확인함')));
      }
      if (doc.kind !== 'setting_change') fields.push(h('div',{class:'na-field-grid'},select(['evidence','conversion_definition'],'전환의 실제 의미',CONVERSIONS)),h('div',{class:'na-actions'},check(['evidence','measurement_complete'],'필요 기간의 집계 완결 확인'),check(['evidence','lag_mature'],'전환 지연 반영 완료 확인')));
      if (doc.kind === 'setting_change') {
        fields.push(h('p',{class:'hint'},'변경 제안과 실제 적용을 구분합니다. 실제 설정을 관측한 시각과 변경 전후 값을 기록하세요. 계획 저장 이력은 실제 네이버 광고 적용의 증거가 아닙니다.'),
          h('div',{class:'na-field-grid'},select(['evidence','execution'],'기록 종류',{planned:'변경 계획',observed:'설정 관측',applied:'적용 기록'}),select(['evidence','changed_variable'],'주요 변경 변수',Object.assign({multiple:'여러 변수 · 단일 변수 비교 아님'},SETTINGS)),input(['evidence','observed_at'],'관측 시각 · 브라우저 현지 시각','datetime-local')));
        Object.keys(SETTINGS).forEach(function (key) {
          var selected = Object.prototype.hasOwnProperty.call(evidence.before,key) || Object.prototype.hasOwnProperty.call(evidence.after,key);
          var toggle = h('input',{type:'checkbox',disabled:locked,onchange:function () {
            if (!active(ctx) || !editable(ctx,draft)) return;
            if (this.checked) { evidence.before[key] = null; evidence.after[key] = null; } else { delete evidence.before[key]; delete evidence.after[key]; }
            draft.dirty = JSON.stringify(doc) !== draft.baseline || draft.baseVersion === 0; draw(ctx);
          }}); toggle.checked = selected;
          var values = selected ? h('div',{class:'na-field-grid'},['before','after'].map(function (side) {
            if (key === 'goal') return select(['evidence',side,key],side === 'before' ? '변경 전' : '변경 후',ENUMS.goal,true);
            if (key === 'enabled') {
              var el = h('select',{disabled:locked,onchange:function () { change(['evidence',side,key],this.value === '' ? null : this.value === 'true'); }},h('option',{value:''},'미확인'),h('option',{value:'true'},'활성'),h('option',{value:'false'},'중지')); el.value = evidence[side][key] == null ? '' : String(evidence[side][key]); return label(side === 'before' ? '변경 전' : '변경 후',el);
            }
            return input(['evidence',side,key],side === 'before' ? '변경 전' : '변경 후',null,key === 'experiment_days');
          })) : null;
          fields.push(h('fieldset',null,h('legend',null,h('label',null,toggle,' ',SETTINGS[key])),values));
        });
      }
      var readonly = Object.keys(doc.source_refs || {}).length > 0;
      return h('article',{class:'na-section'},h('h3',null,KINDS[doc.kind]+' · '+(draft.baseVersion ? env.num(draft.baseVersion)+'판' : '새 자산')),
        stale(ctx,draft) ? h('p',{class:'na-note warn'},'서버에 새 판이 있습니다. 입력 초안을 보존했으며 이 판으로는 저장할 수 없습니다.') : null,
        readonly ? h('p',{class:'na-note'},'보고서·계획에서 연결한 원천 기록입니다. 원본 수치를 수정하지 않고 검수 또는 반려할 수 있습니다.') : null,
        fields,h('p',{class:'hint'},'빈 수치는 미확인으로 저장됩니다. 실제 0건·0원인 경우 0을 입력하세요. 구매 완료가 확인되지 않은 전환을 구매로 표시하지 마세요.'),
        h('p',{'data-learning-draft':'',class:'na-note','aria-live':'polite'},draft.dirty ? '저장하지 않은 입력 초안입니다. 검수·실제 집행 전입니다.' : '저장된 자산을 보고 있습니다.'),
        h('div',{class:'na-actions'},h('button',{type:'button',class:'btn primary','data-learning-save':'',disabled:!editable(ctx,draft) || !draft.dirty || !valid(draft),onclick:function () {
          write(ctx,{possibility_id:ctx.account.possibility_id,account_key:ctx.account.account_key,action:'save',asset_id:draft.asset_id,expected_version:draft.baseVersion,document:copy(doc)});
        }},'자산 초안 저장'),h('button',{type:'button',class:'btn',disabled:busy,onclick:function () { if (!active(ctx) || busy) return; delete drafts[accountKey(ctx.account)]; ctx.message = ''; draw(ctx); }},'입력 초안 닫기·버리기')));
    }
    function draw(ctx) {
      if (shown !== ctx) return;
      var draft = draftFor(ctx), counts = ctx.assets.counts || {}, retrieval = ctx.assets.retrieval || {}, source = sourceRow(ctx), sourceLock = sourceLocks[accountKey(ctx.account)];
      put(ctx.root,h('h3',null,'광고 성과·실험 자산'),h('p',{class:'hint'},ctx.assets.provenance_notice || '관측과 담당자 검수 기록을 구분합니다. 검수만으로 인과관계가 입증되지는 않습니다.'),
        h('div',{class:'na-actions'},Object.keys(STATES).map(function (state) { return h('span',{class:'pill p-gray'},STATES[state]+' '+env.num(counts[state])); })),
        h('p',{class:'hint'},'표시 중 '+env.num(items(ctx).length)+'건(최대 100건) 기준 집계 · 현재 권한으로 조회한 익명 전략 참조 사례 '+env.num((retrieval.cases || []).length)+'건(최대 5건).'),
        plain(ctx.assets.auto_source_capture) ? h('p',{class:'na-note'},'자동 원천 편입 대기 '+(version(ctx.assets.auto_source_capture.pending) ? env.num(ctx.assets.auto_source_capture.pending) : '미확인')+'건 · 재시도 종료 '+(version(ctx.assets.auto_source_capture.exhausted) ? env.num(ctx.assets.auto_source_capture.exhausted) : '미확인')+'건. 편입 실패는 실제 광고 반영·성과 수집 실패와 별도입니다.') : null,
        ctx.message && !sourceLock ? h('p',{class:'na-note warn','aria-live':'polite'},ctx.message) : null,
        !ctx.canEdit ? h('p',{class:'na-note'},'현재 권한·계약 단계에서는 기록을 읽을 수 있습니다. 자산 저장·검수는 허용되지 않습니다.') : null,
        sourceLock && !source ? h('p',{class:'na-note warn'},sourceMessage(sourceLock)) : null,
        h('div',{class:'na-actions'},Object.keys(KINDS).map(function (kind) { return h('button',{type:'button',class:'btn',disabled:busy || sourceLocked(ctx.account) || !ctx.canEdit,onclick:function () { start(ctx,kind); }},KINDS[kind]+' 등록'); }),
          h('button',{type:'button',class:'btn',disabled:busy || sourceLocked(ctx.account) || !ctx.canEdit,onclick:function () { write(ctx,{possibility_id:ctx.account.possibility_id,account_key:ctx.account.account_key,action:'capture'}); }},'최신 저장 보고서 편입'),
          h('button',{type:'button',class:'btn',disabled:busy,onclick:function () { if (active(ctx) && !busy) ctx.onSaved(); }},'최신 자료 확인')),
        source ? sourceEditor(ctx,source) : null,draft ? editor(ctx,draft) : null,
        items(ctx).length ? h('div',{class:'table-wrap'},h('table',{class:'na-checklist'},h('thead',null,h('tr',null,h('th',null,'기록'),h('th',null,'상태·판정'),h('th',null,'검수와 이력'))),h('tbody',null,items(ctx).map(function (item) {
          var assessment = item.assessment || {}, refs = item.document.source_refs || {}, dirty = draft && draft.asset_id === item.asset_id && draft.dirty;
          return h('tr',null,h('td',null,h('strong',null,item.document.title || '이름 없는 기록'),h('p',{class:'hint'},KINDS[item.document.kind]+' · '+env.num(item.version)+'판'),h('p',{class:'hint'},isAuto(item) ? '서버 자동 원천 · 증거 불변' : refs.report_id ? '보고서 '+env.num(refs.report_id)+' 원천' : refs.plan_version ? '운영 계획 '+env.num(refs.plan_version)+'판 원천' : '담당자 수동 기록')),
            h('td',null,h('p',null,STATES[item.state] || '상태 미확인'),h('p',null,OUTCOMES[assessment.outcome] || '판정 미확인'),assessment.winner ? h('p',{class:'hint'},'우수군: '+(assessment.winner === 'control' ? '대조군 A' : '실험군 B')) : null,
              isAuto(item) ? h('p',{class:'hint'},sourceFailures[accountKey(ctx.account)] ? '최신 원천 조회 실패 · 이전 상태 사용 보류' : SOURCE_STATES[(item.source_summary || {}).status] || '원천 상태 미확인') : null,
              h('ul',{class:'hint'},(assessment.reason_codes || []).map(function (reason) { return h('li',null,REASONS[reason] || '추가 조건 확인 필요'); }))),
            h('td',null,h('p',{class:'hint'},'기록 '+env.datedTime((item.author || {}).at)),item.reviewed_at ? h('p',{class:'hint'},'검수 '+env.datedTime(item.reviewed_at)) : null,
              h('div',{class:'na-actions'},h('button',{type:'button',class:'btn sm',disabled:busy,onclick:function () { start(ctx,item.document.kind,item); }},'상세 보기'),
                isAuto(item) ? null : ['review','reject'].map(function (action) { return h('button',{type:'button',class:'btn sm',disabled:busy || sourceLocked(ctx.account) || !ctx.canEdit || item.state !== 'draft' || dirty,onclick:function () { write(ctx,{possibility_id:ctx.account.possibility_id,account_key:ctx.account.account_key,action:action,asset_id:item.asset_id,expected_version:item.version}); }},action === 'review' ? '검수 완료' : '반려'); }))));
        })))) : h('p',{class:'na-note'},'저장된 학습 자산이 없습니다. 기존 보고서를 편입하거나 성과·세팅·실험 기록을 등록해 주세요.'));
    }
    function render(assets,account,canEdit,guard,onSaved) {
      if (!assets || assets.version !== 1 || !Array.isArray(assets.items) || !plain(assets.templates) || !account || typeof guard !== 'function' || typeof onSaved !== 'function') return h('p',{class:'na-note'},'학습 자산 자료를 확인하지 못했습니다.');
      var ctx = {assets:assets,account:account,canEdit:canEdit === true,guard:guard,onSaved:onSaved,context:env.context(),generation:generation,message:'',mounting:true,root:h('section',{class:'na-section'})}; shown = ctx; draw(ctx); ctx.mounting = false; return ctx.root;
    }
    function suspend() { shown = null; }
    function reset() { generation++; drafts = {}; shown = null; busy = false; sourceDrafts = {}; sourceLocks = {}; sourceSelected = {}; sourceFailures = {}; sourceFloors = {}; }
    return {render:render,capability:capability,sourceCapability:sourceCapability,locked:sourceLocked,hasUnsaved:hasUnsaved,suspend:suspend,reset:reset};
  }
  window.NaverLearningAssets = {create:create,model:{validAnnotation:validAnnotation}};
})();
