/* Account-scoped, explicitly approved AI draft schedules. Never sends reports or changes ads. */
(function () {
  'use strict';
  var STATES={empty:'예약 꺼짐',draft:'예약 초안 · 승인 전',approved:'예약 승인',disabled:'예약 중지'};
  var JOBS={waiting:'생성 시각 대기',source_wait:'집계·원천 확인 대기',queued:'생성 큐 대기',reserved:'생성 준비 · 호출 전',provider_started:'Claude 생성 호출 시도 · 결과 대기',response_received:'Claude 응답 수신 · 문안 검증 중',draft_saved:'검토용 초안 저장',failed:'생성 실패',unknown:'호출 결과 미확인',source_changed:'참조 자료 변경 · 저장 보류',cancelled:'예약 취소',skipped:'지난 자동 생성 회차 건너뜀'};
  var DIAGNOSTICS={'source-wait':'최신 보고 기간의 수치·전환 집계 또는 재검증을 기다립니다.','source-changed':'호출 당시와 현재 참조 자료가 달라 초안 저장을 보류했습니다.','context-changed':'현재 권한·담당·예약판·참조 자료를 다시 확인해야 합니다.','strategy-exists':'해당 기간에 기존 전략판이 있어 자동 덮어쓰기를 건너뛰었습니다.','resumed_backlog':'서버 재개 시 최신 회차를 우선하며 지난 회차의 유료 자동 생성을 건너뛰었습니다.','manual_generation_available':'지난 회차는 보고서 화면에서 필요할 때 직접 생성할 수 있습니다.','provider-unavailable':'Claude 공급자 설정이 확인되지 않았습니다.','worker-unavailable':'호출 전 작업이 중단됐습니다. 결과 확인 후 직접 재시도할 수 있습니다.','timeout':'제한 시간 안에 생성 결과를 확인하지 못했습니다.','network':'생성 요청의 통신 결과를 확인하지 못했습니다.','job-interrupted':'서버 종료·재시작으로 작업이 중단됐습니다.','delegation-changed':'예약 위임이 변경돼 실행 또는 저장을 보류했습니다.','authority-changed':'현재 담당 권한이 변경돼 실행 또는 저장을 보류했습니다.','document-invalid':'수신 문안이 보고서 검증을 통과하지 못했습니다.','cancelled':'예약이 꺼져 대기 작업을 취소했습니다.'};
  function copy(x){return JSON.parse(JSON.stringify(x));}
  function plain(x){return !!x&&typeof x==='object'&&!Array.isArray(x);}
  function exact(x,keys){return plain(x)&&Object.keys(x).sort().join('|')===keys.slice().sort().join('|');}
  function version(x){return Number.isSafeInteger(x)&&x>=0;}
  function token(x){return typeof x==='string'&&/^[0-9a-f]{32}$/.test(x);}
  function documentValid(x){return exact(x,['weekly','monthly'])&&typeof x.weekly==='boolean'&&typeof x.monthly==='boolean';}
  function accountValid(x){return plain(x)&&Number.isSafeInteger(x.possibility_id)&&x.possibility_id>0&&typeof x.account_key==='string'&&/^[0-9a-f]{64}$/.test(x.account_key);}
  function same(a,b){return a&&b&&a.possibility_id===b.possibility_id&&a.account_key===b.account_key;}
  function projectionValid(x,account){return plain(x)&&same(x.selection,account)&&plain(x.schedule)&&version(x.schedule.version)&&Object.prototype.hasOwnProperty.call(STATES,x.schedule.state)&&documentValid(x.schedule.document)&&['current','can_edit','can_approve','can_disable'].every(function(k){return typeof x.schedule[k]==='boolean';})&&Array.isArray(x.schedule.hold_reasons)&&Array.isArray(x.jobs)&&x.jobs.length<=100&&x.jobs.every(function(j){return plain(j)&&token(j.job_id)&&version(j.version)&&j.version>0&&Object.prototype.hasOwnProperty.call(JOBS,j.state)&&typeof j.period_key==='string'&&typeof j.can_retry==='boolean';});}
  function create(env){
    var h=env.h,put=env.put,shown=null,epoch=0,cache={},drafts={},locks={},floors={};
    function key(a){return a.possibility_id+'|'+a.account_key;}
    function current(c){return shown===c&&c.epoch===epoch&&c.context===env.context()&&env.active()&&c.guard()&&(c.mounting||!c.root||c.root.isConnected!==false);}
    function dirty(c){var d=drafts[key(c.account)];return !!d&&d.dirty;}
    function draft(c){var k=key(c.account),d=drafts[k],s=c.data&&c.data.schedule;if(!s)return null;if(!d||!d.dirty&&(d.version!==s.version)){d=drafts[k]={version:s.version,document:copy(s.document),baseline:JSON.stringify(s.document),dirty:false};}return d;}
    function hasUnsaved(){return Object.keys(drafts).some(function(k){return drafts[k].dirty;});}
    function busy(c){return !!locks[key(c.account)]||c.reading||c.failed;}
    function editable(c){var s=c.data&&c.data.schedule,d=draft(c);return current(c)&&s&&s.current&&s.can_edit&&!busy(c)&&d&&d.version===s.version;}
    function capability(body){
      var c=shown;if(!c||!current(c)||!plain(body)||!same(body,c.account)||!token(body.request_id)||!c.data||c.reading)return false;
      var lock=locks[key(c.account)];if(lock)return lock.state==='unknown'&&JSON.stringify(body)===JSON.stringify(lock.body);
      if(c.failed)return false;var s=c.data.schedule,d=draft(c),names=['possibility_id','account_key','expected_version','request_id','action'];
      if(body.action==='retry'){
        var j=c.data.jobs.find(function(row){return row.job_id===body.job_id;});
        return exact(body,['possibility_id','account_key','job_id','expected_job_version','request_id','action'])&&s.current&&s.can_edit&&!dirty(c)&&!!j&&j.can_retry===true&&j.version===body.expected_job_version;
      }
      if(body.action==='save')names.push('document');if(!exact(body,names)||!version(body.expected_version)||body.expected_version!==s.version||!s.current)return false;
      if(body.action==='save')return editable(c)&&d.dirty&&documentValid(body.document)&&JSON.stringify(body.document)===JSON.stringify(d.document);
      if(dirty(c))return false;
      return body.action==='approve'&&s.can_approve&&s.state==='draft'&&(s.document.weekly||s.document.monthly)||body.action==='disable'&&s.can_disable;
    }
    function receiptValid(r,body){return exact(r,['request_id','schedule_version','job_id','job_version'])&&r.request_id===body.request_id&&version(r.schedule_version)&&(body.action==='retry'?token(r.job_id)&&r.job_id!==body.job_id&&version(r.job_version)&&r.job_version>0:r.job_id===null&&r.job_version===null&&r.schedule_version>body.expected_version);}
    function path(c,request){return '/reports/schedule?possibility_id='+c.account.possibility_id+'&account_key='+encodeURIComponent(c.account.account_key)+(request?'&request_id='+request:'');}
    function read(c){
      var k=key(c.account),lock=locks[k];if(!current(c)||c.reading||lock&&lock.state==='pending')return Promise.resolve();c.reading=true;draw(c);
      return env.api('GET',path(c,lock&&lock.state==='unknown'?lock.body.request_id:null)).then(function(data){
        if(!current(c))return;if(!projectionValid(data,c.account)||data.schedule.version<(floors[k]||0)||c.data&&data.schedule.version<c.data.schedule.version)throw new Error('schedule-unverified');
        if(lock){var receipt=lock.state==='unknown'?data.recovery_receipt:lock.receipt;if(!receiptValid(receipt,lock.body)||data.schedule.version<receipt.schedule_version||lock.body.action==='retry'&&!data.jobs.some(function(j){return j.job_id===receipt.job_id&&j.version>=receipt.job_version;}))throw new Error('schedule-receipt-unverified');delete locks[k];if(lock.body.action==='save')delete drafts[k];floors[k]=Math.max(floors[k]||0,receipt.schedule_version);}
        cache[k]=copy(data);c.data=data;c.failed=false;c.message='';
      }).catch(function(error){
        if(!current(c))return;if(env.denied(error)){env.purge(error);return;}c.failed=true;
        c.message=locks[k]?'요청 결과나 최신 판을 확인하지 못했습니다. 같은 영수증을 확인하기 전 새 요청을 만들지 않습니다.':'최신 예약을 조회하지 못했습니다. 표시 자료는 확인 전 상태이며 추가 변경을 보류합니다.';
      }).then(function(){if(current(c)){c.reading=false;draw(c);}});
    }
    function uuid(){return window.crypto&&typeof window.crypto.randomUUID==='function'?window.crypto.randomUUID().replace(/-/g,''):null;}
    function write(c,action,job){
      if(!current(c))return;var k=key(c.account),old=locks[k],body=old&&old.state==='unknown'?old.body:null;
      if(!body){var id=uuid();if(!id){c.message='안전한 요청 번호를 만들 수 없습니다. 보안 연결에서 확인해 주세요.';draw(c);return;}body={possibility_id:c.account.possibility_id,account_key:c.account.account_key,request_id:id,action:action};if(action==='retry'){body.job_id=job.job_id;body.expected_job_version=job.version;}else{body.expected_version=c.data.schedule.version;if(action==='save')body.document=copy(draft(c).document);}}
      if(!capability(body))return;var lock={body:copy(body),state:'pending',receipt:null};
      var pending=env.api('POST','/reports/schedule',body);locks[k]=lock;draw(c);
      return pending.then(function(receipt){if(locks[k]!==lock)return;if(!receiptValid(receipt,body)){lock.state='unknown';throw new Error('schedule-invalid-receipt');}lock.state='saved';lock.receipt=copy(receipt);floors[k]=Math.max(floors[k]||0,receipt.schedule_version);if(current(c)){c.failed=false;return read(c);}}).catch(function(error){
        if(locks[k]!==lock)return;if(env.denied(error)){delete locks[k];env.purge(error);return;}
        if(lock.state==='pending'){if(error&&[400,409,422].indexOf(error.status)>=0){delete locks[k];if(current(c))c.failed=true;}else lock.state='unknown';}
        if(current(c)){c.message=locks[k]?'요청 응답이 불명확합니다. 입력을 보존하며 최신 판·동일 요청 영수증 확인을 기다립니다.':'예약판 또는 요청 조건이 변경됐습니다. 입력을 보존했으며 최신 자료 확인이 필요합니다.';draw(c);}
      });
    }
    function periodText(value){var m=/^(weekly|monthly):(\d{4}-\d{2}-\d{2}):(\d{4}-\d{2}-\d{2})$/.exec(value);return m?(m[1]==='weekly'?'주간':'월간')+' · '+m[2]+' ~ '+m[3]:'기간 미확인';}
    function draw(c){
      if(!current(c))return;var data=c.data,s=data&&data.schedule,d=draft(c),k=key(c.account),lock=locks[k],isBusy=busy(c),canEdit=editable(c);
      var fields=s?h('div',{class:'nr-schedule-fields'},['weekly','monthly'].map(function(kind){return h('label',null,h('input',{type:'checkbox','data-schedule-kind':kind,checked:d.document[kind],disabled:!canEdit,onchange:function(event){if(!editable(c))return;d.document[kind]=!!event.target.checked;d.dirty=JSON.stringify(d.document)!==d.baseline;draw(c);}}),kind==='weekly'?'주간 · 다음 월요일 10시':'월간 · 다음달 3일 10시');})):null;
      var jobs=data&&data.jobs.length?h('table',{class:'nr-schedule-jobs'},h('thead',null,h('tr',null,h('th',null,'보고 기간'),h('th',null,'생성 상태'),h('th',null,'처리 시각·다음 행동'))),h('tbody',null,data.jobs.map(function(j){return h('tr',null,h('td',null,periodText(j.period_key)),h('td',null,JOBS[j.state],j.state==='unknown'?h('p',{class:'nr-notice'},'유료 호출이 처리됐을 수 있습니다. 자동 재호출하지 않습니다.'):null,j.diagnostic?h('p',{class:'hint'},typeof j.diagnostic==='string'?j.diagnostic:typeof j.diagnostic.message==='string'?j.diagnostic.message:DIAGNOSTICS[j.diagnostic.code]||'생성 오류의 원천·권한·공급자 상태를 확인해 주세요.'):null),h('td',null,h('p',{class:'hint'},'갱신 '+env.datedTime(j.updated_at)),j.provider_started_at?h('p',{class:'hint'},'생성 호출 시도 '+env.datedTime(j.provider_started_at)):null,j.response_received_at?h('p',{class:'hint'},'응답 수신 '+env.datedTime(j.response_received_at)):null,j.result_version?h('p',null,'저장 초안 '+j.result_version+'판 · 담당자 검토 필요'):null,j.can_retry?h('button',{type:'button',class:'btn sm',disabled:!s.current||!s.can_edit||isBusy||dirty(c),onclick:function(){write(c,'retry',j);}},j.state==='unknown'?'유료 중복 가능성 확인 후 다시 생성':'실패 내용 확인 후 다시 생성'):null));}))):h('p',{class:'hint'},'이 계정에 표시할 예약 작업이 없습니다. 승인 후 닫히는 보고 기간부터 대상이 됩니다.');
      put(c.root,h('h3',null,'AI 보고서 예약 생성'),h('p',{class:'hint'},'주간·월간 수치 집계와 현재 참조 자료를 확인한 뒤 Claude 검토용 초안을 만듭니다. 공유·발송·광고 변경은 담당자 승인 절차를 유지합니다.'),
        s?h('p',null,STATES[s.state]+' · 예약 '+s.version+'판'+(s.approved_at?' · 승인 '+env.datedTime(s.approved_at):'')):h('p',null,c.reading?'예약 정보를 확인하고 있습니다.':'예약 정보 확인이 필요합니다.'),
        lock?h('p',{class:'nr-notice'},lock.state==='pending'?'요청 처리 중 · 추가 변경 보류':lock.state==='saved'?'서버 요청은 확인했습니다. 최신 예약판 재조회를 기다립니다.':'처리 결과 미확인 · 동일 요청 영수증을 확인하기 전 추가 변경 보류'):null,
        c.message?h('p',{class:'nr-notice',role:'status'},c.message):null,
        s&&!s.current?h('p',{class:'nr-notice'},'현재 권한·관리 단계·예약 위임을 다시 확인해야 합니다.'):null,
        s&&s.hold_reasons.length?h('ul',null,s.hold_reasons.map(function(r){return h('li',null,r.message||'예약 조건 확인 필요');})):null,
        fields,d&&d.dirty?h('p',{class:'hint'},'미저장 예약입니다. 저장 후 별도로 승인해야 가동합니다.'):null,
        h('div',{class:'nr-strategy-editor-actions'},h('button',{type:'button',class:'btn',disabled:!s||!canEdit||!d.dirty,onclick:function(){write(c,'save');}},'예약 초안 저장'),h('button',{type:'button',class:'btn primary',disabled:!s||isBusy||dirty(c)||!s.current||!s.can_approve||s.state!=='draft'||!(s.document.weekly||s.document.monthly),onclick:function(){write(c,'approve');}},'이 계정 예약 승인'),h('button',{type:'button',class:'btn',disabled:!s||isBusy||dirty(c)||!s.current||!s.can_disable,onclick:function(){write(c,'disable');}},'예약 끄기'),h('button',{type:'button',class:'btn',disabled:c.reading||lock&&lock.state==='pending',onclick:function(){read(c);}},'최신 예약·영수증 확인'),lock&&lock.state==='unknown'?h('button',{type:'button',class:'btn',disabled:c.reading,onclick:function(){write(c,lock.body.action);}},'같은 요청만 재확인'):null,d&&d.dirty?h('button',{type:'button',class:'btn',disabled:!!lock,onclick:function(){if(!current(c)||locks[k])return;delete drafts[k];draw(c);}},'예약 입력 버리기'):null),
        h('p',{class:'hint'},'기존 Claude 키를 사용합니다. 별도 API 월 비용 상한은 설정하지 않으며, 승인한 예약의 실제 사용량은 운영 기록에서 확인합니다. 예약 시작 전 기간의 일괄 유료 생성은 하지 않습니다.'),jobs);
    }
    return {mount:function(account,guard){var root=h('section',{class:'nr-report-schedule','data-private':'true'});if(!accountValid(account))return root;var c={account:copy(account),guard:guard,context:env.context(),epoch:epoch,root:root,mounting:true,reading:false,failed:false,data:cache[key(account)]?copy(cache[key(account)]):null,message:''};shown=c;draw(c);read(c);c.mounting=false;return root;},capability:capability,hasUnsaved:hasUnsaved,reset:function(){epoch++;shown=null;cache={};drafts={};locks={};floors={};}};
  }
  window.NaverReportSchedule={create:create,projectionValid:projectionValid};
}());
