#!/usr/bin/env python3
"""Apply/rollback a pinned LearningCenter-only static patch. No service or DB calls."""
import argparse,contextlib,fcntl,hashlib,json,os,pathlib,re,tempfile
PACKAGE=pathlib.Path(__file__).resolve().parent

def digest(blob): return hashlib.sha256(blob).hexdigest()
def load(path,expected):
    if path.is_symlink() or not path.is_file(): raise RuntimeError('required regular file missing')
    blob=path.read_bytes()
    if digest(blob)!=expected: raise RuntimeError('pinned file checksum mismatch')
    return blob

def segments(blob):
    matches=list(re.finditer(rb'\n;/\* ===== (.+?) ===== \*/\n',blob))
    keys=[m.group(1).decode() for m in matches]
    if len(set(keys))!=len(keys): raise RuntimeError('duplicate runtime boundary')
    return keys,{m.group(1).decode():blob[m.end():matches[i+1].start() if i+1<len(matches) else len(blob)] for i,m in enumerate(matches)}

def package_files():
    m=json.loads((PACKAGE/'manifest.json').read_text())
    for name in ('old_bundle','new_bundle'):
        if not re.fullmatch(r'app\.[0-9a-f]{12}\.js',m[name]): raise RuntimeError('invalid bundle path')
        if m[name][4:16]!=m[name+'_sha256'][:12]: raise RuntimeError('content hash filename mismatch')
    old=load(PACKAGE/m['old_bundle'],m['old_bundle_sha256'])
    new=load(PACKAGE/m['new_bundle'],m['new_bundle_sha256'])
    original=load(PACKAGE/'original-index.html',m['old_index_sha256'])
    index=load(PACKAGE/'index.html',m['new_index_sha256'])
    names,a=segments(old); names2,b=segments(new)
    if names!=names2 or len(names)!=77 or [n for n in names if a[n]!=b[n]]!=['js/components/LearningCenterPage.jsx']:
        raise RuntimeError('patch must change exactly LearningCenterPage')
    if index!=original.replace(m['old_bundle'].encode(),m['new_bundle'].encode()):
        raise RuntimeError('index patch has unrelated changes')
    if original.count(m['old_bundle'].encode())!=1: raise RuntimeError('index must have one pinned bundle reference')
    return m,old,new,original,index

def atomic_write(path,blob,mode=0o644):
    if path.is_symlink(): raise RuntimeError('symlink target refused')
    fd,tmp=tempfile.mkstemp(prefix='.learning-static-',dir=path.parent)
    try:
        with os.fdopen(fd,'wb') as stream:
            stream.write(blob); stream.flush(); os.fsync(stream.fileno())
        os.chmod(tmp,mode); os.replace(tmp,path)
        fd=os.open(path.parent,os.O_RDONLY)
        try: os.fsync(fd)
        finally: os.close(fd)
    finally:
        if os.path.exists(tmp): os.unlink(tmp)

def verify_root(root):
    if not root.is_absolute() or root.is_symlink() or not root.is_dir(): raise RuntimeError('absolute existing regular root required')
    if (root/'dist').is_symlink() or not (root/'dist').is_dir(): raise RuntimeError('regular dist directory required')
    if (root/'index.html').is_symlink() or not (root/'index.html').is_file(): raise RuntimeError('regular index required')

def inspect(root,m):
    verify_root(root)
    load(root/'dist'/m['old_bundle'],m['old_bundle_sha256'])
    current=(root/'index.html').read_bytes(); h=digest(current)
    if h==m['old_index_sha256']: return 'original'
    if h==m['new_index_sha256']:
        load(root/'dist'/m['new_bundle'],m['new_bundle_sha256']); return 'installed'
    raise RuntimeError('current index drift; no changes applied')

def run(root,mode):
    root=pathlib.Path(root)
    m,old,new,original,index=package_files()
    state=inspect(root,m)
    result={'mode':mode,'state':state,'old_bundle':m['old_bundle'],'new_bundle':m['new_bundle'],'backend_changes':0,'database_changes':0,'nginx_changes':0,'service_restarts':0}
    if mode=='check': return result
    lock_path=root.parent/'.learning-center-static-deploy.lock'
    if lock_path.is_symlink(): raise RuntimeError('symlink lock refused')
    with open(lock_path,'a+b') as lock:
        os.chmod(lock_path,0o600); fcntl.flock(lock,fcntl.LOCK_EX)
        state=inspect(root,m)
        backup=root.parent/'.learning-center-static-backups'/m['new_bundle_sha256'][:12]
        if mode=='install':
            if state=='installed': return dict(result,state='installed',idempotent=True)
            if backup.is_symlink() or backup.parent.is_symlink(): raise RuntimeError('symlink backup refused')
            backup.mkdir(parents=True,exist_ok=True,mode=0o700)
            os.chmod(backup.parent,0o700); os.chmod(backup,0o700)
            previous=backup/'index.html'
            if previous.exists(): load(previous,m['old_index_sha256'])
            else: atomic_write(previous,original,0o600)
            dest=root/'dist'/m['new_bundle']
            if dest.exists() or dest.is_symlink(): load(dest,m['new_bundle_sha256'])
            else: atomic_write(dest,new)
            # Compare again immediately before the atomic pointer change.
            if inspect(root,m)!='original': raise RuntimeError('index changed while preparing patch')
            atomic_write(root/'index.html',index)
            if inspect(root,m)!='installed': raise RuntimeError('post-install checksum mismatch')
            return dict(result,state='installed',idempotent=False,backup_index=str(previous),original_bundle_retained=True)
        if mode=='rollback':
            if state=='original': return dict(result,state='original',idempotent=True)
            load(backup/'index.html',m['old_index_sha256'])
            atomic_write(root/'index.html',original)
            if inspect(root,m)!='original': raise RuntimeError('post-rollback checksum mismatch')
            return dict(result,state='original',idempotent=False,original_bundle_retained=True,new_bundle_retained=True)
        raise RuntimeError('unknown mode')

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root',required=True); p.add_argument('--mode',choices=['check','install','rollback'],required=True)
    args=p.parse_args()
    try:
        result=run(args.root,args.mode)
        print(json.dumps(dict(ok=True,**result),ensure_ascii=False)); return 0
    except (OSError,ValueError,KeyError,RuntimeError) as exc:
        print(json.dumps({'ok':False,'mode':args.mode,'error':str(exc)},ensure_ascii=False)); return 1
if __name__=='__main__': raise SystemExit(main())
